# Greenfield Hub Connect

This is my Greenfield Hub Connect project (frontend + backend for a local produce marketplace app).
I wrote this guide in a simple step-by-step way so it is easier to run without setup issues.

## What This App Includes

- Customer and producer accounts
- Producer dashboard for adding/updating products
- Basket and checkout flow
- Loyalty points
- Previous orders page with:
  - order ID
  - product names + quantities
  - reorder button
  - order tracker (delivery = dispatched/delivered, collection = ready to collect/collected)
- Account settings page with:
  - accessibility tab (large text, high contrast, reduced motion)
  - saved bank details and address per account

## 1) Requirements

- Node.js `18+` (tested on Node 22)
- npm
- PostgreSQL running locally

## 2) Install Dependencies

From project root:

```bash
npm install
npm --prefix backend install
```

## 3) Create Environment Files

Create root `.env`:

```env
VITE_API_URL="http://localhost:4000"
```

Create `backend/.env`:

```env
PORT=4000
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/greenfield_hub
JWT_SECRET=replace_with_a_long_random_string
JWT_EXPIRES_IN=7d
CLIENT_ORIGIN=http://localhost:8080
COOKIE_NAME=ghc_token
NODE_ENV=development
```

## 4) Run Migrations + Seed Data

Make sure PostgreSQL is running first, then:

```bash
npm run backend:migrate
npm run backend:seed
```

This creates all required tables (including account settings table) and test users.

### Test Users

- Producer: `producer@example.com` / `password123`
- Customer: `customer@example.com` / `password123`

## 5) Start the App

```bash
npm run dev
```

- Frontend: `http://localhost:8080`
- Backend: `http://localhost:4000`

If `8080` is busy, Vite may move to `8081`.

## 6) Quick Checks

If you want to verify everything quickly:

```bash
npm run backend:migrate
npm run backend:seed
npm run build
npm run test:backend
```

## Common Issues + Fixes

### `database "greenfield_hub" does not exist`

Run:

```bash
npm run backend:migrate
npm run backend:seed
```

### `relation "user_account_settings" does not exist`

You need latest migration:

```bash
npm run backend:migrate
```

### `Port 4000 is already in use`

Stop old process on that port (or previous terminal), then run:

```bash
npm run dev
```

### `Unexpected token '<' ... is not valid JSON`

Usually means backend route/proxy not active yet.
Restart dev server:

```bash
npm run dev
```

### Vite/esbuild issues (common in OneDrive folders)

```bash
npm install
npm rebuild esbuild
npm --prefix backend install
npm --prefix backend rebuild esbuild
```

Also make sure project files are available locally (not cloud-only placeholders).

## Tech Stack

- React + Vite + TypeScript
- Tailwind CSS + shadcn/ui
- Node.js + Express
- PostgreSQL
- JWT auth (HTTP-only cookies)
- Vitest