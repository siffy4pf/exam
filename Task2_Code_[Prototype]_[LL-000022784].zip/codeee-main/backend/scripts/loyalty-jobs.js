import { runAllLoyaltyScheduledTasks } from "../src/jobs/loyaltyJobs.js";
import { assertRequiredConfig } from "../src/config.js";
import { pool } from "../src/db.js";

async function main() {
  assertRequiredConfig();
  const out = await runAllLoyaltyScheduledTasks(new Date());
  console.log(JSON.stringify(out, null, 2));
}

main()
  .catch((e) => {
    console.error(e);
    process.exitCode = 1;
  })
  .finally(() => pool.end());
