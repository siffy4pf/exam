import { assertRequiredConfig } from "../src/config.js";
import { pool } from "../src/db.js";
import { hashPassword } from "../src/utils/auth.js";

async function run() {
  assertRequiredConfig();

  const email = "producer@example.com";
  const passwordHash = await hashPassword("password123");

  await pool.query(
    `INSERT INTO users (email, full_name, password_hash, role)
     VALUES ($1, $2, $3, 'producer')
     ON CONFLICT (email) DO UPDATE SET role = 'producer', full_name = EXCLUDED.full_name`,
    [email, "Sample Producer", passwordHash],
  );

  const customerEmail = "customer@example.com";
  await pool.query(
    `INSERT INTO users (email, full_name, password_hash, role)
     VALUES ($1, $2, $3, 'customer')
     ON CONFLICT (email) DO UPDATE SET role = 'customer', full_name = EXCLUDED.full_name`,
    [customerEmail, "Sample Customer", passwordHash],
  );

  console.log(
    `Seed complete. Producer: ${email} / password123 — Customer: ${customerEmail} / password123`,
  );
  await pool.end();
}

run().catch(async (error) => {
  console.error("Seed failed:", error);
  await pool.end();
  process.exit(1);
});
