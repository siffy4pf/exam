import { pool } from "../db.js";
import { batchQualifiesForExpiryReminder } from "../services/loyaltyRules.js";
import * as repo from "../repositories/loyaltyRepository.js";
import { sendPointsExpiryReminder } from "../services/emailService.js";
import { runPointExpiry } from "../services/loyaltyService.js";

const DAYS_BEFORE_EXPIRY_REMINDER = 30;

/**
 * Sends one email per eligible batch (30 days before expiry, UTC calendar match).
 */
export async function runExpiryReminderEmails(now = new Date()) {
  const client = await pool.connect();
  const sent = [];
  try {
    const rows = await repo.findBatchesPendingReminder(client, now);
    for (const r of rows) {
      if (
        !batchQualifiesForExpiryReminder({
          expiresAt: r.expires_at,
          now,
          daysBeforeExpiry: DAYS_BEFORE_EXPIRY_REMINDER,
        })
      ) {
        continue;
      }
      await sendPointsExpiryReminder({
        to: r.email,
        points: r.points_remaining,
        expiresAt: r.expires_at,
      });
      await repo.markReminderSent(client, r.id);
      sent.push({ batchId: r.id, email: r.email });
    }
    return { sent };
  } finally {
    client.release();
  }
}

export async function runAllLoyaltyScheduledTasks(now = new Date()) {
  const expiry = await runPointExpiry(now);
  const reminders = await runExpiryReminderEmails(now);
  return { expiry, reminders };
}
