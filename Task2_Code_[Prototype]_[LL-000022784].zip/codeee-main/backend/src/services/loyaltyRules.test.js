import { describe, it, expect } from "vitest";
import {
  pointsEarnedFromEarnBasePence,
  earnBasePence,
  discountPenceFromRedeemedPoints,
  maxRedeemablePoints,
  isValidRedemptionIncrement,
  validateRedemption,
  defaultExpiresAt,
  batchQualifiesForExpiryReminder,
  MIN_REDEMPTION_POINTS,
  MAX_REDEMPTION_POINTS,
  REDEMPTION_INCREMENT,
} from "./loyaltyRules.js";

describe("pointsEarnedFromEarnBasePence", () => {
  it("10 points per £1, round down", () => {
    expect(pointsEarnedFromEarnBasePence(100)).toBe(10);
    expect(pointsEarnedFromEarnBasePence(1000)).toBe(100);
    expect(pointsEarnedFromEarnBasePence(99)).toBe(9);
    expect(pointsEarnedFromEarnBasePence(109)).toBe(10);
  });
  it("handles zero and negatives", () => {
    expect(pointsEarnedFromEarnBasePence(0)).toBe(0);
    expect(pointsEarnedFromEarnBasePence(-5)).toBe(0);
  });
});

describe("earnBasePence", () => {
  it("merchandise minus loyalty discount only", () => {
    expect(earnBasePence({ merchandiseSubtotalPence: 5000, loyaltyDiscountPence: 750 })).toBe(4250);
  });
  it("never negative", () => {
    expect(earnBasePence({ merchandiseSubtotalPence: 100, loyaltyDiscountPence: 500 })).toBe(0);
  });
});

describe("discountPenceFromRedeemedPoints", () => {
  it("150 points = £1.50 → 150p", () => {
    expect(discountPenceFromRedeemedPoints(150)).toBe(150);
  });
  it("75 points = 75p", () => {
    expect(discountPenceFromRedeemedPoints(75)).toBe(75);
  });
});

describe("maxRedeemablePoints", () => {
  it("returns 0 when subtotal below minimum threshold", () => {
    expect(maxRedeemablePoints({ merchandiseSubtotalPence: 74, redeemablePointsBalance: 1000 })).toBe(0);
  });
  it("caps at 750 and at subtotal and at balance", () => {
    expect(maxRedeemablePoints({ merchandiseSubtotalPence: 10000, redeemablePointsBalance: 2000 })).toBe(750);
    expect(maxRedeemablePoints({ merchandiseSubtotalPence: 200, redeemablePointsBalance: 10000 })).toBe(150);
    expect(maxRedeemablePoints({ merchandiseSubtotalPence: 10000, redeemablePointsBalance: 140 })).toBe(75);
    expect(maxRedeemablePoints({ merchandiseSubtotalPence: 10000, redeemablePointsBalance: 50 })).toBe(0);
  });
  it("floors to 75 increments", () => {
    expect(maxRedeemablePoints({ merchandiseSubtotalPence: 200, redeemablePointsBalance: 200 })).toBe(150);
    expect(maxRedeemablePoints({ merchandiseSubtotalPence: 800, redeemablePointsBalance: 800 })).toBe(750);
  });
});

describe("isValidRedemptionIncrement", () => {
  it("accepts 0 and valid steps", () => {
    expect(isValidRedemptionIncrement(0)).toBe(true);
    expect(isValidRedemptionIncrement(75)).toBe(true);
    expect(isValidRedemptionIncrement(150)).toBe(true);
    expect(isValidRedemptionIncrement(750)).toBe(true);
  });
  it("rejects invalid", () => {
    expect(isValidRedemptionIncrement(76)).toBe(false);
    expect(isValidRedemptionIncrement(74)).toBe(false);
    expect(isValidRedemptionIncrement(751)).toBe(false);
    expect(isValidRedemptionIncrement(1.5)).toBe(false);
  });
});

describe("validateRedemption", () => {
  it("allows zero redemption", () => {
    expect(validateRedemption(0, { merchandiseSubtotalPence: 10, redeemablePointsBalance: 0 })).toEqual([]);
  });
  it("rejects when subtotal below minimum threshold", () => {
    const e = validateRedemption(75, { merchandiseSubtotalPence: 50, redeemablePointsBalance: 500 });
    expect(e.some((x) => x.includes("minimum redemption"))).toBe(true);
  });
  it("rejects exceeding subtotal (cannot exceed merchandise)", () => {
    const e = validateRedemption(150, { merchandiseSubtotalPence: 100, redeemablePointsBalance: 500 });
    expect(e.some((x) => x.toLowerCase().includes("subtotal"))).toBe(true);
  });
  it("rejects exceeding available batch points", () => {
    const e = validateRedemption(150, { merchandiseSubtotalPence: 500, redeemablePointsBalance: 100 });
    expect(e.some((x) => x.includes("Insufficient"))).toBe(true);
  });
  it("rejects non-75 increments", () => {
    const e = validateRedemption(100, { merchandiseSubtotalPence: 500, redeemablePointsBalance: 500 });
    expect(e.length).toBeGreaterThan(0);
  });
  it("accepts valid 150 redemption", () => {
    expect(validateRedemption(150, { merchandiseSubtotalPence: 500, redeemablePointsBalance: 200 })).toEqual([]);
  });
});

describe("defaultExpiresAt", () => {
  it("adds 12 months UTC", () => {
    const base = new Date(Date.UTC(2025, 0, 15, 12, 0, 0));
    const exp = defaultExpiresAt(base);
    expect(exp.getUTCFullYear()).toBe(2026);
    expect(exp.getUTCMonth()).toBe(0);
    expect(exp.getUTCDate()).toBe(15);
  });
});

describe("batchQualifiesForExpiryReminder", () => {
  it("true exactly 30 days before expiry (UTC date)", () => {
    const expiresAt = new Date(Date.UTC(2026, 5, 20, 12, 0, 0));
    const now = new Date(Date.UTC(2026, 4, 21, 0, 0, 0));
    expect(batchQualifiesForExpiryReminder({ expiresAt, now, daysBeforeExpiry: 30 })).toBe(true);
  });
  it("false on other days", () => {
    const expiresAt = new Date(Date.UTC(2026, 5, 20, 12, 0, 0));
    const now = new Date(Date.UTC(2026, 4, 22, 0, 0, 0));
    expect(batchQualifiesForExpiryReminder({ expiresAt, now, daysBeforeExpiry: 30 })).toBe(false);
  });
});

describe("end-to-end earn on net after redemption", () => {
  it("earn uses subtotal after discount, not delivery", () => {
    const m = 2000;
    const redeem = 150;
    const discount = discountPenceFromRedeemedPoints(redeem);
    const base = earnBasePence({ merchandiseSubtotalPence: m, loyaltyDiscountPence: discount });
    expect(base).toBe(1850);
    expect(pointsEarnedFromEarnBasePence(base)).toBe(185);
  });
});

describe("constants match spec", () => {
  it("redemption bounds", () => {
    expect(MIN_REDEMPTION_POINTS).toBe(75);
    expect(MAX_REDEMPTION_POINTS).toBe(750);
    expect(REDEMPTION_INCREMENT).toBe(75);
  });
});

describe("validateRedemption vs maxRedeemablePoints", () => {
  it("rejects choosing more than max allowed even if balance is higher", () => {
    const m = 200;
    const avail = 500;
    const max = maxRedeemablePoints({ merchandiseSubtotalPence: m, redeemablePointsBalance: avail });
    expect(max).toBe(150);
    expect(validateRedemption(225, { merchandiseSubtotalPence: m, redeemablePointsBalance: avail }).length).toBeGreaterThan(0);
  });
});
