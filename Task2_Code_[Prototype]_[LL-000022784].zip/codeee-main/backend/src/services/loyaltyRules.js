/**
 * Loyalty rules (pure functions — no I/O).
 *
 * Earning: 10 points per £1 spent on final merchandise subtotal after discounts, excluding delivery.
 *           Whole points only (round down).
 * Redemption: 1 point = 1p discount; min 75 pts, max 750 pts per order, 75-pt increments only.
 *             Discount must not exceed merchandise subtotal (pre-delivery).
 */

export const MIN_REDEMPTION_POINTS = 75;
export const MAX_REDEMPTION_POINTS = 750;
export const REDEMPTION_INCREMENT = 75;

/** £1 = 100p → 10 points ⇒ floor(pence / 10). */
export function pointsEarnedFromEarnBasePence(earnBasePence) {
  if (!Number.isFinite(earnBasePence) || earnBasePence < 0) return 0;
  return Math.floor(earnBasePence / 10);
}

/** Merchandise after loyalty discount, before delivery — earn base in pence. */
export function earnBasePence({ merchandiseSubtotalPence, loyaltyDiscountPence }) {
  const m = Number(merchandiseSubtotalPence);
  const d = Number(loyaltyDiscountPence);
  if (!Number.isFinite(m) || m < 0) return 0;
  if (!Number.isFinite(d) || d < 0) return Math.floor(m);
  return Math.max(0, Math.floor(m - d));
}

export function discountPenceFromRedeemedPoints(pointsToRedeem) {
  if (!Number.isFinite(pointsToRedeem) || pointsToRedeem < 0) return 0;
  return Math.floor(pointsToRedeem);
}

/**
 * Largest allowed redemption (0 or 75..750 in steps of 75) for this subtotal and wallet.
 */
export function maxRedeemablePoints({ merchandiseSubtotalPence, redeemablePointsBalance }) {
  const capBySubtotal = Math.min(
    MAX_REDEMPTION_POINTS,
    Math.max(0, Math.floor(Number(merchandiseSubtotalPence) || 0)),
    Math.max(0, Math.floor(Number(redeemablePointsBalance) || 0)),
  );
  if (capBySubtotal < MIN_REDEMPTION_POINTS) return 0;
  const steps = Math.floor(capBySubtotal / REDEMPTION_INCREMENT);
  return steps * REDEMPTION_INCREMENT;
}

export function isValidRedemptionIncrement(pointsToRedeem) {
  if (pointsToRedeem === 0) return true;
  if (!Number.isInteger(pointsToRedeem)) return false;
  if (pointsToRedeem < MIN_REDEMPTION_POINTS) return false;
  if (pointsToRedeem > MAX_REDEMPTION_POINTS) return false;
  return pointsToRedeem % REDEMPTION_INCREMENT === 0;
}

export function validateRedemption(pointsToRedeem, { merchandiseSubtotalPence, redeemablePointsBalance }) {
  const errors = [];
  const m = Number(merchandiseSubtotalPence);
  const avail = Number(redeemablePointsBalance);

  if (!Number.isFinite(pointsToRedeem) || pointsToRedeem < 0 || !Number.isInteger(pointsToRedeem)) {
    errors.push("pointsToRedeem must be a non-negative integer");
    return errors;
  }

  if (pointsToRedeem === 0) return errors;

  if (!isValidRedemptionIncrement(pointsToRedeem)) {
    errors.push(`Redemption must be 0 or between ${MIN_REDEMPTION_POINTS} and ${MAX_REDEMPTION_POINTS} in steps of ${REDEMPTION_INCREMENT}`);
  }

  if (maxRedeemablePoints({ merchandiseSubtotalPence: m, redeemablePointsBalance: avail }) < MIN_REDEMPTION_POINTS) {
    errors.push("Order subtotal is below the minimum redemption threshold");
  }

  if (pointsToRedeem > avail) {
    errors.push("Insufficient loyalty points");
  }

  if (pointsToRedeem > m) {
    errors.push("Redemption cannot exceed the order merchandise subtotal");
  }

  const maxAllowed = maxRedeemablePoints({ merchandiseSubtotalPence: m, redeemablePointsBalance: avail });
  if (pointsToRedeem > maxAllowed) {
    errors.push(`Redemption exceeds the maximum allowed for this order (${maxAllowed} points)`);
  }

  return errors;
}

/** Default expiry: 12 months after earned-at (UTC calendar). */
export function defaultExpiresAt(earnedAt) {
  const d = new Date(earnedAt);
  return new Date(Date.UTC(d.getUTCFullYear() + 1, d.getUTCMonth(), d.getUTCDate(), 23, 59, 59, 999));
}

/**
 * True on the calendar day (UTC) that is exactly `daysBeforeExpiry` days before `expiresAt` (date part).
 * Used to send one reminder per batch.
 */
export function batchQualifiesForExpiryReminder({ expiresAt, now, daysBeforeExpiry }) {
  const exp = new Date(expiresAt);
  const reminder = new Date(Date.UTC(exp.getUTCFullYear(), exp.getUTCMonth(), exp.getUTCDate()));
  reminder.setUTCDate(reminder.getUTCDate() - daysBeforeExpiry);
  const cur = new Date(now);
  return (
    cur.getUTCFullYear() === reminder.getUTCFullYear() &&
    cur.getUTCMonth() === reminder.getUTCMonth() &&
    cur.getUTCDate() === reminder.getUTCDate()
  );
}
