/**
 * Sends loyalty expiry reminders. In development, logs to the console; wire SMTP or a provider for production.
 */
export async function sendPointsExpiryReminder({ to, points, expiresAt }) {
  const line = `[loyalty-email] Reminder to ${to}: ${points} point(s) will expire on ${new Date(expiresAt).toISOString()}`;
  console.info(line);
  return { ok: true, line };
}
