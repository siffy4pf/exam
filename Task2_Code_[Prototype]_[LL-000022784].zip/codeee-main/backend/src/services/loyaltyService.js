import { pool } from "../db.js";
import {
  pointsEarnedFromEarnBasePence,
  earnBasePence,
  discountPenceFromRedeemedPoints,
  validateRedemption,
  defaultExpiresAt,
} from "./loyaltyRules.js";
import * as repo from "../repositories/loyaltyRepository.js";

// Service layer for loyalty rules + order lifecycle actions.
export async function getLoyaltySummary(userId) {
  const client = await pool.connect();
  try {
    const ledger = await repo.getLedgerBalance(client, userId);
    const redeemable = await repo.getRedeemableBatchTotal(client, userId, new Date());
    return { ledgerBalance: ledger, redeemablePoints: redeemable };
  } finally {
    client.release();
  }
}

export async function previewCheckoutRedemption({
  userId,
  merchandiseSubtotalPence,
  pointsToRedeem,
}) {
  const client = await pool.connect();
  try {
    const redeemable = await repo.getRedeemableBatchTotal(client, userId, new Date());
    const errors = validateRedemption(pointsToRedeem, {
      merchandiseSubtotalPence,
      redeemablePointsBalance: redeemable,
    });
    const discountPence = discountPenceFromRedeemedPoints(pointsToRedeem);
    const earnBase = earnBasePence({
      merchandiseSubtotalPence,
      loyaltyDiscountPence: discountPence,
    });
    const pointsWouldEarn = pointsEarnedFromEarnBasePence(earnBase);
    return {
      ok: errors.length === 0,
      errors,
      redeemablePoints: redeemable,
      discountPence,
      earnBasePence: earnBase,
      pointsWouldEarn,
    };
  } finally {
    client.release();
  }
}

/**
 * Completes a paid order: optional redemption (FIFO batches), then earn on net merchandise.
 */
export async function completePaidCheckout({
  userId,
  merchandiseSubtotalPence,
  deliveryChargePence,
  pointsToRedeem,
  idempotencyKey,
  fulfillmentType = "collection",
  items = [],
  paidAt = new Date(),
}) {
  const m = Math.floor(Number(merchandiseSubtotalPence));
  const d = Math.floor(Number(deliveryChargePence) || 0);
  const redeemPts = Math.floor(Number(pointsToRedeem) || 0);

  if (!Number.isFinite(m) || m < 0) throw new Error("Invalid merchandiseSubtotalPence");
  if (!Number.isFinite(d) || d < 0) throw new Error("Invalid deliveryChargePence");

  const client = await pool.connect();
  try {
    // If same key was already processed, return the existing order safely.
    if (idempotencyKey) {
      const existing = await repo.getOrderByIdempotencyKey(client, idempotencyKey);
      if (existing) {
        return { order: existing, duplicate: true };
      }
    }

    const redeemable = await repo.getRedeemableBatchTotal(client, userId, paidAt);
    const v = validateRedemption(redeemPts, {
      merchandiseSubtotalPence: m,
      redeemablePointsBalance: redeemable,
    });
    if (v.length) {
      const err = new Error(v.join("; "));
      err.code = "INVALID_REDEMPTION";
      err.details = v;
      throw err;
    }

    const discountPence = discountPenceFromRedeemedPoints(redeemPts);
    const earnBase = earnBasePence({
      merchandiseSubtotalPence: m,
      loyaltyDiscountPence: discountPence,
    });
    const pointsEarned = pointsEarnedFromEarnBasePence(earnBase);

    await client.query("BEGIN");

    const orderRow = await repo.insertOrder(client, {
      userId,
      status: "paid",
      fulfillmentType: fulfillmentType === "delivery" ? "delivery" : "collection",
      merchandiseSubtotalPence: m,
      deliveryChargePence: d,
      loyaltyPointsRedeemed: redeemPts,
      loyaltyDiscountPence: discountPence,
      earnBasePence: earnBase,
      pointsEarned,
      idempotencyKey: idempotencyKey ?? null,
    });

    if (!orderRow) {
      await client.query("ROLLBACK");
      const dup = await repo.getOrderByIdempotencyKey(client, idempotencyKey);
      return { order: dup, duplicate: true };
    }

    const normalizedItems = (Array.isArray(items) ? items : [])
      .map((item) => ({
        productId: item?.productId ? String(item.productId) : null,
        productName: String(item?.productName ?? "").trim(),
        unitPricePence: Math.floor(Number(item?.unitPricePence) || 0),
        quantity: Math.floor(Number(item?.quantity) || 0),
      }))
      .filter((item) => item.productName && item.unitPricePence >= 0 && item.quantity > 0);

    if (normalizedItems.length > 0) {
      await repo.insertOrderItems(client, { orderId: orderRow.id, items: normalizedItems });
    }

    if (redeemPts > 0) {
      // Redeem points from oldest valid batches first (FIFO).
      await repo.insertTransaction(client, {
        userId,
        txType: "redeem",
        points: -redeemPts,
        orderId: orderRow.id,
        note: "Checkout redemption",
      });

      let left = redeemPts;
      const { rows: batchRows } = await repo.lockBatchesFifo(client, userId, paidAt);
      for (const b of batchRows) {
        if (left <= 0) break;
        const take = Math.min(b.points_remaining, left);
        const r = await client.query(
          `UPDATE loyalty_point_batches SET points_remaining = points_remaining - $1 WHERE id = $2 AND points_remaining >= $1 RETURNING id`,
          [take, b.id],
        );
        if (r.rowCount !== 1) {
          throw new Error("FIFO loyalty debit failed (concurrent update?)");
        }
        left -= take;
      }
      if (left > 0) {
        throw new Error("Insufficient batch points after validation");
      }
    }

    if (pointsEarned > 0) {
      // Earned points are stored in a batch so they can expire later.
      const expiresAt = defaultExpiresAt(paidAt);
      const batchId = await repo.insertEarnBatch(client, {
        userId,
        sourceOrderId: orderRow.id,
        pointsOriginal: pointsEarned,
        earnedAt: paidAt,
        expiresAt,
      });
      await repo.insertTransaction(client, {
        userId,
        txType: "earn",
        points: pointsEarned,
        orderId: orderRow.id,
        batchId,
        note: "Earned on paid order",
      });
    }

    await client.query("COMMIT");
    return { order: orderRow, duplicate: false };
  } catch (e) {
    await client.query("ROLLBACK").catch(() => {});
    throw e;
  } finally {
    client.release();
  }
}

export async function refundOrCancelPaidOrder(orderId, { nextStatus }) {
  if (!["cancelled", "refunded"].includes(nextStatus)) {
    throw new Error("nextStatus must be cancelled or refunded");
  }
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const order = await repo.getOrderById(client, orderId);
    if (!order) {
      await client.query("ROLLBACK");
      const err = new Error("Order not found");
      err.code = "NOT_FOUND";
      throw err;
    }
    if (order.status !== "paid") {
      await client.query("ROLLBACK");
      return { order, changed: false };
    }

    const E = order.points_earned;
    if (E > 0) {
      await repo.insertTransaction(client, {
        userId: order.user_id,
        txType: "refund_clawback",
        points: -E,
        orderId: order.id,
        note: `Order ${nextStatus}: claw back earned points`,
      });
      await repo.clawbackEarnedPointsOnBatch(client, { sourceOrderId: order.id, pointsEarned: E });
    }

    await repo.updateOrderStatus(client, order.id, nextStatus);
    await client.query("COMMIT");
    const updated = await repo.getOrderById(client, orderId);
    return { order: updated, changed: true };
  } catch (e) {
    await client.query("ROLLBACK").catch(() => {});
    throw e;
  } finally {
    client.release();
  }
}

export async function runPointExpiry(now = new Date()) {
  const client = await pool.connect();
  const expired = [];
  try {
    await client.query("BEGIN");
    const rows = await repo.findBatchesNeedingExpiry(client, now);
    for (const b of rows) {
      const pts = b.points_remaining;
      if (pts <= 0) continue;
      await repo.insertTransaction(client, {
        userId: b.user_id,
        txType: "expire",
        points: -pts,
        batchId: b.id,
        note: "Points expired after 12 months",
      });
      await repo.zeroBatchRemaining(client, b.id);
      expired.push({ batchId: b.id, userId: b.user_id, points: pts });
    }
    await client.query("COMMIT");
    return { expired };
  } catch (e) {
    await client.query("ROLLBACK").catch(() => {});
    throw e;
  } finally {
    client.release();
  }
}
