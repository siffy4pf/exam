import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

// Load backend env values from backend/.env file.
const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.join(__dirname, "..", ".env") });

// Central config object used around backend services.
export const config = {
  port: Number(process.env.PORT ?? 4000),
  databaseUrl: process.env.DATABASE_URL ?? "",
  jwtSecret: process.env.JWT_SECRET ?? "",
  jwtExpiresIn: process.env.JWT_EXPIRES_IN ?? "7d",
  clientOrigin: process.env.CLIENT_ORIGIN ?? "http://localhost:8080",
  cookieName: process.env.COOKIE_NAME ?? "ghc_token",
  isProduction: process.env.NODE_ENV === "production",
};

export function assertRequiredConfig() {
  // In production we fail fast if critical env values are missing.
  if (config.isProduction) {
    const missing = [];
    if (!config.databaseUrl) missing.push("DATABASE_URL");
    if (!config.jwtSecret) missing.push("JWT_SECRET");
    if (missing.length > 0) {
      throw new Error(`Missing required environment variables: ${missing.join(", ")}`);
    }
    return;
  }

  if (!config.jwtSecret) {
    config.jwtSecret = "dev-only-jwt-secret-change-me-in-backend-env";
    console.warn("[config] JWT_SECRET missing; using insecure development default. Set JWT_SECRET in backend/.env.");
  }

  if (!config.databaseUrl) {
    config.databaseUrl = "postgresql://postgres:postgres@localhost:5432/greenfield_hub";
    console.warn(
      "[config] DATABASE_URL missing; using localhost default. Copy backend/.env.example to backend/.env and adjust if your Postgres differs.",
    );
  }
}
