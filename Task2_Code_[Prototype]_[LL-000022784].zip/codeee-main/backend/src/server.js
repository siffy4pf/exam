import { app } from "./app.js";
import { assertRequiredConfig, config } from "./config.js";

// Validate env setup first, then start HTTP server.
assertRequiredConfig();

const server = app.listen(config.port, () => {
  console.log(`Backend running on http://localhost:${config.port}`);
});

server.on("error", (err) => {
  if (err && err.code === "EADDRINUSE") {
    console.error(
      `[server] Port ${config.port} is already in use. Stop the other process or set PORT in backend/.env to a free port.`,
    );
  } else {
    console.error("[server] Failed to start:", err);
  }
  process.exit(1);
});
