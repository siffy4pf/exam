import { config } from "../config.js";
import {
  findUserByEmail,
  findUserById,
  createUser,
  updatePassword,
  getUserAccountSettings,
  upsertUserAccountSettings,
} from "../repositories/userRepository.js";
import { hashPassword, verifyPassword, signToken, getCookieOptions } from "../utils/auth.js";

// Remove DB-only fields so API never returns sensitive data.
function sanitizeUser(user) {
  return {
    id: user.id,
    email: user.email,
    fullName: user.full_name,
    role: user.role,
  };
}

function setSessionCookie(res, userId) {
  // Session is stored in a signed JWT cookie.
  const token = signToken(userId);
  res.cookie(config.cookieName, token, getCookieOptions());
}

export async function signUp(req, res) {
  const { email, password, fullName, role: requestedRole } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: "Email and password are required." });
  }

  if (password.length < 8) {
    return res.status(400).json({ error: "Password must be at least 8 characters." });
  }

  const role = requestedRole === "producer" ? "producer" : "customer";

  const existingUser = await findUserByEmail(email);
  if (existingUser) {
    return res.status(409).json({ error: "An account with this email already exists." });
  }

  const passwordHash = await hashPassword(password);
  const user = await createUser({
    email,
    fullName: fullName?.trim() || null,
    passwordHash,
    role,
  });

  setSessionCookie(res, user.id);
  return res.status(201).json({ user: sanitizeUser(user) });
}

export async function login(req, res) {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: "Email and password are required." });
  }

  const user = await findUserByEmail(email);
  if (!user) {
    return res.status(401).json({ error: "Invalid email or password." });
  }

  const passwordMatches = await verifyPassword(password, user.password_hash);
  if (!passwordMatches) {
    return res.status(401).json({ error: "Invalid email or password." });
  }

  setSessionCookie(res, user.id);
  return res.status(200).json({ user: sanitizeUser(user) });
}

export async function logout(_req, res) {
  res.clearCookie(config.cookieName, getCookieOptions());
  return res.status(204).send();
}

export async function session(req, res) {
  // Used by frontend on page load to restore login state.
  const user = await findUserById(req.userId);
  if (!user) {
    res.clearCookie(config.cookieName, getCookieOptions());
    return res.status(401).json({ error: "Session not found." });
  }

  return res.status(200).json({ user: sanitizeUser(user) });
}

export async function changePassword(req, res) {
  const { currentPassword, newPassword } = req.body;

  if (!currentPassword || !newPassword) {
    return res.status(400).json({ error: "Current and new password are required." });
  }

  if (newPassword.length < 8) {
    return res.status(400).json({ error: "Password must be at least 8 characters." });
  }

  const user = await findUserById(req.userId);
  if (!user) {
    return res.status(404).json({ error: "User not found." });
  }

  const userWithPassword = await findUserByEmail(user.email);
  const passwordMatches = await verifyPassword(currentPassword, userWithPassword.password_hash);
  if (!passwordMatches) {
    return res.status(401).json({ error: "Current password is incorrect." });
  }

  const passwordHash = await hashPassword(newPassword);
  await updatePassword({ userId: req.userId, passwordHash });

  return res.status(200).json({ message: "Password updated successfully." });
}

function mapAccountSettings(row) {
  // Always return strings so frontend forms can bind safely.
  return {
    bankAccountName: row?.bank_account_name ?? "",
    bankSortCode: row?.bank_sort_code ?? "",
    bankAccountNumber: row?.bank_account_number ?? "",
    addressLine1: row?.address_line1 ?? "",
    addressLine2: row?.address_line2 ?? "",
    addressCity: row?.address_city ?? "",
    addressPostcode: row?.address_postcode ?? "",
    addressPhone: row?.address_phone ?? "",
  };
}

export async function getProfile(req, res) {
  // Get account-specific bank/address profile.
  const row = await getUserAccountSettings(req.userId);
  return res.status(200).json({ profile: mapAccountSettings(row) });
}

export async function updateProfile(req, res) {
  // Sanitize incoming profile payload before saving.
  const trim = (v) => String(v ?? "").trim();
  const payload = {
    bankAccountName: trim(req.body?.bankAccountName),
    bankSortCode: trim(req.body?.bankSortCode),
    bankAccountNumber: trim(req.body?.bankAccountNumber),
    addressLine1: trim(req.body?.addressLine1),
    addressLine2: trim(req.body?.addressLine2),
    addressCity: trim(req.body?.addressCity),
    addressPostcode: trim(req.body?.addressPostcode),
    addressPhone: trim(req.body?.addressPhone),
  };
  const saved = await upsertUserAccountSettings(req.userId, payload);
  return res.status(200).json({ profile: mapAccountSettings(saved) });
}
