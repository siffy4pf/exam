import * as productRepo from "../repositories/productRepository.js";
import { findUserById } from "../repositories/userRepository.js";

function mapProduct(row) {
  if (!row) return null;
  return {
    id: row.id,
    producerUserId: row.producer_user_id,
    name: row.name,
    stock: row.stock,
    pricePence: row.price_pence,
    price: row.price_pence / 100,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

async function requireProducer(req, res) {
  const user = await findUserById(req.userId);
  if (!user) {
    res.status(401).json({ error: "Not authenticated." });
    return null;
  }
  if (user.role !== "producer") {
    res.status(403).json({ error: "Producer access required." });
    return null;
  }
  return user;
}

export async function listMyProducts(req, res) {
  const user = await requireProducer(req, res);
  if (!user) return;

  const rows = await productRepo.listByProducerUserId(user.id);
  res.json({ products: rows.map(mapProduct) });
}

export async function createMyProduct(req, res) {
  const user = await requireProducer(req, res);
  if (!user) return;

  const name = String(req.body?.name ?? "").trim();
  const stock = Number(req.body?.stock);
  const price = Number(req.body?.price);

  if (!name) return res.status(400).json({ error: "Product name is required." });
  if (!Number.isInteger(stock) || stock < 0) {
    return res.status(400).json({ error: "Stock must be a non-negative integer." });
  }
  if (!Number.isFinite(price) || price <= 0) {
    return res.status(400).json({ error: "Price must be a positive number." });
  }

  const pricePence = Math.round(price * 100);
  const created = await productRepo.createForProducer({
    producerUserId: user.id,
    name,
    stock,
    pricePence,
  });
  return res.status(201).json({ product: mapProduct(created) });
}

export async function updateMyProductStock(req, res) {
  const user = await requireProducer(req, res);
  if (!user) return;

  const stock = Number(req.body?.stock);
  if (!Number.isInteger(stock) || stock < 0) {
    return res.status(400).json({ error: "Stock must be a non-negative integer." });
  }

  const updated = await productRepo.updateStockForProducer({
    producerUserId: user.id,
    productId: req.params.id,
    stock,
  });
  if (!updated) return res.status(404).json({ error: "Product not found." });

  return res.json({ product: mapProduct(updated) });
}
