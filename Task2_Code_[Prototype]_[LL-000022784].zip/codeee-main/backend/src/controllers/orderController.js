import { completePaidCheckout, refundOrCancelPaidOrder } from "../services/loyaltyService.js";
import * as repo from "../repositories/loyaltyRepository.js";
import { pool } from "../db.js";

// Convert DB columns into frontend-friendly response shape.
function mapOrder(row) {
  if (!row) return null;
  return {
    id: row.id,
    status: row.status,
    fulfillmentType: row.fulfillment_type ?? "collection",
    merchandiseSubtotalPence: row.merchandise_subtotal_pence,
    deliveryChargePence: row.delivery_charge_pence,
    loyaltyPointsRedeemed: row.loyalty_points_redeemed,
    loyaltyDiscountPence: row.loyalty_discount_pence,
    earnBasePence: row.earn_base_pence,
    pointsEarned: row.points_earned,
    createdAt: row.created_at,
  };
}

export async function listMyOrders(req, res) {
  // Return orders plus nested items for history + reorder UI.
  const { rows } = await pool.query(
    `SELECT
       o.*,
       COALESCE(
         json_agg(
           json_build_object(
             'productId', oi.product_id,
             'productName', oi.product_name,
             'unitPricePence', oi.unit_price_pence,
             'quantity', oi.quantity
           )
           ORDER BY oi.created_at ASC
         ) FILTER (WHERE oi.id IS NOT NULL),
         '[]'::json
       ) AS items
     FROM orders o
     LEFT JOIN order_items oi ON oi.order_id = o.id
     WHERE o.user_id = $1
     GROUP BY o.id
     ORDER BY o.created_at DESC`,
    [req.userId],
  );

  res.json({
    orders: rows.map((row) => ({
      ...mapOrder(row),
      items: Array.isArray(row.items) ? row.items : [],
    })),
  });
}

export async function checkout(req, res) {
  // Checkout supports loyalty values and item lines for order history.
  const {
    merchandiseSubtotalPence,
    deliveryChargePence,
    pointsToRedeem,
    idempotencyKey,
    fulfillmentType,
    items,
  } = req.body ?? {};
  try {
    const out = await completePaidCheckout({
      userId: req.userId,
      merchandiseSubtotalPence,
      deliveryChargePence: deliveryChargePence ?? 0,
      pointsToRedeem: pointsToRedeem ?? 0,
      idempotencyKey: idempotencyKey ?? null,
      fulfillmentType,
      items: Array.isArray(items) ? items : [],
    });
    return res.status(201).json({ order: mapOrder(out.order), duplicate: out.duplicate });
  } catch (e) {
    if (e.code === "INVALID_REDEMPTION") {
      return res.status(400).json({ error: e.message, details: e.details ?? [] });
    }
    throw e;
  }
}

export async function refundOrder(req, res) {
  const client = await pool.connect();
  try {
    const order = await repo.getOrderById(client, req.params.id);
    if (!order || order.user_id !== req.userId) {
      return res.status(404).json({ error: "Order not found." });
    }
  } finally {
    client.release();
  }
  const out = await refundOrCancelPaidOrder(req.params.id, { nextStatus: "refunded" });
  return res.json({ order: mapOrder(out.order), changed: out.changed });
}

export async function cancelOrder(req, res) {
  const client = await pool.connect();
  try {
    const order = await repo.getOrderById(client, req.params.id);
    if (!order || order.user_id !== req.userId) {
      return res.status(404).json({ error: "Order not found." });
    }
  } finally {
    client.release();
  }
  const out = await refundOrCancelPaidOrder(req.params.id, { nextStatus: "cancelled" });
  return res.json({ order: mapOrder(out.order), changed: out.changed });
}
