import { getLoyaltySummary, previewCheckoutRedemption } from "../services/loyaltyService.js";

export async function summary(req, res) {
  const s = await getLoyaltySummary(req.userId);
  return res.json(s);
}

export async function preview(req, res) {
  const { merchandiseSubtotalPence, pointsToRedeem } = req.body ?? {};
  const out = await previewCheckoutRedemption({
    userId: req.userId,
    merchandiseSubtotalPence,
    pointsToRedeem: pointsToRedeem ?? 0,
  });
  return res.status(200).json(out);
}
