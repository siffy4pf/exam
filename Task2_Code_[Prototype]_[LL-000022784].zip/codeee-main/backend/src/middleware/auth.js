import { config } from "../config.js";
import { verifyToken } from "../utils/auth.js";

// Protect routes by validating session cookie token.
export function requireAuth(req, res, next) {
  const token = req.cookies?.[config.cookieName];

  if (!token) {
    return res.status(401).json({ error: "Not authenticated." });
  }

  try {
    const payload = verifyToken(token);
    req.userId = payload.sub;
    return next();
  } catch {
    return res.status(401).json({ error: "Invalid or expired session." });
  }
}
