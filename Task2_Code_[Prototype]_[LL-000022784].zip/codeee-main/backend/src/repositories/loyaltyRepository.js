// Repository layer for loyalty + order SQL queries.
// Keeping SQL in one file makes service/controller code cleaner.
export async function getLedgerBalance(client, userId) {
  const { rows } = await client.query(
    `SELECT COALESCE(SUM(points), 0)::bigint AS b FROM loyalty_transactions WHERE user_id = $1`,
    [userId],
  );
  return Number(rows[0].b);
}

export async function getRedeemableBatchTotal(client, userId, now = new Date()) {
  const { rows } = await client.query(
    `SELECT COALESCE(SUM(points_remaining), 0)::bigint AS s
     FROM loyalty_point_batches
     WHERE user_id = $1 AND expires_at > $2`,
    [userId, now],
  );
  return Number(rows[0].s);
}

export async function insertTransaction(client, { userId, txType, points, orderId, batchId, note }) {
  const { rows } = await client.query(
    `INSERT INTO loyalty_transactions (user_id, tx_type, points, order_id, batch_id, note)
     VALUES ($1, $2, $3, $4, $5, $6)
     RETURNING id`,
    [userId, txType, points, orderId ?? null, batchId ?? null, note ?? null],
  );
  return rows[0].id;
}

export async function insertEarnBatch(client, { userId, sourceOrderId, pointsOriginal, earnedAt, expiresAt }) {
  const { rows } = await client.query(
    `INSERT INTO loyalty_point_batches (user_id, source_order_id, points_original, points_remaining, earned_at, expires_at)
     VALUES ($1, $2, $3, $3, $4, $5)
     RETURNING id`,
    [userId, sourceOrderId, pointsOriginal, earnedAt, expiresAt],
  );
  return rows[0].id;
}

export async function lockBatchesFifo(client, userId, now = new Date()) {
  return client.query(
    `SELECT id, points_remaining, expires_at, earned_at
     FROM loyalty_point_batches
     WHERE user_id = $1 AND points_remaining > 0 AND expires_at > $2
     ORDER BY expires_at ASC, earned_at ASC
     FOR UPDATE`,
    [userId, now],
  );
}

export async function decreaseBatchRemaining(client, batchId, delta) {
  await client.query(
    `UPDATE loyalty_point_batches
     SET points_remaining = points_remaining - $1
     WHERE id = $2 AND points_remaining >= $1`,
    [delta, batchId],
  );
}

export async function clawbackEarnedPointsOnBatch(client, { sourceOrderId, pointsEarned }) {
  await client.query(
    `UPDATE loyalty_point_batches
     SET points_remaining = GREATEST(0, points_remaining - $1)
     WHERE source_order_id = $2`,
    [pointsEarned, sourceOrderId],
  );
}

export async function findBatchesNeedingExpiry(client, now = new Date()) {
  const { rows } = await client.query(
    `SELECT id, user_id, points_remaining
     FROM loyalty_point_batches
     WHERE expires_at <= $1 AND points_remaining > 0
     FOR UPDATE SKIP LOCKED`,
    [now],
  );
  return rows;
}

export async function zeroBatchRemaining(client, batchId) {
  await client.query(`UPDATE loyalty_point_batches SET points_remaining = 0 WHERE id = $1`, [batchId]);
}

export async function findBatchesPendingReminder(client, now = new Date()) {
  const { rows } = await client.query(
    `SELECT b.id, b.user_id, b.points_remaining, b.expires_at, u.email
     FROM loyalty_point_batches b
     JOIN users u ON u.id = b.user_id
     WHERE b.expiry_reminder_sent_at IS NULL
       AND b.points_remaining > 0
       AND b.expires_at > $1`,
    [now],
  );
  return rows;
}

export async function markReminderSent(client, batchId) {
  await client.query(
    `UPDATE loyalty_point_batches SET expiry_reminder_sent_at = NOW() WHERE id = $1`,
    [batchId],
  );
}

export async function insertOrder(client, row) {
  const {
    userId,
    status,
    fulfillmentType,
    merchandiseSubtotalPence,
    deliveryChargePence,
    loyaltyPointsRedeemed,
    loyaltyDiscountPence,
    earnBasePence,
    pointsEarned,
    idempotencyKey,
  } = row;
  const params = [
    userId,
    status,
    fulfillmentType ?? "collection",
    merchandiseSubtotalPence,
    deliveryChargePence,
    loyaltyPointsRedeemed,
    loyaltyDiscountPence,
    earnBasePence,
    pointsEarned,
    idempotencyKey ?? null,
  ];
  // Idempotency key avoids duplicate checkout rows if the same request is retried.
  if (idempotencyKey) {
    const { rows } = await client.query(
      `INSERT INTO orders (
         user_id, status, fulfillment_type, merchandise_subtotal_pence, delivery_charge_pence,
         loyalty_points_redeemed, loyalty_discount_pence, earn_base_pence, points_earned, idempotency_key
       ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
       ON CONFLICT (idempotency_key) DO NOTHING
       RETURNING *`,
      params,
    );
    return rows[0] ?? null;
  }
  const { rows } = await client.query(
    `INSERT INTO orders (
       user_id, status, fulfillment_type, merchandise_subtotal_pence, delivery_charge_pence,
       loyalty_points_redeemed, loyalty_discount_pence, earn_base_pence, points_earned, idempotency_key
     ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
     RETURNING *`,
    params,
  );
  return rows[0] ?? null;
}

export async function getOrderById(client, orderId) {
  const { rows } = await client.query(`SELECT * FROM orders WHERE id = $1`, [orderId]);
  return rows[0] ?? null;
}

export async function getOrderByIdempotencyKey(client, key) {
  if (!key) return null;
  const { rows } = await client.query(`SELECT * FROM orders WHERE idempotency_key = $1`, [key]);
  return rows[0] ?? null;
}

export async function updateOrderStatus(client, orderId, status) {
  await client.query(`UPDATE orders SET status = $2, updated_at = NOW() WHERE id = $1`, [orderId, status]);
}

export async function insertOrderItems(client, { orderId, items }) {
  for (const item of items) {
    await client.query(
      `INSERT INTO order_items (order_id, product_id, product_name, unit_price_pence, quantity)
       VALUES ($1, $2, $3, $4, $5)`,
      [
        orderId,
        item.productId ?? null,
        item.productName,
        item.unitPricePence,
        item.quantity,
      ],
    );
  }
}
