import { query } from "../db.js";

export async function listByProducerUserId(producerUserId) {
  const result = await query(
    `SELECT id, producer_id AS producer_user_id, name, stock, price_pence, created_at, updated_at
     FROM products
     WHERE producer_id = $1
     ORDER BY created_at DESC`,
    [producerUserId],
  );
  return result.rows;
}

export async function createForProducer({ producerUserId, name, stock, pricePence }) {
  const result = await query(
    `INSERT INTO products (producer_id, name, description, category, price_pence, stock, image_url, is_active)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
     RETURNING id, producer_id AS producer_user_id, name, stock, price_pence, created_at, updated_at`,
    [producerUserId, name, "", "other", pricePence, stock, "", true],
  );
  return result.rows[0];
}

export async function updateStockForProducer({ producerUserId, productId, stock }) {
  const result = await query(
    `UPDATE products
     SET stock = $3, updated_at = NOW()
     WHERE id = $1 AND producer_id = $2
     RETURNING id, producer_id AS producer_user_id, name, stock, price_pence, created_at, updated_at`,
    [productId, producerUserId, stock],
  );
  return result.rows[0] ?? null;
}
