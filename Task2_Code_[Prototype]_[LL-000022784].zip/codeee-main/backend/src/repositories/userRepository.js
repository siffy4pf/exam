import { query } from "../db.js";

export async function findUserByEmail(email) {
  const result = await query(
    `SELECT id, email, full_name, password_hash, role, created_at, updated_at
     FROM users
     WHERE email = $1`,
    [email.toLowerCase()],
  );
  return result.rows[0] ?? null;
}

export async function findUserById(id) {
  const result = await query(
    `SELECT id, email, full_name, role, created_at, updated_at
     FROM users
     WHERE id = $1`,
    [id],
  );
  return result.rows[0] ?? null;
}

export async function createUser({ email, fullName, passwordHash, role = "customer" }) {
  const result = await query(
    `INSERT INTO users (email, full_name, password_hash, role)
     VALUES ($1, $2, $3, $4)
     RETURNING id, email, full_name, role, created_at, updated_at`,
    [email.toLowerCase(), fullName, passwordHash, role],
  );

  return result.rows[0];
}

export async function updatePassword({ userId, passwordHash }) {
  const result = await query(
    `UPDATE users
     SET password_hash = $2, updated_at = NOW()
     WHERE id = $1
     RETURNING id`,
    [userId, passwordHash],
  );
  return result.rowCount > 0;
}

export async function getUserAccountSettings(userId) {
  // Read saved payment and address fields for one account.
  const result = await query(
    `SELECT
      user_id,
      bank_account_name,
      bank_sort_code,
      bank_account_number,
      address_line1,
      address_line2,
      address_city,
      address_postcode,
      address_phone
     FROM user_account_settings
     WHERE user_id = $1`,
    [userId],
  );
  return result.rows[0] ?? null;
}

export async function upsertUserAccountSettings(userId, payload) {
  // Upsert keeps one profile row per user and updates safely.
  const result = await query(
    `INSERT INTO user_account_settings (
      user_id,
      bank_account_name,
      bank_sort_code,
      bank_account_number,
      address_line1,
      address_line2,
      address_city,
      address_postcode,
      address_phone
    )
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
    ON CONFLICT (user_id) DO UPDATE SET
      bank_account_name = EXCLUDED.bank_account_name,
      bank_sort_code = EXCLUDED.bank_sort_code,
      bank_account_number = EXCLUDED.bank_account_number,
      address_line1 = EXCLUDED.address_line1,
      address_line2 = EXCLUDED.address_line2,
      address_city = EXCLUDED.address_city,
      address_postcode = EXCLUDED.address_postcode,
      address_phone = EXCLUDED.address_phone,
      updated_at = NOW()
    RETURNING
      user_id,
      bank_account_name,
      bank_sort_code,
      bank_account_number,
      address_line1,
      address_line2,
      address_city,
      address_postcode,
      address_phone`,
    [
      userId,
      payload.bankAccountName ?? null,
      payload.bankSortCode ?? null,
      payload.bankAccountNumber ?? null,
      payload.addressLine1 ?? null,
      payload.addressLine2 ?? null,
      payload.addressCity ?? null,
      payload.addressPostcode ?? null,
      payload.addressPhone ?? null,
    ],
  );
  return result.rows[0] ?? null;
}
