/** Passes rejected async controller errors to Express `next` so the error middleware runs. */
export function asyncHandler(handler) {
  return (req, res, next) => {
    Promise.resolve(handler(req, res, next)).catch(next);
  };
}
