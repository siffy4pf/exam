import { Pool } from "pg";
import { config } from "./config.js";

// Shared Postgres pool used by repositories.
export const pool = new Pool({
  connectionString: config.databaseUrl,
});

export async function query(text, params = []) {
  // Small helper to keep imports cleaner in repository files.
  return pool.query(text, params);
}
