import cors from "cors";
import cookieParser from "cookie-parser";
import express from "express";
import { config } from "./config.js";
import { authRouter } from "./routes/authRoutes.js";
import { loyaltyRouter } from "./routes/loyaltyRoutes.js";
import { orderRouter } from "./routes/orderRoutes.js";
import { productRouter } from "./routes/productRoutes.js";

// Express app setup: middleware, route registration, and global error handling.
export const app = express();

const allowedOrigins = new Set([
  config.clientOrigin,
  "http://localhost:8080",
  "http://127.0.0.1:8080",
  "http://localhost:8081",
  "http://127.0.0.1:8081",
  // Vite with host "::" often uses IPv6 loopback in the Origin header
  "http://[::1]:8080",
  "http://[::1]:8081",
]);

function isLikelyLocalDevOrigin(origin) {
  if (!origin || config.isProduction) return false;
  try {
    const u = new URL(origin);
    const port = u.port || "80";
    const okPort = ["8080", "8081", "5173", "4173"].includes(port);
    const h = u.hostname;
    const okHost =
      h === "localhost" ||
      h === "127.0.0.1" ||
      h === "::1" ||
      h === "[::1]" ||
      /^192\.168\.\d{1,3}\.\d{1,3}$/.test(h) ||
      /^10\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(h);
    return okHost && okPort;
  } catch {
    return false;
  }
}

app.use(
  cors({
    origin(origin, callback) {
      if (!origin || allowedOrigins.has(origin) || isLikelyLocalDevOrigin(origin)) {
        callback(null, true);
        return;
      }
      callback(new Error(`CORS blocked for origin: ${origin}`));
    },
    credentials: true,
  }),
);
app.use(express.json());
app.use(cookieParser());

app.get("/health", (_req, res) => {
  res.status(200).json({ status: "ok" });
});

// Feature routes
app.use("/auth", authRouter);
app.use("/loyalty", loyaltyRouter);
app.use("/orders", orderRouter);
app.use("/products", productRouter);

app.use((err, _req, res, _next) => {
  console.error(err);
  const message =
    process.env.NODE_ENV === "production" ? "Server error." : err?.message || "Server error.";
  res.status(500).json({ error: message });
});
