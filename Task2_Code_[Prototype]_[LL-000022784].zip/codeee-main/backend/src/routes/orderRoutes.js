import { Router } from "express";
import { requireAuth } from "../middleware/auth.js";
import * as orderController from "../controllers/orderController.js";
import { asyncHandler } from "../utils/asyncHandler.js";

// Order routes for checkout and account order history.
export const orderRouter = Router();

orderRouter.get("/mine", requireAuth, asyncHandler(orderController.listMyOrders));
orderRouter.post("/checkout", requireAuth, asyncHandler(orderController.checkout));
orderRouter.post("/:id/refund", requireAuth, asyncHandler(orderController.refundOrder));
orderRouter.post("/:id/cancel", requireAuth, asyncHandler(orderController.cancelOrder));
