import { Router } from "express";
import { requireAuth } from "../middleware/auth.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import * as productController from "../controllers/productController.js";

// Product routes used by producer dashboard CRUD.
export const productRouter = Router();

productRouter.get("/mine", requireAuth, asyncHandler(productController.listMyProducts));
productRouter.post("/mine", requireAuth, asyncHandler(productController.createMyProduct));
productRouter.patch("/:id/stock", requireAuth, asyncHandler(productController.updateMyProductStock));
