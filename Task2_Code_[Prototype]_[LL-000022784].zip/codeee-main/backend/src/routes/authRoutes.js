import { Router } from "express";
import { changePassword, getProfile, login, logout, session, signUp, updateProfile } from "../controllers/authController.js";
import { requireAuth } from "../middleware/auth.js";
import { asyncHandler } from "../utils/asyncHandler.js";

export const authRouter = Router();

authRouter.post("/signup", asyncHandler(signUp));
authRouter.post("/login", asyncHandler(login));
authRouter.post("/logout", asyncHandler(logout));
authRouter.get("/session", requireAuth, asyncHandler(session));
authRouter.post("/change-password", requireAuth, asyncHandler(changePassword));
authRouter.get("/profile", requireAuth, asyncHandler(getProfile));
authRouter.put("/profile", requireAuth, asyncHandler(updateProfile));
