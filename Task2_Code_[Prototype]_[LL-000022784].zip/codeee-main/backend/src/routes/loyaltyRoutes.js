import { Router } from "express";
import { requireAuth } from "../middleware/auth.js";
import * as loyaltyController from "../controllers/loyaltyController.js";
import { asyncHandler } from "../utils/asyncHandler.js";

export const loyaltyRouter = Router();

loyaltyRouter.get("/summary", requireAuth, asyncHandler(loyaltyController.summary));
loyaltyRouter.post("/preview", requireAuth, asyncHandler(loyaltyController.preview));
