-- Two account types: customer (shop only) and producer (shop + sell / dashboard).
UPDATE users SET role = 'producer' WHERE LOWER(TRIM(role)) = 'producer';
UPDATE users SET role = 'customer' WHERE role IS NULL OR LOWER(TRIM(role)) NOT IN ('customer', 'producer');

ALTER TABLE users DROP CONSTRAINT IF EXISTS users_role_check;
ALTER TABLE users ADD CONSTRAINT users_role_check CHECK (role IN ('customer', 'producer'));

ALTER TABLE users ALTER COLUMN role SET DEFAULT 'customer';
