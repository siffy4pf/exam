DO $$
DECLARE
  constraint_name TEXT;
BEGIN
  FOR constraint_name IN
    SELECT c.conname
    FROM pg_constraint c
    JOIN pg_class t ON t.oid = c.conrelid
    WHERE t.relname = 'orders'
      AND c.contype = 'c'
      AND pg_get_constraintdef(c.oid) ILIKE '%status%'
  LOOP
    EXECUTE format('ALTER TABLE orders DROP CONSTRAINT IF EXISTS %I', constraint_name);
  END LOOP;
END
$$;

UPDATE orders
SET status = CASE
  WHEN LOWER(TRIM(status)) IN ('paid', 'completed', 'complete', 'done') THEN 'paid'
  WHEN LOWER(TRIM(status)) IN ('cancelled', 'canceled') THEN 'cancelled'
  WHEN LOWER(TRIM(status)) IN ('refunded', 'refund') THEN 'refunded'
  ELSE 'paid'
END;

ALTER TABLE orders
ADD CONSTRAINT orders_status_check
CHECK (status IN ('paid', 'cancelled', 'refunded', 'pending', 'ready', 'dispatched'));
