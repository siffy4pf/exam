ALTER TABLE orders
ADD COLUMN IF NOT EXISTS fulfillment_type TEXT;

UPDATE orders
SET fulfillment_type = CASE
  WHEN COALESCE(delivery_charge_pence, 0) > 0 THEN 'delivery'
  ELSE 'collection'
END
WHERE fulfillment_type IS NULL OR TRIM(fulfillment_type) = '';

ALTER TABLE orders
ALTER COLUMN fulfillment_type SET DEFAULT 'collection';

ALTER TABLE orders
ALTER COLUMN fulfillment_type SET NOT NULL;

ALTER TABLE orders
DROP CONSTRAINT IF EXISTS orders_fulfillment_type_check;

ALTER TABLE orders
ADD CONSTRAINT orders_fulfillment_type_check
CHECK (fulfillment_type IN ('collection', 'delivery'));

DO $$
DECLARE
  constraint_name TEXT;
BEGIN
  FOR constraint_name IN
    SELECT c.conname
    FROM pg_constraint c
    JOIN pg_class t ON t.oid = c.conrelid
    WHERE t.relname = 'orders'
      AND c.contype = 'c'
      AND c.conname = 'orders_status_check'
  LOOP
    EXECUTE format('ALTER TABLE orders DROP CONSTRAINT IF EXISTS %I', constraint_name);
  END LOOP;
END
$$;

ALTER TABLE orders
ADD CONSTRAINT orders_status_check
CHECK (status IN ('paid', 'cancelled', 'refunded', 'pending', 'ready', 'dispatched', 'delivered', 'collected'));
