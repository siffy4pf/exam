CREATE TABLE IF NOT EXISTS user_account_settings (
  user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  bank_account_name TEXT,
  bank_sort_code TEXT,
  bank_account_number TEXT,
  address_line1 TEXT,
  address_line2 TEXT,
  address_city TEXT,
  address_postcode TEXT,
  address_phone TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

