CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  producer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL CHECK (char_length(trim(name)) > 0),
  stock INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
  price_pence INTEGER NOT NULL CHECK (price_pence > 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE products ADD COLUMN IF NOT EXISTS producer_id UUID;
ALTER TABLE products ADD COLUMN IF NOT EXISTS name TEXT;
ALTER TABLE products ADD COLUMN IF NOT EXISTS stock INTEGER DEFAULT 0;
ALTER TABLE products ADD COLUMN IF NOT EXISTS price_pence INTEGER;
ALTER TABLE products ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT NOW();
ALTER TABLE products ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

UPDATE products
SET name = COALESCE(NULLIF(TRIM(name), ''), 'Untitled Product')
WHERE name IS NULL OR TRIM(name) = '';

UPDATE products
SET stock = 0
WHERE stock IS NULL OR stock < 0;

UPDATE products
SET updated_at = NOW()
WHERE updated_at IS NULL;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'products_producer_id_fkey'
  ) THEN
    ALTER TABLE products
    ADD CONSTRAINT products_producer_id_fkey
    FOREIGN KEY (producer_id) REFERENCES users(id) ON DELETE CASCADE;
  END IF;
END
$$;

CREATE INDEX IF NOT EXISTS idx_products_producer_id
  ON products (producer_id, created_at DESC);
