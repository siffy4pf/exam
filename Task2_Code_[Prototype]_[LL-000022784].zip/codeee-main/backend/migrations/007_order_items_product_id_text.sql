DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_name = 'order_items'
      AND column_name = 'product_id'
      AND data_type = 'uuid'
  ) THEN
    ALTER TABLE order_items
    DROP CONSTRAINT IF EXISTS order_items_product_id_fkey;

    ALTER TABLE order_items
    ALTER COLUMN product_id TYPE TEXT USING product_id::text;
  END IF;
END
$$;
