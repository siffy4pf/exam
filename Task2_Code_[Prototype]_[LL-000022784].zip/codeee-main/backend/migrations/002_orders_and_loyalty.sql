-- Orders (paid checkout) for loyalty earn / refund linkage
CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  status TEXT NOT NULL CHECK (status IN ('paid', 'cancelled', 'refunded')),
  merchandise_subtotal_pence INT NOT NULL CHECK (merchandise_subtotal_pence >= 0),
  delivery_charge_pence INT NOT NULL DEFAULT 0 CHECK (delivery_charge_pence >= 0),
  loyalty_points_redeemed INT NOT NULL DEFAULT 0 CHECK (loyalty_points_redeemed >= 0),
  loyalty_discount_pence INT NOT NULL DEFAULT 0 CHECK (loyalty_discount_pence >= 0),
  earn_base_pence INT NOT NULL DEFAULT 0 CHECK (earn_base_pence >= 0),
  points_earned INT NOT NULL DEFAULT 0 CHECK (points_earned >= 0),
  idempotency_key TEXT UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS orders_user_id_idx ON orders (user_id);
CREATE INDEX IF NOT EXISTS orders_status_idx ON orders (status);

-- FIFO pools for non-expired redeemable points + expiry reminders
CREATE TABLE IF NOT EXISTS loyalty_point_batches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  source_order_id UUID REFERENCES orders (id) ON DELETE SET NULL,
  points_original INT NOT NULL CHECK (points_original > 0),
  points_remaining INT NOT NULL CHECK (points_remaining >= 0),
  earned_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at TIMESTAMPTZ NOT NULL,
  expiry_reminder_sent_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS loyalty_batches_user_fifo_idx ON loyalty_point_batches (user_id, expires_at, earned_at);
CREATE INDEX IF NOT EXISTS loyalty_batches_expiry_idx ON loyalty_point_batches (expires_at);

-- Append-only audit log; balance = SUM(points) per user (may be negative)
CREATE TABLE IF NOT EXISTS loyalty_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  tx_type TEXT NOT NULL CHECK (tx_type IN ('earn', 'redeem', 'expire', 'refund_clawback')),
  points INT NOT NULL,
  order_id UUID REFERENCES orders (id) ON DELETE SET NULL,
  batch_id UUID REFERENCES loyalty_point_batches (id) ON DELETE SET NULL,
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS loyalty_tx_user_idx ON loyalty_transactions (user_id, created_at);
