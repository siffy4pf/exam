CREATE TABLE IF NOT EXISTS order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id TEXT,
  product_name TEXT NOT NULL,
  unit_price_pence INTEGER NOT NULL CHECK (unit_price_pence >= 0),
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE order_items ADD COLUMN IF NOT EXISTS product_id TEXT;
ALTER TABLE order_items ADD COLUMN IF NOT EXISTS product_name TEXT;
ALTER TABLE order_items ADD COLUMN IF NOT EXISTS unit_price_pence INTEGER;
ALTER TABLE order_items ADD COLUMN IF NOT EXISTS quantity INTEGER;
ALTER TABLE order_items ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT NOW();

UPDATE order_items
SET product_name = COALESCE(NULLIF(TRIM(product_name), ''), 'Unknown product')
WHERE product_name IS NULL OR TRIM(product_name) = '';

UPDATE order_items
SET unit_price_pence = 0
WHERE unit_price_pence IS NULL OR unit_price_pence < 0;

UPDATE order_items
SET quantity = 1
WHERE quantity IS NULL OR quantity <= 0;

CREATE INDEX IF NOT EXISTS order_items_order_id_idx ON order_items(order_id);
