import { useCart } from "@/context/CartContext";
import { Gift } from "lucide-react";

export default function LoyaltyBanner() {
  const { redeemablePoints, ledgerBalance } = useCart();
  const worth = (redeemablePoints / 100).toFixed(2);

  return (
    <div className="mx-auto max-w-3xl my-6 px-4">
      <div className="relative overflow-hidden bg-gradient-to-r from-accent via-loyalty-bg to-accent rounded-2xl border border-loyalty-border/30 py-3 px-5 shadow-elegant">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-primary/5 via-transparent to-primary/5" />
        <div className="relative flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-2 text-center">
          <Gift className="h-4 w-4 text-primary animate-pulse-soft flex-shrink-0" />
          <p className="text-accent-foreground font-semibold text-sm">
            <span className="font-extrabold text-primary">{redeemablePoints}</span> points available at checkout
            {redeemablePoints > 0 ? (
              <>
                {" "}
                — up to <span className="font-extrabold text-primary">£{worth}</span> off (75-point steps, max £7.50 per order).
              </>
            ) : (
              <> — earn 10 points per £1 on paid orders (points expire after 12 months).</>
            )}
          </p>
          {ledgerBalance !== redeemablePoints && (
            <p className="text-[11px] text-muted-foreground font-medium">
              Account balance (incl. adjustments): {ledgerBalance} pts
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
