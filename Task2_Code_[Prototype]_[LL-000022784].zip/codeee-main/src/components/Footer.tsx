import { Link } from "react-router-dom";
import { Leaf } from "lucide-react";
import { useAuth } from "@/context/AuthContext";

export default function Footer() {
  const { user } = useAuth();

  const quickMiddle =
    user?.role === "producer"
      ? [{ to: "/dashboard", label: "Producer Dashboard" }]
      : [{ to: "/account?mode=register&role=producer", label: "Become a producer" }];

  return (
    <footer className="bg-gradient-to-b from-primary-dark to-primary-dark/95 text-primary-foreground pt-10 pb-6 mt-auto">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Leaf className="h-5 w-5 text-primary-light" />
              <span className="font-serif font-bold text-lg">Local Produce Hub</span>
            </div>
            <p className="text-primary-foreground/60 text-sm leading-relaxed">
              A cooperative of local farmers and food producers bringing fresh, traceable produce to your table.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold text-sm uppercase tracking-wider text-primary-foreground/80 mb-3">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              {[
                { to: "/about", label: "About GLH" },
                { to: "/contact", label: "Contact Us" },
                ...quickMiddle,
              ].map((link) => (
                <li key={link.to}>
                  <Link to={link.to} className="text-primary-foreground/60 hover:text-primary-foreground transition-colors duration-200">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="font-bold text-sm uppercase tracking-wider text-primary-foreground/80 mb-3">Legal</h4>
            <ul className="space-y-2 text-sm">
              {[
                { to: "/privacy", label: "Privacy Policy" },
                { to: "/accessibility", label: "Accessibility Statement" },
              ].map((link) => (
                <li key={link.to}>
                  <Link to={link.to} className="text-primary-foreground/60 hover:text-primary-foreground transition-colors duration-200">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-primary-foreground/10 pt-4">
          <p className="text-center text-xs text-primary-foreground/40">
            © 2026 Greenfield Local Hub. All rights reserved. | Farm-to-fork traceability in every order.
          </p>
        </div>
      </div>
    </footer>
  );
}
