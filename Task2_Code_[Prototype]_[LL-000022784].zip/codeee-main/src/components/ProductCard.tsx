import { Link } from "react-router-dom";
import type { Product } from "@/data/products";
import { getStockStatus } from "@/data/products";
import StockBadge from "./StockBadge";
import { useCart } from "@/context/CartContext";
import { toast } from "sonner";
import { Plus, MapPin } from "lucide-react";

export default function ProductCard({ product }: { product: Product }) {
  const { addToCart } = useCart();
  const status = getStockStatus(product.stock);

  const handleAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (status === "out-of-stock") return;
    addToCart(product);
    toast.success(`${product.name} added to basket`);
  };

  return (
    <Link to={`/product/${product.id}`} className="block">
      <article className="group bg-card border border-border rounded-2xl overflow-hidden hover-lift shadow-sm">
        <div className="relative overflow-hidden">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-44 object-cover transition-transform duration-500 group-hover:scale-110"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-foreground/30 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          <div className="absolute top-3 right-3">
            <StockBadge stock={product.stock} />
          </div>
          <div className="absolute bottom-3 left-3 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-2 group-hover:translate-y-0">
            <span className="text-xs font-semibold text-primary-foreground bg-foreground/60 backdrop-blur-sm px-2 py-1 rounded-full flex items-center gap-1">
              <MapPin className="h-3 w-3" />
              Local
            </span>
          </div>
        </div>
        <div className="p-4">
          <div className="flex items-start justify-between gap-2">
            <div>
              <h3 className="font-bold text-foreground text-base leading-tight">{product.name}</h3>
              <p className="text-muted-foreground text-xs mt-0.5">{product.producer}</p>
            </div>
            <p className="text-primary font-extrabold text-lg">£{product.price.toFixed(2)}</p>
          </div>
          <button
            onClick={handleAdd}
            disabled={status === "out-of-stock"}
            className="mt-3 w-full bg-gradient-to-r from-primary to-primary-light text-primary-foreground font-bold text-sm py-2.5 rounded-xl hover:shadow-glow transition-all duration-300 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:shadow-none flex items-center justify-center gap-1.5 active:scale-[0.98]"
            aria-label={`Add ${product.name} to basket`}
          >
            <Plus className="h-4 w-4" />
            {status === "out-of-stock" ? "Out of Stock" : "Add to Basket"}
          </button>
        </div>
      </article>
    </Link>
  );
}
