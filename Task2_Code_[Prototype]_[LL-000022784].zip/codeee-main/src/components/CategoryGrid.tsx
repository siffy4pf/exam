import vegetablesImg from "@/assets/categories/vegetables.jpg";
import bakeryImg from "@/assets/categories/bakery.jpg";
import dairyImg from "@/assets/categories/dairy.jpg";
import preservesImg from "@/assets/categories/preserves.jpg";
import meatImg from "@/assets/categories/meat.jpg";

interface CategoryGridProps {
  onCategorySelect: (category: string) => void;
}

const categoryData = [
  { name: "Vegetables", image: vegetablesImg, count: 3 },
  { name: "Bakery", image: bakeryImg, count: 2 },
  { name: "Dairy & Eggs", image: dairyImg, count: 2 },
  { name: "Preserves", image: preservesImg, count: 3 },
  { name: "Meat", image: meatImg, count: 3 },
];

export default function CategoryGrid({ onCategorySelect }: CategoryGridProps) {
  return (
    <section className="py-10">
      <div className="flex items-end justify-between mb-6">
        <div>
          <p className="text-primary font-bold text-sm uppercase tracking-wider mb-1">Browse by</p>
          <h2 className="text-2xl md:text-3xl font-bold font-serif">Categories</h2>
        </div>
        <button
          onClick={() => onCategorySelect("All")}
          className="text-sm font-semibold text-primary hover:underline"
        >
          View all →
        </button>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        {categoryData.map((cat) => (
          <button
            key={cat.name}
            onClick={() => onCategorySelect(cat.name)}
            className="group relative h-44 md:h-52 rounded-2xl overflow-hidden hover-lift cursor-pointer"
          >
            <img
              src={cat.image}
              alt={cat.name}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-foreground/70 via-foreground/20 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-4">
              <h3 className="text-primary-foreground font-bold text-lg drop-shadow-md">{cat.name}</h3>
              <p className="text-primary-foreground/70 text-xs">{cat.count} products</p>
            </div>
          </button>
        ))}
      </div>
    </section>
  );
}
