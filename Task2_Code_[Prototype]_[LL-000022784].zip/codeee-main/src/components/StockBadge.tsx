import { getStockStatus } from "@/data/products";

export default function StockBadge({ stock }: { stock: number }) {
  const status = getStockStatus(stock);

  const styles = {
    "in-stock": "bg-success/90 text-success-foreground backdrop-blur-sm",
    "low-stock": "bg-warning/90 text-warning-foreground backdrop-blur-sm",
    "out-of-stock": "bg-destructive/90 text-destructive-foreground backdrop-blur-sm",
  };

  const labels = {
    "in-stock": "In Stock",
    "low-stock": "Low Stock",
    "out-of-stock": "Out of Stock",
  };

  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold shadow-sm ${styles[status]}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${
        status === "in-stock" ? "bg-success-foreground" :
        status === "low-stock" ? "bg-warning-foreground animate-pulse-soft" :
        "bg-destructive-foreground"
      }`} />
      {labels[status]}
    </span>
  );
}
