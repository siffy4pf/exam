import { categories, dietaryOptions, producers } from "@/data/products";
import { SlidersHorizontal } from "lucide-react";

interface FilterBarProps {
  category: string;
  dietary: string;
  producer: string;
  inStockOnly: boolean;
  onCategoryChange: (v: string) => void;
  onDietaryChange: (v: string) => void;
  onProducerChange: (v: string) => void;
  onInStockChange: (v: boolean) => void;
}

export default function FilterBar({
  category,
  dietary,
  producer,
  inStockOnly,
  onCategoryChange,
  onDietaryChange,
  onProducerChange,
  onInStockChange,
}: FilterBarProps) {
  const selectClass =
    "bg-card text-foreground border border-border rounded-xl px-4 py-2.5 text-sm font-semibold focus:ring-2 focus:ring-ring focus:border-primary outline-none transition-all duration-200 cursor-pointer hover:border-primary/50 shadow-sm appearance-none";

  return (
    <div className="flex flex-wrap items-center gap-3 py-4 animate-fade-in">
      <div className="flex items-center gap-2 text-muted-foreground mr-1">
        <SlidersHorizontal className="h-4 w-4" />
        <span className="text-sm font-bold hidden sm:inline">Filters</span>
      </div>
      <select className={selectClass} value={category} onChange={(e) => onCategoryChange(e.target.value)} aria-label="Filter by category">
        {categories.map((c) => (
          <option key={c} value={c}>{c === "All" ? "All Categories" : c}</option>
        ))}
      </select>
      <select className={selectClass} value={dietary} onChange={(e) => onDietaryChange(e.target.value)} aria-label="Filter by dietary needs">
        {dietaryOptions.map((d) => (
          <option key={d} value={d}>{d === "All" ? "Dietary Needs" : d}</option>
        ))}
      </select>
      <select className={selectClass} value={producer} onChange={(e) => onProducerChange(e.target.value)} aria-label="Filter by producer">
        {producers.map((p) => (
          <option key={p} value={p}>{p === "All" ? "All Producers" : p}</option>
        ))}
      </select>
      <label className="flex items-center gap-2 text-sm font-semibold text-foreground cursor-pointer bg-card border border-border rounded-xl px-4 py-2.5 hover:border-primary/50 transition-all duration-200 shadow-sm">
        <input
          type="checkbox"
          checked={inStockOnly}
          onChange={(e) => onInStockChange(e.target.checked)}
          className="accent-primary w-4 h-4 rounded"
        />
        In Stock Only
      </label>
    </div>
  );
}
