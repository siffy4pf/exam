import heroImg from "@/assets/hero-farm.jpg";
import { Leaf, Truck, ShieldCheck } from "lucide-react";

export default function HeroBanner() {
  return (
    <section className="relative w-full overflow-hidden">
      {/* Main hero */}
      <div className="relative h-64 md:h-80 lg:h-96">
        <img
          src={heroImg}
          alt="Beautiful countryside farmland at sunrise"
          className="w-full h-full object-cover scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-primary-dark/80 via-primary/60 to-background/90" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-4">
          <h1 className="text-primary-foreground text-4xl md:text-5xl lg:text-6xl font-bold mb-3 animate-fade-up drop-shadow-lg">
            Shop Fresh, Shop Local
          </h1>
          <p className="text-primary-foreground/85 text-base md:text-lg max-w-xl animate-fade-up" style={{ animationDelay: "150ms" }}>
            Supporting local farmers and producers in your community
          </p>
          <a
            href="#products"
            className="mt-6 bg-card text-primary font-bold px-8 py-3 rounded-full hover:bg-card/90 transition-all duration-300 hover:shadow-lg hover:scale-105 animate-fade-up"
            style={{ animationDelay: "300ms" }}
          >
            Browse Products
          </a>
        </div>
      </div>

      {/* Feature strip */}
      <div className="relative -mt-6 z-10 container mx-auto px-4">
        <div className="glass rounded-2xl border border-border/50 shadow-elegant p-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { icon: Leaf, title: "100% Local", desc: "Every product sourced within 30 miles" },
            { icon: Truck, title: "Collection & Delivery", desc: "Flexible slots to suit your schedule" },
            { icon: ShieldCheck, title: "Full Traceability", desc: "Know exactly where your food comes from" },
          ].map((f, i) => (
            <div
              key={f.title}
              className="flex items-center gap-3 p-2 rounded-xl hover:bg-accent/50 transition-colors duration-200 animate-fade-up"
              style={{ animationDelay: `${400 + i * 100}ms` }}
            >
              <div className="bg-accent rounded-xl p-2.5 flex-shrink-0">
                <f.icon className="h-5 w-5 text-accent-foreground" />
              </div>
              <div>
                <p className="font-bold text-sm text-foreground">{f.title}</p>
                <p className="text-xs text-muted-foreground">{f.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
