import { Link, useNavigate } from "react-router-dom";
import { ShoppingBasket, Search, LayoutDashboard, LogIn, UserPlus, LogOut, MapPin, UserCircle2, ClipboardList } from "lucide-react";
import ThemeToggle from "@/components/ThemeToggle";
import { useCart } from "@/context/CartContext";
import { useAuth } from "@/context/AuthContext";
import { useState, useRef, useEffect, useMemo } from "react";
import { toast } from "sonner";
import { products } from "@/data/products";

// Top navigation bar: search, auth links, and basket summary.
const logo = "/favicon-glh.svg";

interface NavbarProps {
  onSearch?: (query: string) => void;
}

export default function Navbar({ onSearch }: NavbarProps) {
  const { totalItems } = useCart();
  const { user, signOut } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [showPreview, setShowPreview] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  const results = useMemo(() => {
    // Quick search preview in navbar (first 5 matches).
    if (!searchQuery.trim()) return [];
    const q = searchQuery.toLowerCase();
    return products
      .filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.producer.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q)
      )
      .slice(0, 5);
  }, [searchQuery]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setShowPreview(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchQuery(value);
    setShowPreview(value.trim().length > 0);
    if (onSearch) {
      onSearch(value);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setShowPreview(false);
      navigate(`/products?search=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const handleViewAllResults = () => {
    if (!searchQuery.trim()) return;
    setShowPreview(false);
    navigate(`/products?search=${encodeURIComponent(searchQuery.trim())}`);
  };

  const handleSelectProduct = (productId: string) => {
    setShowPreview(false);
    setSearchQuery("");
    navigate(`/product/${productId}`);
  };

  const handleSignOut = async () => {
    // Sign out and show a quick confirmation toast.
    await signOut();
    toast.success("Signed out successfully!");
  };

  return (
    <nav className="bg-gradient-to-r from-primary-dark via-primary to-primary-dark sticky top-0 z-50 shadow-lg border-b border-primary-light/20">
      <div className="container mx-auto flex items-center justify-between px-4 py-3">
        <Link to="/" className="flex items-center gap-2.5 text-primary-foreground font-serif text-xl font-bold group">
          <img
            src={logo}
            alt="GLH Logo"
            className="h-10 w-10 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3"
          />
          <span className="tracking-tight">Local Produce Hub</span>
        </Link>

        <div ref={searchRef} className="hidden md:block relative">
          <form onSubmit={handleSearchSubmit} className="flex items-center glass rounded-full px-4 py-2 w-80 border border-primary-foreground/10 transition-all duration-300 focus-within:w-96 focus-within:border-primary-foreground/30">
            <Search className="h-4 w-4 text-muted-foreground mr-2 flex-shrink-0" />
            <input
              type="text"
              placeholder="Search local produce..."
              className="bg-transparent outline-none text-sm w-full text-foreground placeholder:text-muted-foreground"
              value={searchQuery}
              onChange={handleSearch}
              onFocus={() => searchQuery.trim() && setShowPreview(true)}
              aria-label="Search local produce"
            />
          </form>

          {showPreview && searchQuery.trim() && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-popover border border-border rounded-xl shadow-lg overflow-hidden z-50 animate-fade-in">
              {results.length > 0 ? (
                <>
                  {results.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => handleSelectProduct(p.id)}
                      className="w-full flex items-center gap-3 px-4 py-3 hover:bg-accent/50 transition-colors text-left border-b border-border/30 last:border-b-0"
                    >
                      <img
                        src={p.image}
                        alt={p.name}
                        className="w-10 h-10 rounded-lg object-cover flex-shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-foreground truncate">{p.name}</p>
                        <p className="text-xs text-muted-foreground flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          {p.producer}
                        </p>
                      </div>
                      <span className="text-sm font-bold text-primary flex-shrink-0">
                        £{p.price.toFixed(2)}
                      </span>
                    </button>
                  ))}
                  <button
                    onClick={handleViewAllResults}
                    className="w-full px-4 py-2.5 text-xs font-bold text-primary hover:bg-accent/30 transition-colors text-center"
                  >
                    View all results for "{searchQuery}" →
                  </button>
                </>
              ) : (
                <div className="px-4 py-6 text-center">
                  <p className="text-sm text-muted-foreground font-semibold">No products found</p>
                  <p className="text-xs text-muted-foreground/60 mt-1">Try a different search term</p>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="flex items-center gap-1">
          <ThemeToggle />
          {user ? (
            <>
              {user.role === "producer" && (
                <Link
                  to="/dashboard"
                  className="text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/10 flex items-center gap-1.5 text-sm font-semibold px-3 py-2 rounded-full transition-all duration-200"
                  aria-label="Producer Dashboard"
                >
                  <LayoutDashboard className="h-4.5 w-4.5" />
                  <span className="hidden lg:inline">Dashboard</span>
                </Link>
              )}
              <Link
                to="/account/orders"
                className="text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/10 flex items-center gap-1.5 text-sm font-semibold px-3 py-2 rounded-full transition-all duration-200"
                aria-label="Previous Orders"
              >
                <ClipboardList className="h-4.5 w-4.5" />
                <span className="hidden lg:inline">Orders</span>
              </Link>
              <Link
                to="/account/settings"
                className="text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/10 flex items-center gap-1.5 text-sm font-semibold px-3 py-2 rounded-full transition-all duration-200"
                aria-label="Account Settings"
              >
                <UserCircle2 className="h-4.5 w-4.5" />
                <span className="hidden lg:inline">Profile</span>
              </Link>
              <button
                onClick={handleSignOut}
                className="text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/10 flex items-center gap-1.5 text-sm font-semibold px-3 py-2 rounded-full transition-all duration-200"
                aria-label="Sign Out"
              >
                <LogOut className="h-4.5 w-4.5" />
                <span className="hidden lg:inline">Sign Out</span>
              </button>
            </>
          ) : (
            <>
              <Link
                to="/account"
                className="text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/10 flex items-center gap-1.5 text-sm font-semibold px-3 py-2 rounded-full transition-all duration-200"
                aria-label="Sign In"
              >
                <LogIn className="h-4.5 w-4.5" />
                <span className="hidden lg:inline">Sign In</span>
              </Link>
              <Link
                to="/account?mode=register"
                className="text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/10 flex items-center gap-1.5 text-sm font-semibold px-3 py-2 rounded-full transition-all duration-200"
                aria-label="Create Account"
              >
                <UserPlus className="h-4.5 w-4.5" />
                <span className="hidden lg:inline">Register</span>
              </Link>
            </>
          )}
          <Link
            to="/checkout"
            className="relative text-primary-foreground hover:bg-primary-foreground/10 flex items-center gap-1.5 font-semibold pl-3 pr-4 py-2 rounded-full transition-all duration-200"
            aria-label="Shopping basket"
          >
            <ShoppingBasket className="h-5 w-5" />
            <span className="text-sm">Basket</span>
            {totalItems > 0 && (
              <span className="absolute -top-1 -right-1 bg-destructive text-destructive-foreground text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center animate-scale-in">
                {totalItems}
              </span>
            )}
          </Link>
        </div>
      </div>
    </nav>
  );
}
