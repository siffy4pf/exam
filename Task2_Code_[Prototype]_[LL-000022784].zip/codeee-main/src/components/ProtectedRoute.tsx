import { Navigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import type { AccountRole } from "@/lib/api/auth";

export default function ProtectedRoute({
  children,
  requireRole,
}: {
  children: React.ReactNode;
  /** If set, only users with this role may access the route. */
  requireRole?: AccountRole;
}) {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/account" replace />;
  }

  if (requireRole && user.role !== requireRole) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}
