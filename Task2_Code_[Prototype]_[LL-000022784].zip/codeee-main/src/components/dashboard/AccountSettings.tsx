import { useEffect, useState } from "react";
import { User, Lock, Palette, CreditCard, Bell, Truck, Eye, EyeOff, Upload, Accessibility } from "lucide-react";
import { changePassword, getAccountProfile, updateAccountProfile } from "@/lib/api/auth";
import { toast } from "sonner";
import {
  applyAccessibilityPrefs,
  loadAccessibilityPrefs,
  saveAccessibilityPrefs,
  type AccessibilityPrefs,
} from "@/lib/accessibilityPrefs";

interface AccountSettingsProps {
  userEmail: string;
  userRole?: "customer" | "producer" | string;
}

type SettingsSection = "profile" | "password" | "branding" | "payment" | "notifications" | "delivery" | "accessibility";

export default function AccountSettings({ userEmail, userRole }: AccountSettingsProps) {
  // Local UI state for tabs and forms in the account settings page.
  const [activeSection, setActiveSection] = useState<SettingsSection>("profile");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showCurrentPw, setShowCurrentPw] = useState(false);
  const [showNewPw, setShowNewPw] = useState(false);
  const [changingPassword, setChangingPassword] = useState(false);
  const [bankAccountName, setBankAccountName] = useState("");
  const [bankSortCode, setBankSortCode] = useState("");
  const [bankAccountNumber, setBankAccountNumber] = useState("");
  const [addressLine1, setAddressLine1] = useState("");
  const [addressLine2, setAddressLine2] = useState("");
  const [addressCity, setAddressCity] = useState("");
  const [addressPostcode, setAddressPostcode] = useState("");
  const [addressPhone, setAddressPhone] = useState("");
  const [savingProfile, setSavingProfile] = useState(false);
  const [accessibilityPrefs, setAccessibilityPrefs] = useState<AccessibilityPrefs>(() =>
    loadAccessibilityPrefs(),
  );

  const sections: { key: SettingsSection; label: string; icon: React.ReactNode }[] = [
    { key: "profile", label: "Profile", icon: <User className="h-4 w-4" /> },
    { key: "password", label: "Password", icon: <Lock className="h-4 w-4" /> },
    { key: "branding", label: "Branding", icon: <Palette className="h-4 w-4" /> },
    { key: "payment", label: "Payment", icon: <CreditCard className="h-4 w-4" /> },
    { key: "notifications", label: "Notifications", icon: <Bell className="h-4 w-4" /> },
    ...(userRole === "customer" ? [] : [{ key: "delivery" as const, label: "Delivery", icon: <Truck className="h-4 w-4" /> }]),
    { key: "accessibility", label: "Accessibility", icon: <Accessibility className="h-4 w-4" /> },
  ];

  const handlePasswordChange = async () => {
    if (!newPassword || !confirmPassword) {
      toast.error("Please fill in all password fields");
      return;
    }
    if (newPassword.length < 6) {
      toast.error("Password must be at least 6 characters");
      return;
    }
    if (newPassword !== confirmPassword) {
      toast.error("Passwords do not match");
      return;
    }
    setChangingPassword(true);
    try {
      await changePassword({ currentPassword, newPassword });
      toast.success("Password updated successfully!");
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    } catch (error: unknown) {
      toast.error(error instanceof Error ? error.message : "Failed to update password.");
    } finally {
      setChangingPassword(false);
    }
  };

  const inputClass = "w-full mt-1 px-3 py-2.5 rounded-xl border border-input bg-background text-sm focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none";
  const labelClass = "text-xs font-semibold text-muted-foreground uppercase tracking-wider";
  const cardClass = "bg-card border border-border rounded-2xl p-6 shadow-sm";
  const btnClass = "mt-5 bg-gradient-to-r from-primary to-primary-light text-primary-foreground px-6 py-2.5 rounded-xl text-sm font-bold hover:shadow-glow transition-all duration-300";

  const toggleAccessibility = (key: keyof AccessibilityPrefs) => {
    setAccessibilityPrefs((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const saveAccessibilitySettings = () => {
    applyAccessibilityPrefs(accessibilityPrefs);
    saveAccessibilityPrefs(accessibilityPrefs);
    toast.success("Accessibility preferences saved.");
  };

  useEffect(() => {
    let mounted = true;
    // Load saved bank/address fields for the current account.
    async function loadProfile() {
      try {
        const { profile } = await getAccountProfile();
        if (!mounted) return;
        setBankAccountName(profile.bankAccountName);
        setBankSortCode(profile.bankSortCode);
        setBankAccountNumber(profile.bankAccountNumber);
        setAddressLine1(profile.addressLine1);
        setAddressLine2(profile.addressLine2);
        setAddressCity(profile.addressCity);
        setAddressPostcode(profile.addressPostcode);
        setAddressPhone(profile.addressPhone);
      } catch (error) {
        if (!mounted) return;
        toast.error(error instanceof Error ? error.message : "Failed to load account details.");
      }
    }
    void loadProfile();
    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    // If customer role is active, force away from hidden delivery section.
    if (userRole === "customer" && activeSection === "delivery") {
      setActiveSection("profile");
    }
  }, [userRole, activeSection]);

  const saveProfileDetails = async () => {
    // Save bank and address info to backend profile endpoint.
    setSavingProfile(true);
    try {
      await updateAccountProfile({
        bankAccountName,
        bankSortCode,
        bankAccountNumber,
        addressLine1,
        addressLine2,
        addressCity,
        addressPostcode,
        addressPhone,
      });
      toast.success("Account details saved.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to save account details.");
    } finally {
      setSavingProfile(false);
    }
  };

  return (
    <div className="animate-fade-in">
      <h2 className="text-xl font-bold font-serif mb-6">Account Settings</h2>

      {/* Section tabs */}
      <div className="flex flex-wrap gap-2 mb-8">
        {sections.map((s) => (
          <button
            key={s.key}
            onClick={() => setActiveSection(s.key)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-200 ${
              activeSection === s.key
                ? "bg-primary text-primary-foreground shadow-glow"
                : "bg-card text-muted-foreground border border-border hover:bg-accent/50"
            }`}
          >
            {s.icon}
            {s.label}
          </button>
        ))}
      </div>

      {/* Profile */}
      {activeSection === "profile" && (
        <div className={`${cardClass} max-w-2xl`}>
          <div className="flex items-center gap-3 mb-5">
            <User className="h-5 w-5 text-primary" />
            <h3 className="font-bold font-serif text-lg">Profile Information</h3>
          </div>
          <div className="grid gap-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className={labelClass}>Account Name</label>
                <input className={inputClass} defaultValue="Hillside Apiary" />
              </div>
              <div>
                <label className={labelClass}>Contact Name</label>
                <input className={inputClass} placeholder="Your full name" />
              </div>
            </div>
            <div>
              <label className={labelClass}>Email</label>
              <input className={`${inputClass} bg-muted text-muted-foreground cursor-not-allowed`} value={userEmail} readOnly />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className={labelClass}>Phone</label>
                <input className={inputClass} placeholder="07xxx xxxxxx" />
              </div>
              <div>
                <label className={labelClass}>Location</label>
                <input className={inputClass} placeholder="e.g. Gloucestershire" />
              </div>
            </div>
            <div>
              <label className={labelClass}>Bio</label>
              <textarea className={`${inputClass} resize-none`} rows={3} placeholder="Tell customers about your produce and story..." />
            </div>
            <div>
              <label className={labelClass}>Website</label>
              <input className={inputClass} placeholder="https://yourfarm.co.uk" />
            </div>
          </div>
          <button className={btnClass}>Save Profile</button>
        </div>
      )}

      {/* Password */}
      {activeSection === "password" && (
        <div className={`${cardClass} max-w-lg`}>
          <div className="flex items-center gap-3 mb-5">
            <Lock className="h-5 w-5 text-primary" />
            <h3 className="font-bold font-serif text-lg">Change Password</h3>
          </div>
          <div className="grid gap-4">
            <div>
              <label className={labelClass}>Current Password</label>
              <div className="relative">
                <input
                  type={showCurrentPw ? "text" : "password"}
                  className={inputClass}
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="Enter current password"
                />
                <button
                  type="button"
                  onClick={() => setShowCurrentPw(!showCurrentPw)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 mt-0.5 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showCurrentPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>
            <div>
              <label className={labelClass}>New Password</label>
              <div className="relative">
                <input
                  type={showNewPw ? "text" : "password"}
                  className={inputClass}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="At least 6 characters"
                />
                <button
                  type="button"
                  onClick={() => setShowNewPw(!showNewPw)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 mt-0.5 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showNewPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {newPassword && newPassword.length < 6 && (
                <p className="text-xs text-destructive mt-1">Must be at least 6 characters</p>
              )}
            </div>
            <div>
              <label className={labelClass}>Confirm New Password</label>
              <input
                type="password"
                className={inputClass}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Re-enter new password"
              />
              {confirmPassword && confirmPassword !== newPassword && (
                <p className="text-xs text-destructive mt-1">Passwords do not match</p>
              )}
            </div>
          </div>
          <button className={btnClass} onClick={handlePasswordChange} disabled={changingPassword}>
            {changingPassword ? "Updating..." : "Update Password"}
          </button>
        </div>
      )}

      {/* Branding */}
      {activeSection === "branding" && (
        <div className={`${cardClass} max-w-2xl`}>
          <div className="flex items-center gap-3 mb-5">
            <Palette className="h-5 w-5 text-primary" />
            <h3 className="font-bold font-serif text-lg">Branding & Storefront</h3>
          </div>
          <div className="grid gap-6">
            <div>
              <label className={labelClass}>Store Logo</label>
              <div className="mt-2 flex items-center gap-4">
                <div className="w-20 h-20 rounded-2xl border-2 border-dashed border-border bg-muted flex items-center justify-center">
                  <Upload className="h-6 w-6 text-muted-foreground" />
                </div>
                <div>
                  <button className="text-sm font-semibold text-primary hover:underline">Upload logo</button>
                  <p className="text-xs text-muted-foreground mt-1">PNG or JPG, max 2MB. 200×200px recommended.</p>
                </div>
              </div>
            </div>
            <div>
              <label className={labelClass}>Banner Image</label>
              <div className="mt-2 w-full h-32 rounded-2xl border-2 border-dashed border-border bg-muted flex flex-col items-center justify-center gap-1">
                <Upload className="h-6 w-6 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">Upload a banner (1200×300px recommended)</span>
              </div>
            </div>
            <div>
              <label className={labelClass}>Accent Colour</label>
              <div className="flex items-center gap-3 mt-2">
                {["#4CAF50", "#2196F3", "#FF9800", "#E91E63", "#9C27B0", "#795548"].map((color) => (
                  <button
                    key={color}
                    className="w-8 h-8 rounded-full border-2 border-transparent hover:border-foreground/30 transition-all hover:scale-110"
                    style={{ backgroundColor: color }}
                    aria-label={`Select colour ${color}`}
                  />
                ))}
                <div className="flex items-center gap-2 ml-2">
                  <input type="color" className="w-8 h-8 rounded-full cursor-pointer border-0" defaultValue="#4CAF50" />
                  <span className="text-xs text-muted-foreground">Custom</span>
                </div>
              </div>
            </div>
            <div>
              <label className={labelClass}>Store Tagline</label>
              <input className={inputClass} placeholder="e.g. Fresh from the hive since 2018" />
            </div>
            <div>
              <label className={labelClass}>Store Description</label>
              <textarea className={`${inputClass} resize-none`} rows={4} placeholder="Describe your store for customers browsing your page..." />
            </div>
          </div>
          <button className={btnClass}>Save Branding</button>
        </div>
      )}

      {/* Payment */}
      {activeSection === "payment" && (
        <div className={`${cardClass} max-w-2xl`}>
          <div className="flex items-center gap-3 mb-5">
            <CreditCard className="h-5 w-5 text-primary" />
            <h3 className="font-bold font-serif text-lg">Payment & Banking</h3>
          </div>
          <p className="text-sm text-muted-foreground mb-6">Configure how you receive payments from customers.</p>
          <div className="grid gap-6">
            <div className="bg-muted/50 border border-border rounded-xl p-4">
              <h4 className="text-sm font-bold mb-3">Bank Account Details</h4>
              <div className="grid gap-4">
                <div>
                  <label className={labelClass}>Account Holder Name</label>
                  <input
                    className={inputClass}
                    placeholder="Name as it appears on your account"
                    value={bankAccountName}
                    onChange={(e) => setBankAccountName(e.target.value)}
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className={labelClass}>Sort Code</label>
                    <input
                      className={inputClass}
                      placeholder="00-00-00"
                      maxLength={8}
                      value={bankSortCode}
                      onChange={(e) => setBankSortCode(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className={labelClass}>Account Number</label>
                    <input
                      className={inputClass}
                      placeholder="00000000"
                      maxLength={8}
                      value={bankAccountNumber}
                      onChange={(e) => setBankAccountNumber(e.target.value)}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-muted/50 border border-border rounded-xl p-4">
              <h4 className="text-sm font-bold mb-3">Payment Methods Accepted</h4>
              <div className="space-y-3">
                {[
                  { label: "Card payments (online)", defaultChecked: true },
                  { label: "Cash on collection", defaultChecked: true },
                  { label: "Bank transfer", defaultChecked: false },
                ].map((method) => (
                  <label key={method.label} className="flex items-center gap-3 cursor-pointer">
                    <input type="checkbox" defaultChecked={method.defaultChecked} className="w-4 h-4 rounded border-input accent-primary" />
                    <span className="text-sm font-medium">{method.label}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="bg-muted/50 border border-border rounded-xl p-4">
              <h4 className="text-sm font-bold mb-3">Payout Schedule</h4>
              <select className={inputClass} defaultValue="weekly">
                <option value="daily">Daily</option>
                <option value="weekly">Weekly</option>
                <option value="biweekly">Every two weeks</option>
                <option value="monthly">Monthly</option>
              </select>
            </div>
          </div>
          <button className={btnClass} onClick={saveProfileDetails} disabled={savingProfile}>
            {savingProfile ? "Saving..." : "Save Payment Settings"}
          </button>
        </div>
      )}

      {/* Notifications */}
      {activeSection === "notifications" && (
        <div className={`${cardClass} max-w-lg`}>
          <div className="flex items-center gap-3 mb-5">
            <Bell className="h-5 w-5 text-primary" />
            <h3 className="font-bold font-serif text-lg">Notification Preferences</h3>
          </div>
          <div className="space-y-4">
            {[
              { label: "New order alerts", desc: "Get notified when a customer places an order" },
              { label: "Low stock warnings", desc: "Alert when stock drops below 5 units" },
              { label: "Weekly sales reports", desc: "Summary of sales every Monday morning" },
              { label: "Customer messages", desc: "When a customer sends you a message" },
              { label: "Review notifications", desc: "When a customer leaves a review" },
            ].map((item) => (
              <label key={item.label} className="flex items-start gap-3 cursor-pointer p-3 rounded-xl hover:bg-accent/30 transition-colors">
                <input type="checkbox" defaultChecked className="w-4 h-4 rounded border-input accent-primary mt-0.5" />
                <div>
                  <span className="text-sm font-semibold block">{item.label}</span>
                  <span className="text-xs text-muted-foreground">{item.desc}</span>
                </div>
              </label>
            ))}
          </div>
          <button className={btnClass}>Save Notifications</button>
        </div>
      )}

      {/* Delivery */}
      {activeSection === "delivery" && (
        <div className={`${cardClass} max-w-2xl`}>
          <div className="flex items-center gap-3 mb-5">
            <Truck className="h-5 w-5 text-primary" />
            <h3 className="font-bold font-serif text-lg">Delivery Settings</h3>
          </div>
          <div className="grid gap-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className={labelClass}>Delivery Radius (miles)</label>
                <input type="number" className={inputClass} defaultValue={10} />
              </div>
              <div>
                <label className={labelClass}>Minimum Order (£)</label>
                <input type="number" className={inputClass} defaultValue={5} />
              </div>
            </div>
            <div>
              <label className={labelClass}>Delivery Fee (£)</label>
              <input type="number" className={inputClass} defaultValue={2.5} step={0.5} />
            </div>
            <div>
              <label className={labelClass}>Free Delivery Over (£)</label>
              <input type="number" className={inputClass} defaultValue={20} />
            </div>
            <div className="space-y-3 mt-2">
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" defaultChecked className="w-4 h-4 rounded border-input accent-primary" />
                <span className="text-sm font-medium">Allow collection from farm</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" className="w-4 h-4 rounded border-input accent-primary" />
                <span className="text-sm font-medium">Offer same-day delivery</span>
              </label>
            </div>
            <div>
              <label className={labelClass}>Address Line 1</label>
              <input
                className={inputClass}
                value={addressLine1}
                onChange={(e) => setAddressLine1(e.target.value)}
                placeholder="Street and number"
              />
            </div>
            <div>
              <label className={labelClass}>Address Line 2</label>
              <input
                className={inputClass}
                value={addressLine2}
                onChange={(e) => setAddressLine2(e.target.value)}
                placeholder="Flat, unit, optional"
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className={labelClass}>City</label>
                <input
                  className={inputClass}
                  value={addressCity}
                  onChange={(e) => setAddressCity(e.target.value)}
                  placeholder="Town or city"
                />
              </div>
              <div>
                <label className={labelClass}>Postcode</label>
                <input
                  className={inputClass}
                  value={addressPostcode}
                  onChange={(e) => setAddressPostcode(e.target.value)}
                  placeholder="e.g. GL1 2AB"
                />
              </div>
            </div>
            <div>
              <label className={labelClass}>Phone</label>
              <input
                className={inputClass}
                value={addressPhone}
                onChange={(e) => setAddressPhone(e.target.value)}
                placeholder="Delivery contact number"
              />
            </div>
          </div>
          <button className={btnClass} onClick={saveProfileDetails} disabled={savingProfile}>
            {savingProfile ? "Saving..." : "Save Delivery Settings"}
          </button>
        </div>
      )}

      {/* Accessibility */}
      {activeSection === "accessibility" && (
        <div className={`${cardClass} max-w-2xl`}>
          <div className="flex items-center gap-3 mb-5">
            <Accessibility className="h-5 w-5 text-primary" />
            <h3 className="font-bold font-serif text-lg">Accessibility Preferences</h3>
          </div>
          <p className="text-sm text-muted-foreground mb-6">
            Turn on simple options to make reading and navigation easier.
          </p>
          <div className="space-y-3">
            <button
              type="button"
              onClick={() => toggleAccessibility("largeText")}
              className={`w-full rounded-xl border px-4 py-3 text-left text-sm font-semibold transition-colors ${
                accessibilityPrefs.largeText
                  ? "border-primary bg-primary/10 text-foreground"
                  : "border-border hover:bg-accent/40"
              }`}
            >
              Larger text
            </button>
            <button
              type="button"
              onClick={() => toggleAccessibility("highContrast")}
              className={`w-full rounded-xl border px-4 py-3 text-left text-sm font-semibold transition-colors ${
                accessibilityPrefs.highContrast
                  ? "border-primary bg-primary/10 text-foreground"
                  : "border-border hover:bg-accent/40"
              }`}
            >
              High contrast
            </button>
            <button
              type="button"
              onClick={() => toggleAccessibility("reduceMotion")}
              className={`w-full rounded-xl border px-4 py-3 text-left text-sm font-semibold transition-colors ${
                accessibilityPrefs.reduceMotion
                  ? "border-primary bg-primary/10 text-foreground"
                  : "border-border hover:bg-accent/40"
              }`}
            >
              Reduce animation
            </button>
          </div>
          <button className={btnClass} onClick={saveAccessibilitySettings}>
            Save Accessibility Settings
          </button>
        </div>
      )}
    </div>
  );
}
