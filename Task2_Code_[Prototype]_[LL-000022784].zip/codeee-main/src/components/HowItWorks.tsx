import { ShoppingBag, Clock, Package, Star } from "lucide-react";

const steps = [
  {
    icon: ShoppingBag,
    title: "Browse & Shop",
    description: "Explore fresh produce from local farmers. Filter by category, dietary needs or producer.",
  },
  {
    icon: Clock,
    title: "Pick a Slot",
    description: "Choose a convenient collection or delivery time that suits your schedule.",
  },
  {
    icon: Package,
    title: "We Prepare",
    description: "Producers pack your items fresh. Every order is fully traceable from farm to fork.",
  },
  {
    icon: Star,
    title: "Earn Rewards",
    description: "Collect loyalty points with every purchase — 5 points per pound spent.",
  },
];

export default function HowItWorks() {
  return (
    <section className="py-12 bg-accent/30 -mx-4 px-4 md:-mx-8 md:px-8 rounded-3xl">
      <div className="text-center mb-10">
        <p className="text-primary font-bold text-sm uppercase tracking-wider mb-1">Simple process</p>
        <h2 className="text-2xl md:text-3xl font-bold font-serif">How It Works</h2>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
        {steps.map((step, i) => (
          <div key={step.title} className="relative text-center group">
            {/* Connector line */}
            {i < steps.length - 1 && (
              <div className="hidden lg:block absolute top-8 left-[60%] w-[80%] h-px border-t-2 border-dashed border-primary/20" />
            )}
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-card border border-border shadow-elegant mb-4 group-hover:shadow-glow group-hover:border-primary/30 transition-all duration-300">
              <step.icon className="h-7 w-7 text-primary" />
            </div>
            <div className="absolute -top-2 -right-1 sm:right-auto sm:left-[55%] w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-bold flex items-center justify-center">
              {i + 1}
            </div>
            <h3 className="font-bold text-base mb-1">{step.title}</h3>
            <p className="text-muted-foreground text-sm leading-relaxed">{step.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
