import { MapPin, Award } from "lucide-react";

const producerList = [
  {
    name: "Hillside Apiary",
    location: "Greenfield Valley",
    specialty: "Honey & Bee Products",
    certifications: ["Organic"],
    initial: "HA",
  },
  {
    name: "Green Acres Farm",
    location: "Lower Meadows",
    specialty: "Fresh Salads & Herbs",
    certifications: ["Organic", "Sustainable"],
    initial: "GA",
  },
  {
    name: "Oak Tree Farm",
    location: "Hillside Ridge",
    specialty: "Free Range Eggs & Cheese",
    certifications: ["Free Range"],
    initial: "OT",
  },
  {
    name: "Village Bakehouse",
    location: "Greenfield Town",
    specialty: "Artisan Breads & Pastries",
    certifications: [],
    initial: "VB",
  },
  {
    name: "Meadow View Farm",
    location: "North Pastures",
    specialty: "Seasonal Vegetables",
    certifications: ["Organic"],
    initial: "MV",
  },
  {
    name: "Berry Good Farm",
    location: "Sunnydale",
    specialty: "Jams, Chutneys & Preserves",
    certifications: ["Handmade"],
    initial: "BG",
  },
  {
    name: "Greenfield Butchers",
    location: "Greenfield Farm",
    specialty: "Pork, Beef & Sausages",
    certifications: ["Free Range", "Grass-Fed"],
    initial: "GB",
  },
  {
    name: "Valley Shepherds",
    location: "Greenfield Valley",
    specialty: "Lamb & Mutton",
    certifications: ["Grass-Fed"],
    initial: "VS",
  },
];

export default function ProducerSpotlight() {
  return (
    <section className="py-12">
      <div className="text-center mb-8">
        <p className="text-primary font-bold text-sm uppercase tracking-wider mb-1">Meet the farmers</p>
        <h2 className="text-2xl md:text-3xl font-bold font-serif">Our Producers</h2>
        <p className="text-muted-foreground text-sm mt-2 max-w-md mx-auto">
          Every product is traceable back to the farmer who grew it. Get to know the people behind your food.
        </p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {producerList.map((p) => (
          <div
            key={p.name}
            className="bg-card border border-border rounded-2xl p-5 hover-lift group cursor-default"
          >
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-primary-light text-primary-foreground font-bold flex items-center justify-center text-sm flex-shrink-0 group-hover:shadow-glow transition-shadow duration-300">
                {p.initial}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-bold text-base">{p.name}</h3>
                <p className="text-muted-foreground text-xs flex items-center gap-1 mt-0.5">
                  <MapPin className="h-3 w-3" />
                  {p.location}
                </p>
                <p className="text-sm text-foreground/80 mt-1">{p.specialty}</p>
                {p.certifications.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {p.certifications.map((c) => (
                      <span
                        key={c}
                        className="inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider bg-accent text-accent-foreground px-2 py-0.5 rounded-full"
                      >
                        <Award className="h-2.5 w-2.5" />
                        {c}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
