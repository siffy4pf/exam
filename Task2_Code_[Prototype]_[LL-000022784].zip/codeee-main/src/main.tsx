import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";
import { applyAccessibilityPrefs, loadAccessibilityPrefs } from "./lib/accessibilityPrefs";

// Entry point: mount React app into the root element in index.html.
applyAccessibilityPrefs(loadAccessibilityPrefs());
createRoot(document.getElementById("root")!).render(<App />);
