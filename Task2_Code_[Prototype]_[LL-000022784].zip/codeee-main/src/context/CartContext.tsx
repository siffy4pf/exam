import React, { createContext, useContext, useState, useCallback, useMemo, useEffect } from "react";
import type { Product } from "@/data/products";
import { useAuth } from "@/context/AuthContext";
import { getLoyaltySummary } from "@/lib/api/loyalty";
import { discountPenceFromRedeemedPoints, maxRedeemablePoints } from "@/lib/loyaltyRules";

export interface CartItem {
  product: Product;
  quantity: number;
}

interface CartContextType {
  items: CartItem[];
  /** Points customer chooses to redeem at checkout (75-step, capped server-side). */
  pointsToRedeem: number;
  setPointsToRedeem: (n: number) => void;
  /** Sum of non-expired batch points (server). */
  redeemablePoints: number;
  /** Ledger balance incl. negative after clawback (server). */
  ledgerBalance: number;
  refreshLoyalty: () => Promise<void>;
  addToCart: (product: Product) => void;
  setItemsDirectly: (items: CartItem[]) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  totalItems: number;
  subtotal: number;
  loyaltyDiscount: number;
  maxRedeemableForCart: number;
  totalToPay: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [items, setItems] = useState<CartItem[]>([]);
  const [redeemablePoints, setRedeemablePoints] = useState(0);
  const [ledgerBalance, setLedgerBalance] = useState(0);
  const [pointsToRedeem, setPointsToRedeemState] = useState(0);

  const refreshLoyalty = useCallback(async () => {
    // Loyalty summary is tied to logged-in user, so reset when logged out.
    if (!user) {
      setRedeemablePoints(0);
      setLedgerBalance(0);
      setPointsToRedeemState(0);
      return;
    }
    try {
      const s = await getLoyaltySummary();
      setRedeemablePoints(s.redeemablePoints);
      setLedgerBalance(s.ledgerBalance);
    } catch {
      setRedeemablePoints(0);
      setLedgerBalance(0);
    }
  }, [user]);

  useEffect(() => {
    void refreshLoyalty();
  }, [refreshLoyalty]);

  const subtotal = items.reduce((sum, i) => sum + i.product.price * i.quantity, 0);
  const merchandiseSubtotalPence = Math.round(subtotal * 100);

  const maxRedeemableForCart = useMemo(
    () =>
      maxRedeemablePoints({
        merchandiseSubtotalPence,
        redeemablePointsBalance: redeemablePoints,
      }),
    [merchandiseSubtotalPence, redeemablePoints],
  );

  const setPointsToRedeem = useCallback((n: number) => {
    const v = Math.max(0, Math.floor(Number(n) || 0));
    setPointsToRedeemState(v);
  }, []);

  useEffect(() => {
    if (pointsToRedeem > maxRedeemableForCart) {
      setPointsToRedeemState(maxRedeemableForCart);
    }
  }, [pointsToRedeem, maxRedeemableForCart]);

  useEffect(() => {
    if (!user) setPointsToRedeemState(0);
  }, [user]);

  const loyaltyDiscountPence = discountPenceFromRedeemedPoints(pointsToRedeem);
  const loyaltyDiscount = loyaltyDiscountPence / 100;
  const totalToPay = Math.max(0, subtotal - loyaltyDiscount);

  const addToCart = useCallback((product: Product) => {
    // If item already exists, just increase quantity.
    setItems((prev) => {
      const existing = prev.find((i) => i.product.id === product.id);
      if (existing) {
        return prev.map((i) =>
          i.product.id === product.id ? { ...i, quantity: i.quantity + 1 } : i,
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  }, []);

  const setItemsDirectly = useCallback((nextItems: CartItem[]) => {
    // Replace entire basket (used by "Reorder" flow from order history).
    setItems(nextItems);
  }, []);

  const removeFromCart = useCallback((productId: string) => {
    setItems((prev) => prev.filter((i) => i.product.id !== productId));
  }, []);

  const updateQuantity = useCallback((productId: string, quantity: number) => {
    if (quantity <= 0) {
      setItems((prev) => prev.filter((i) => i.product.id !== productId));
    } else {
      setItems((prev) =>
        prev.map((i) => (i.product.id === productId ? { ...i, quantity } : i)),
      );
    }
  }, []);

  const clearCart = useCallback(() => {
    setItems([]);
    setPointsToRedeemState(0);
  }, []);

  const totalItems = items.reduce((sum, i) => sum + i.quantity, 0);

  return (
    <CartContext.Provider
      value={{
        items,
        pointsToRedeem,
        setPointsToRedeem,
        redeemablePoints,
        ledgerBalance,
        refreshLoyalty,
        addToCart,
        setItemsDirectly,
        removeFromCart,
        updateQuantity,
        clearCart,
        totalItems,
        subtotal,
        loyaltyDiscount,
        maxRedeemableForCart,
        totalToPay,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  // Small guard so we don't use cart hooks outside provider tree.
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
}
