import { useState, useMemo, useEffect } from "react";
import { Link, useSearchParams } from "react-router-dom";
import Navbar from "@/components/Navbar";
import FilterBar from "@/components/FilterBar";
import ProductCard from "@/components/ProductCard";
import Footer from "@/components/Footer";
import { products } from "@/data/products";

// Full products page: same filter logic as home, but shows all matching items.
export default function Products() {
  const [searchParams] = useSearchParams();
  const [search, setSearch] = useState(searchParams.get("search") || "");
  const [category, setCategory] = useState("All");
  const [dietary, setDietary] = useState("All");
  const [producer, setProducer] = useState("All");
  const [inStockOnly, setInStockOnly] = useState(false);

  useEffect(() => {
    const q = searchParams.get("search");
    if (q) setSearch(q);
  }, [searchParams]);

  const filtered = useMemo(() => {
    // Filter chain is grouped here for readability and reuse.
    return products.filter((p) => {
      if (search) {
        const q = search.toLowerCase();
        const matchesName = p.name.toLowerCase().includes(q);
        const matchesProducer = p.producer.toLowerCase().includes(q);
        const matchesCategory = p.category.toLowerCase().includes(q);
        const matchesDescription = p.description?.toLowerCase().includes(q);
        if (!matchesName && !matchesProducer && !matchesCategory && !matchesDescription) return false;
      }
      if (category !== "All" && p.category !== category) return false;
      if (dietary !== "All" && !p.dietary.includes(dietary)) return false;
      if (producer !== "All" && p.producer !== producer) return false;
      if (inStockOnly && p.stock === 0) return false;
      return true;
    });
  }, [search, category, dietary, producer, inStockOnly]);

  const handleSearch = (query: string) => {
    setSearch(query);
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar onSearch={handleSearch} />
      <main className="container mx-auto flex-1 px-4 py-8">
        <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
          <Link to="/" className="hover:text-primary transition-colors">Home</Link>
          <span>/</span>
          <span className="text-foreground font-medium">All Products</span>
        </nav>

        <div className="flex items-end justify-between mb-2">
          <div>
            <p className="text-primary font-bold text-sm uppercase tracking-wider mb-1">Fresh today</p>
            <h1 className="text-2xl md:text-3xl font-bold font-serif">
              {search ? `Results for "${search}"` : category === "All" ? "All Products" : category}
            </h1>
          </div>
          <div className="flex gap-5 text-xs text-muted-foreground">
            {[
              { color: "bg-success", label: "In Stock" },
              { color: "bg-warning", label: "Low Stock" },
              { color: "bg-destructive", label: "Out of Stock" },
            ].map((s) => (
              <span key={s.label} className="flex items-center gap-1.5">
                <span className={`w-2 h-2 rounded-full ${s.color} inline-block`} />
                {s.label}
              </span>
            ))}
          </div>
        </div>

        <FilterBar
          category={category}
          dietary={dietary}
          producer={producer}
          inStockOnly={inStockOnly}
          onCategoryChange={setCategory}
          onDietaryChange={setDietary}
          onProducerChange={setProducer}
          onInStockChange={setInStockOnly}
        />

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-4 animate-stagger">
          {filtered.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-16 animate-fade-in">
            <p className="text-muted-foreground text-lg font-semibold">No products match your filters.</p>
            <p className="text-muted-foreground/60 text-sm mt-1">Try adjusting your filters or search terms.</p>
            <button
              onClick={() => { setSearch(""); setCategory("All"); setDietary("All"); setProducer("All"); setInStockOnly(false); }}
              className="mt-4 text-primary font-bold text-sm hover:underline"
            >
              Clear all filters
            </button>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}
