import { useState, useRef, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import StockBadge from "@/components/StockBadge";
import Footer from "@/components/Footer";
import ThemeToggle from "@/components/ThemeToggle";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts";
import { Package, ClipboardList, BarChart3, TrendingUp, AlertTriangle, Boxes, PoundSterling, ArrowLeft, LogOut, ChevronUp, Settings, X } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import AccountSettings from "@/components/dashboard/AccountSettings";
import { toast } from "sonner";
import {
  createMyProduct,
  getMyProducts,
  updateMyProductStock,
} from "@/lib/api/products";

const logo = "/favicon-glh.svg";
interface DashboardProduct {
  id: string;
  name: string;
  stock: number;
  price: number;
}

const salesData = [
  { name: "Honey", sales: 42 },
  { name: "Candle", sales: 28 },
  { name: "Wildflower", sales: 12 },
  { name: "Royal J.", sales: 35 },
  { name: "Pollen", sales: 30 },
];

const recentOrders = [
  { id: "#1042", items: "2x Honey, 1x Pollen", date: "Tue 10:00", total: "£24.50", status: "Pending" },
  { id: "#1039", items: "1x Candle", date: "Mon 14:00", total: "£6.00", status: "Ready" },
  { id: "#1037", items: "3x Honey", date: "Mon 09:00", total: "£13.50", status: "Dispatched" },
];

type Tab = "products" | "orders" | "sales" | "settings";

export default function ProducerDashboard() {
  const [activeTab, setActiveTab] = useState<Tab>("products");
  const [dashProducts, setDashProducts] = useState<DashboardProduct[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editStock, setEditStock] = useState("");
  const [showAccountMenu, setShowAccountMenu] = useState(false);
  const accountMenuRef = useRef<HTMLDivElement>(null);
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newProduct, setNewProduct] = useState({ name: "", stock: "", price: "" });
  const [loadingProducts, setLoadingProducts] = useState(true);
  const [savingProduct, setSavingProduct] = useState(false);

  useEffect(() => {
    // Close account menu when user clicks outside the menu box.
    const handleClickOutside = (e: MouseEvent) => {
      if (accountMenuRef.current && !accountMenuRef.current.contains(e.target as Node)) {
        setShowAccountMenu(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    let mounted = true;
    // Load producer products from backend so refresh keeps data.
    async function loadProducts() {
      setLoadingProducts(true);
      try {
        const res = await getMyProducts();
        if (!mounted) return;
        setDashProducts(
          res.products.map((p) => ({
            id: p.id,
            name: p.name,
            stock: p.stock,
            price: p.price,
          })),
        );
      } catch (error) {
        if (!mounted) return;
        toast.error(error instanceof Error ? error.message : "Failed to load your products.");
      } finally {
        if (mounted) setLoadingProducts(false);
      }
    }
    void loadProducts();
    return () => {
      mounted = false;
    };
  }, []);

  const handleSignOut = async () => {
    await signOut();
    navigate("/");
  };

  const handleAddProduct = async () => {
    // Basic form validation before POSTing to API.
    const name = newProduct.name.trim();
    const stock = parseInt(newProduct.stock);
    const price = parseFloat(newProduct.price);
    if (!name) { toast.error("Product name is required."); return; }
    if (isNaN(stock) || stock < 0) { toast.error("Enter a valid stock amount."); return; }
    if (isNaN(price) || price <= 0) { toast.error("Enter a valid price."); return; }

    setSavingProduct(true);
    try {
      const res = await createMyProduct({ name, stock, price });
      setDashProducts((prev) => [
        ...prev,
        {
          id: res.product.id,
          name: res.product.name,
          stock: res.product.stock,
          price: res.product.price,
        },
      ]);
      setNewProduct({ name: "", stock: "", price: "" });
      setShowAddDialog(false);
      toast.success(`"${name}" added successfully!`);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to add product.");
    } finally {
      setSavingProduct(false);
    }
  };

  const handleEdit = (product: DashboardProduct) => {
    setEditingId(product.id);
    setEditStock(String(product.stock));
  };

  const handleSave = async (id: string) => {
    // Save stock change to backend and update local row.
    const newStock = parseInt(editStock);
    if (isNaN(newStock) || newStock < 0) {
      toast.error("Stock must be a non-negative number.");
      return;
    }
    setSavingProduct(true);
    try {
      const res = await updateMyProductStock(id, { stock: newStock });
      setDashProducts((prev) =>
        prev.map((p) => (p.id === id ? { ...p, stock: res.product.stock } : p))
      );
      setEditingId(null);
      toast.success("Stock updated.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to update stock.");
    } finally {
      setSavingProduct(false);
    }
  };

  const totalStock = dashProducts.reduce((s, p) => s + p.stock, 0);
  const lowStockCount = dashProducts.filter((p) => p.stock > 0 && p.stock <= 5).length;
  const totalRevenue = "£147.50";

  const tabs: { key: Tab; label: string; icon: React.ReactNode }[] = [
    { key: "products", label: "My Products", icon: <Package className="h-4 w-4" /> },
    { key: "orders", label: "My Orders", icon: <ClipboardList className="h-4 w-4" /> },
    { key: "sales", label: "Sales Summary", icon: <BarChart3 className="h-4 w-4" /> },
  ];

  const statCards = [
    { label: "Total Products", value: dashProducts.length, icon: Boxes, color: "text-primary" },
    { label: "Total Stock", value: totalStock, icon: Package, color: "text-primary" },
    { label: "Low Stock Alerts", value: lowStockCount, icon: AlertTriangle, color: "text-warning" },
    { label: "This Week", value: totalRevenue, icon: PoundSterling, color: "text-primary" },
  ];

  const statusColors: Record<string, string> = {
    Pending: "bg-warning/10 text-warning border-warning/30",
    Ready: "bg-primary/10 text-primary border-primary/30",
    Dispatched: "bg-success/10 text-success border-success/30",
  };

  return (
    <div className="flex flex-col min-h-screen">
      <nav className="bg-gradient-to-r from-primary-dark via-primary to-primary-dark px-4 py-3 shadow-lg">
        <div className="container mx-auto flex items-center justify-between">
          <Link to="/" className="group flex items-center gap-2.5 text-primary-foreground font-serif text-xl font-bold">
            <img
              src={logo}
              alt="GLH Logo"
              className="h-10 w-10 rounded-lg ring-2 ring-primary-foreground/40 shadow-md transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3"
            />
            Local Produce Hub
          </Link>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Link to="/" className="text-primary-foreground/80 hover:text-primary-foreground text-sm font-semibold flex items-center gap-1 hover:bg-primary-foreground/10 px-3 py-1.5 rounded-full transition-all">
              <ArrowLeft className="h-4 w-4" />
              Store
            </Link>
          </div>
        </div>
      </nav>

      <div className="flex flex-1">
        {/* Sidebar */}
        <aside className="w-56 bg-sidebar text-sidebar-foreground hidden md:flex flex-col border-r border-sidebar-border/20">
          <div className="p-5">
            <h2 className="text-sidebar-primary font-bold text-lg font-serif">My Hub</h2>
            <p className="text-sidebar-foreground/50 text-xs mt-0.5">Hillside Apiary</p>
          </div>
          <ul className="flex-1 px-3 space-y-1">
            {tabs.map((t) => (
              <li key={t.key}>
                <button
                  onClick={() => setActiveTab(t.key)}
                  className={`w-full text-left px-3 py-2.5 rounded-xl text-sm font-semibold flex items-center gap-2.5 transition-all duration-200 ${
                    activeTab === t.key
                      ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-sm"
                      : "text-sidebar-foreground/60 hover:bg-sidebar-accent/40 hover:text-sidebar-foreground"
                  }`}
                >
                  {t.icon}
                  {t.label}
                </button>
              </li>
            ))}
          </ul>
          <div className="p-4 border-t border-sidebar-border/20 relative" ref={accountMenuRef}>
            {showAccountMenu && (
              <div className="absolute bottom-full left-3 right-3 mb-2 bg-popover border border-border rounded-xl shadow-lg overflow-hidden animate-fade-in">
                <button
                  onClick={() => { setActiveTab("settings"); setShowAccountMenu(false); }}
                  className="w-full text-left px-4 py-2.5 text-sm font-semibold text-foreground hover:bg-accent transition-colors flex items-center gap-2"
                >
                  <Settings className="h-4 w-4" />
                  Account Settings
                </button>
                <button
                  onClick={handleSignOut}
                  className="w-full text-left px-4 py-2.5 text-sm font-semibold text-destructive hover:bg-destructive/10 transition-colors flex items-center gap-2 border-t border-border/50"
                >
                  <LogOut className="h-4 w-4" />
                  Sign Out
                </button>
              </div>
            )}
            <button
              onClick={() => setShowAccountMenu(!showAccountMenu)}
              className="flex items-center gap-2 w-full hover:bg-sidebar-accent/40 rounded-xl p-1.5 transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-sidebar-accent text-sidebar-accent-foreground flex items-center justify-center text-xs font-bold">
                {user?.email?.charAt(0).toUpperCase() || "P"}
              </div>
              <div className="flex-1 text-left">
                <p className="text-xs font-bold text-sidebar-foreground truncate">{user?.email || "Producer"}</p>
                <p className="text-[10px] text-sidebar-foreground/50">Producer Account</p>
              </div>
              <ChevronUp className={`h-3.5 w-3.5 text-sidebar-foreground/50 transition-transform ${showAccountMenu ? "" : "rotate-180"}`} />
            </button>
          </div>
        </aside>

        {/* Main */}
        <main className="flex-1 p-6 bg-background overflow-y-auto">
          {/* Mobile tabs */}
          <div className="flex md:hidden gap-2 mb-6 overflow-x-auto pb-1">
            {tabs.map((t) => (
              <button
                key={t.key}
                onClick={() => setActiveTab(t.key)}
                className={`px-4 py-2 text-xs font-bold rounded-full whitespace-nowrap transition-all duration-200 ${
                  activeTab === t.key
                    ? "bg-primary text-primary-foreground shadow-glow"
                    : "bg-card text-muted-foreground border border-border"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          {activeTab === "products" && (
            <div className="animate-fade-in">
              {/* Stat cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                {statCards.map((s) => (
                  <div key={s.label} className="bg-card border border-border rounded-2xl p-4 shadow-sm hover:shadow-elegant transition-shadow">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs text-muted-foreground font-semibold uppercase tracking-wider">{s.label}</span>
                      <s.icon className={`h-4 w-4 ${s.color}`} />
                    </div>
                    <p className="text-2xl font-extrabold">{s.value}</p>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-foreground font-serif">My Products</h2>
                <button
                  onClick={() => setShowAddDialog(true)}
                  className="bg-gradient-to-r from-primary to-primary-light text-primary-foreground px-5 py-2 rounded-xl text-sm font-bold hover:shadow-glow transition-all duration-300"
                >
                  + Add New
                </button>
              </div>

              <div className="bg-card rounded-2xl border border-border overflow-hidden shadow-sm">
                {loadingProducts ? (
                  <div className="p-6 text-sm text-muted-foreground">Loading your products...</div>
                ) : dashProducts.length === 0 ? (
                  <div className="p-6 text-sm text-muted-foreground">No products yet. Add your first product.</div>
                ) : (
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gradient-to-r from-primary-dark to-primary text-primary-foreground">
                      <th className="text-left px-5 py-3.5 font-bold">Product Name</th>
                      <th className="text-center px-4 py-3.5 font-bold">Stock</th>
                      <th className="text-center px-4 py-3.5 font-bold">Price</th>
                      <th className="text-center px-4 py-3.5 font-bold">Status</th>
                      <th className="text-center px-4 py-3.5 font-bold">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {dashProducts.map((p, i) => (
                      <tr key={p.id} className={`border-b border-border/50 hover:bg-accent/30 transition-colors ${i % 2 === 0 ? "" : "bg-muted/30"}`}>
                        <td className="px-5 py-3.5 font-semibold">{p.name}</td>
                        <td className="px-4 py-3.5 text-center">
                          {editingId === p.id ? (
                            <input
                              type="number"
                              min="0"
                              value={editStock}
                              onChange={(e) => setEditStock(e.target.value)}
                              className="w-16 border border-input rounded-lg px-2 py-1 text-center text-sm bg-background"
                              aria-label={`Stock for ${p.name}`}
                            />
                          ) : (
                            <span className="font-bold">{p.stock}</span>
                          )}
                        </td>
                        <td className="px-4 py-3.5 text-center font-semibold">£{p.price.toFixed(2)}</td>
                        <td className="px-4 py-3.5 text-center">
                          <StockBadge stock={p.stock} />
                        </td>
                        <td className="px-4 py-3.5 text-center">
                          {editingId === p.id ? (
                            <button
                              onClick={() => handleSave(p.id)}
                              className="bg-primary text-primary-foreground px-4 py-1.5 rounded-lg text-xs font-bold hover:bg-primary/90 transition-colors"
                            >
                              Save
                            </button>
                          ) : (
                            <button
                              onClick={() => handleEdit(p)}
                              className="bg-secondary text-secondary-foreground px-4 py-1.5 rounded-lg text-xs font-bold hover:bg-accent transition-colors border border-border"
                            >
                              Edit
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                )}
              </div>

              {/* Sales + Orders */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
                <div className="bg-card border border-border rounded-2xl p-5 shadow-sm">
                  <div className="flex items-center gap-2 mb-4">
                    <TrendingUp className="h-4 w-4 text-primary" />
                    <h3 className="font-bold font-serif">Weekly Sales</h3>
                  </div>
                  <div className="h-52">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={salesData}>
                        <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                        <YAxis tick={{ fontSize: 12 }} />
                        <Tooltip
                          contentStyle={{
                            borderRadius: "12px",
                            border: "1px solid hsl(var(--border))",
                            boxShadow: "var(--shadow-md)",
                          }}
                        />
                        <Bar dataKey="sales" fill="hsl(122, 39%, 49%)" radius={[6, 6, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="bg-card border border-border rounded-2xl p-5 shadow-sm">
                  <div className="flex items-center gap-2 mb-4">
                    <ClipboardList className="h-4 w-4 text-primary" />
                    <h3 className="font-bold font-serif">Recent Orders</h3>
                  </div>
                  <div className="space-y-3">
                    {recentOrders.map((o) => (
                      <div key={o.id} className="flex items-center justify-between p-3 rounded-xl border border-border/50 hover:bg-accent/20 transition-colors">
                        <div className="flex items-center gap-3">
                          <span className="font-bold text-primary text-sm">{o.id}</span>
                          <div>
                            <p className="text-sm font-semibold">{o.items}</p>
                            <p className="text-xs text-muted-foreground">{o.date}</p>
                          </div>
                        </div>
                        <div className="text-right flex items-center gap-3">
                          <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full border ${statusColors[o.status]}`}>
                            {o.status}
                          </span>
                          <span className="font-bold text-sm">{o.total}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === "orders" && (
            <div className="animate-fade-in">
              <h2 className="text-xl font-bold font-serif mb-6">All Orders</h2>
              <div className="space-y-3">
                {recentOrders.map((o) => (
                  <div key={o.id} className="bg-card border border-border rounded-2xl p-5 shadow-sm hover:shadow-elegant transition-shadow">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <span className="font-bold text-primary text-lg">{o.id}</span>
                        <span className={`text-xs font-bold uppercase px-2.5 py-1 rounded-full border ${statusColors[o.status]}`}>
                          {o.status}
                        </span>
                      </div>
                      <span className="text-muted-foreground text-sm">{o.date}</span>
                    </div>
                    <p className="text-sm mt-2">{o.items}</p>
                    <p className="text-lg font-bold mt-1">{o.total}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === "sales" && (
            <div className="animate-fade-in">
              <h2 className="text-xl font-bold font-serif mb-6">Sales Summary</h2>
              <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={salesData}>
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip
                        contentStyle={{
                          borderRadius: "12px",
                          border: "1px solid hsl(var(--border))",
                        }}
                      />
                      <Bar dataKey="sales" fill="hsl(122, 39%, 49%)" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}

          {activeTab === "settings" && (
            <AccountSettings userEmail={user?.email || ""} userRole={user?.role} />
          )}

        </main>
      </div>

      {/* Add New Product Dialog */}
      {showAddDialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 animate-fade-in" onClick={() => setShowAddDialog(false)}>
          <div className="bg-card border border-border rounded-2xl p-6 w-full max-w-md shadow-lg mx-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-lg font-bold font-serif">Add New Product</h3>
              <button onClick={() => setShowAddDialog(false)} className="text-muted-foreground hover:text-foreground transition-colors">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-semibold block mb-1">Product Name</label>
                <input
                  type="text"
                  value={newProduct.name}
                  onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                  className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background"
                  placeholder="e.g. Organic Honey 340g"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-semibold block mb-1">Stock</label>
                  <input
                    type="number"
                    min="0"
                    value={newProduct.stock}
                    onChange={(e) => setNewProduct({ ...newProduct, stock: e.target.value })}
                    className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background"
                    placeholder="0"
                  />
                </div>
                <div>
                  <label className="text-sm font-semibold block mb-1">Price (£)</label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={newProduct.price}
                    onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })}
                    className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background"
                    placeholder="0.00"
                  />
                </div>
              </div>
              <button
                onClick={handleAddProduct}
                disabled={savingProduct}
                className="w-full bg-gradient-to-r from-primary to-primary-light text-primary-foreground font-bold py-2.5 rounded-xl hover:shadow-glow transition-all duration-300"
              >
                {savingProduct ? "Saving..." : "Add Product"}
              </button>
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
}
