import { Link } from "react-router-dom";
import Footer from "@/components/Footer";

export default function AccessibilityPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <nav className="bg-primary px-4 py-3">
        <div className="container mx-auto">
          <Link to="/" className="text-primary-foreground font-serif text-xl font-bold">
            Local Produce Hub
          </Link>
        </div>
      </nav>
      <main className="container mx-auto flex-1 max-w-3xl px-4 py-8">
        <h1 className="text-2xl font-bold font-serif text-primary mb-4">Accessibility Statement</h1>
        <p className="mb-4">
          Greenfield Local Hub is committed to ensuring digital accessibility for all users. We aim to meet WCAG 2.1 AA standards throughout our platform.
        </p>
        <h2 className="text-lg font-bold font-serif text-primary mt-6 mb-2">What We've Done</h2>
        <ul className="list-disc list-inside space-y-1 mb-4">
          <li>All interactive elements are keyboard navigable</li>
          <li>Colour contrast meets WCAG AA minimum ratios</li>
          <li>Stock status badges use universally understood colour coding (green, amber, red)</li>
          <li>All images include descriptive alt text</li>
          <li>Form fields have associated labels for screen readers</li>
          <li>Responsive design supports a wide range of devices and screen sizes</li>
        </ul>
        <h2 className="text-lg font-bold font-serif text-primary mt-6 mb-2">Known Limitations</h2>
        <p className="mb-4">We are continuously improving. If you encounter any accessibility barriers, please contact us at accessibility@glh.co.uk.</p>
        <h2 className="text-lg font-bold font-serif text-primary mt-6 mb-2">Feedback</h2>
        <p>We welcome your feedback on the accessibility of this website. Please contact us so we can address any issues.</p>
      </main>
      <Footer />
    </div>
  );
}
