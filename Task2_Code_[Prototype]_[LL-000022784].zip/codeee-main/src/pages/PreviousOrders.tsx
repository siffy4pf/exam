import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { PackageSearch } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { getMyOrders, type UserOrder } from "@/lib/api/orders";
import { products } from "@/data/products";
import { useCart, type CartItem } from "@/context/CartContext";
import { toast } from "sonner";

// Convert stored pence values to pounds for display.
function pounds(pence: number) {
  return (pence / 100).toFixed(2);
}

function statusClass(status: UserOrder["status"]) {
  if (status === "paid") return "bg-success/10 text-success border-success/30";
  if (status === "refunded") return "bg-warning/10 text-warning border-warning/30";
  if (status === "cancelled") return "bg-destructive/10 text-destructive border-destructive/30";
  if (status === "ready") return "bg-primary/10 text-primary border-primary/30";
  if (status === "dispatched") return "bg-indigo-500/10 text-indigo-600 border-indigo-500/30";
  return "bg-muted text-muted-foreground border-border";
}

function statusStep(status: UserOrder["status"]) {
  if (status === "delivered" || status === "collected") return 3;
  if (status === "dispatched" || status === "ready") return 2;
  if (status === "paid") return 1;
  return 0;
}

function trackingMessage(order: UserOrder) {
  const { status, fulfillmentType } = order;
  if (status === "ready" && fulfillmentType === "collection") return "Your order is ready to collect.";
  if (status === "collected") return "Your collection order has been collected.";
  if (status === "dispatched" && fulfillmentType === "delivery") return "Your order has been dispatched.";
  if (status === "delivered") return "Your delivery order has been delivered.";
  if (status === "paid") return "Your order is being prepared.";
  if (status === "cancelled") return "This order was cancelled.";
  if (status === "refunded") return "This order was refunded.";
  return "Tracking status unavailable.";
}
function trackerLabels(fulfillmentType: UserOrder["fulfillmentType"]) {
  return fulfillmentType === "delivery"
    ? ["Paid", "Dispatched", "Delivered"]
    : ["Paid", "Ready to collect", "Collected"];
}


export default function PreviousOrders() {
  const navigate = useNavigate();
  const { setItemsDirectly } = useCart();
  const [orders, setOrders] = useState<UserOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const productsById = useMemo(
    () => new Map(products.map((p) => [p.id, p])),
    [],
  );
  const productsByName = useMemo(
    () => new Map(products.map((p) => [p.name.trim().toLowerCase(), p])),
    [],
  );

  useEffect(() => {
    let mounted = true;
    // Load the signed-in user's order history once on page entry.
    async function load() {
      try {
        const res = await getMyOrders();
        if (!mounted) return;
        setOrders(res.orders);
      } catch (e) {
        if (!mounted) return;
        setError(e instanceof Error ? e.message : "Failed to load previous orders.");
      } finally {
        if (mounted) setLoading(false);
      }
    }
    void load();
    return () => {
      mounted = false;
    };
  }, []);

  const handleReorder = (order: UserOrder) => {
    // Rebuild cart lines from saved order items.
    const nextItems: CartItem[] = [];
    for (const item of order.items) {
      const product =
        (item.productId ? productsById.get(item.productId) : undefined) ??
        productsByName.get(item.productName.trim().toLowerCase());
      if (!product) continue;
      nextItems.push({ product, quantity: item.quantity });
    }
    if (nextItems.length === 0) {
      toast.error("None of the original items are currently available to reorder.");
      return;
    }
    setItemsDirectly(nextItems);
    toast.success("Items added to basket. Continue checkout.");
    navigate("/checkout");
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="container mx-auto flex-1 px-4 py-8">
        <div className="mb-6">
          <h1 className="font-serif text-2xl font-bold text-foreground">Previous Orders</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            All orders placed on this account are shown here.
          </p>
        </div>

        {loading && (
          <div className="rounded-2xl border border-border bg-card p-6 text-sm text-muted-foreground">
            Loading your order history...
          </div>
        )}

        {!loading && error && (
          <div className="rounded-2xl border border-destructive/30 bg-destructive/10 p-6 text-sm text-destructive">
            {error}
          </div>
        )}

        {!loading && !error && orders.length === 0 && (
          <div className="rounded-2xl border border-border bg-card p-10 text-center">
            <PackageSearch className="mx-auto h-10 w-10 text-muted-foreground/50" />
            <p className="mt-3 text-sm font-semibold text-foreground">No previous orders yet</p>
            <p className="mt-1 text-sm text-muted-foreground">Place your first order to see it here.</p>
            <Link
              to="/products"
              className="mt-5 inline-block rounded-xl bg-primary px-4 py-2 text-sm font-bold text-primary-foreground"
            >
              Browse products
            </Link>
          </div>
        )}

        {!loading && !error && orders.length > 0 && (
          <div className="space-y-3">
            {orders.map((order) => {
              const totalPence =
                order.merchandiseSubtotalPence + order.deliveryChargePence - order.loyaltyDiscountPence;
              return (
                <div key={order.id} className="rounded-2xl border border-border bg-card p-5 shadow-sm">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Order ID</p>
                      <p className="text-sm font-bold">{order.id}</p>
                    </div>
                    <span className={`rounded-full border px-2.5 py-1 text-xs font-bold uppercase ${statusClass(order.status)}`}>
                      {order.status}
                    </span>
                  </div>
                  <div className="mt-4 grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
                    <div>
                      <p className="text-xs text-muted-foreground">Subtotal</p>
                      <p className="font-semibold">GBP {pounds(order.merchandiseSubtotalPence)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Delivery</p>
                      <p className="font-semibold">GBP {pounds(order.deliveryChargePence)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Loyalty discount</p>
                      <p className="font-semibold">-GBP {pounds(order.loyaltyDiscountPence)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Total paid</p>
                      <p className="font-bold">GBP {pounds(totalPence)}</p>
                    </div>
                  </div>
                  <div className="mt-4 rounded-xl border border-border/60 bg-muted/20 p-3">
                    <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                      Order tracker
                    </p>
                    <div className="mt-2 flex items-center gap-2">
                      {trackerLabels(order.fulfillmentType).map((label, index) => {
                        const done = statusStep(order.status) >= index + 1;
                        return (
                          <div key={label} className="flex flex-1 items-center gap-2">
                            <div
                              className={`h-2 w-2 rounded-full ${
                                done ? "bg-primary" : "bg-muted-foreground/40"
                              }`}
                            />
                            <span className={`text-xs font-semibold ${done ? "text-foreground" : "text-muted-foreground"}`}>
                              {label}
                            </span>
                            {index < 2 && (
                              <div
                                className={`h-0.5 flex-1 ${
                                  statusStep(order.status) > index + 1
                                    ? "bg-primary/80"
                                    : "bg-muted-foreground/30"
                                }`}
                              />
                            )}
                          </div>
                        );
                      })}
                    </div>
                    <p className="mt-2 text-sm font-medium text-foreground">{trackingMessage(order)}</p>
                  </div>
                  <div className="mt-4 rounded-xl border border-border/60 bg-muted/20 p-3">
                    <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                      Products in this order
                    </p>
                    <ul className="mt-2 space-y-1">
                      {order.items.length > 0 ? (
                        order.items.map((item, idx) => (
                          <li key={`${order.id}-${item.productName}-${idx}`} className="text-sm">
                            {item.quantity}x {item.productName}
                          </li>
                        ))
                      ) : (
                        <li className="text-sm text-muted-foreground">No item details saved for this order.</li>
                      )}
                    </ul>
                  </div>
                  <div className="mt-4">
                    <button
                      onClick={() => handleReorder(order)}
                      className="rounded-xl bg-primary px-4 py-2 text-sm font-bold text-primary-foreground hover:bg-primary/90"
                    >
                      Reorder
                    </button>
                  </div>
                  <p className="mt-3 text-xs text-muted-foreground">
                    Placed on {new Date(order.createdAt).toLocaleString()}
                  </p>
                </div>
              );
            })}
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}
