import { useState, useEffect } from "react";
import { Link, useSearchParams, useNavigate } from "react-router-dom";
import Footer from "@/components/Footer";
import { toast } from "sonner";
import { login, signUp, type AccountRole } from "@/lib/api/auth";
import { useAuth } from "@/context/AuthContext";

// Account page combines sign in + sign up in one place.
function homePathForRole(role: AccountRole) {
  return role === "producer" ? "/dashboard" : "/";
}

export default function Account() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user, refreshSession } = useAuth();
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [accountRole, setAccountRole] = useState<AccountRole>(() =>
    searchParams.get("role") === "producer" ? "producer" : "customer",
  );
  const [consent, setConsent] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (searchParams.get("mode") === "register") {
      setIsLogin(false);
    }
  }, [searchParams]);

  useEffect(() => {
    if (searchParams.get("role") === "producer") {
      setAccountRole("producer");
    }
  }, [searchParams]);

  const redirect = searchParams.get("redirect");

  // Redirect if already logged in
  useEffect(() => {
    if (user) {
      const dest = redirect ? `/${redirect}` : homePathForRole(user.role);
      navigate(dest, { replace: true });
    }
  }, [user, navigate, redirect]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      toast.error("Please fill in all required fields.");
      return;
    }
    if (!isLogin && !consent) {
      toast.error("You must agree to data storage to create an account.");
      return;
    }
    if (password.length < 8) {
      toast.error("Password must be at least 8 characters.");
      return;
    }

    setSubmitting(true);
    try {
      // Same submit function handles both login and registration flows.
      if (isLogin) {
        const { user: signedIn } = await login({ email, password });
        await refreshSession();
        toast.success("Signed in successfully!");
        navigate(redirect ? `/${redirect}` : homePathForRole(signedIn.role));
      } else {
        const { user: created } = await signUp({
          email,
          password,
          fullName: name,
          role: accountRole,
        });
        await refreshSession();
        toast.success("Account created successfully!");
        navigate(redirect ? `/${redirect}` : homePathForRole(created.role));
      }
    } catch (error: unknown) {
      toast.error(error instanceof Error ? error.message : "An error occurred.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      <nav className="bg-primary px-4 py-3">
        <div className="container mx-auto flex items-center justify-between">
          <Link to="/" className="text-primary-foreground font-serif text-xl font-bold">
            Local Produce Hub
          </Link>
          <Link to="/" className="text-primary-foreground text-sm font-semibold hover:underline">
            Back to Store
          </Link>
        </div>
      </nav>

      <main className="flex-1 flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-md border border-border rounded-xl p-6 bg-popover shadow-sm">
          <h1 className="text-2xl font-bold font-serif text-primary text-center mb-6">
            {isLogin ? "Sign In" : "Create Account"}
          </h1>

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div>
                <label htmlFor="name" className="text-sm font-semibold block mb-1">Full Name</label>
                <input
                  id="name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  maxLength={100}
                  className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background"
                  required
                />
              </div>
            )}
            <div>
              <label htmlFor="email" className="text-sm font-semibold block mb-1">Email</label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                maxLength={255}
                className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background"
                required
              />
            </div>
            <div>
              <label htmlFor="password" className="text-sm font-semibold block mb-1">Password</label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                maxLength={128}
                minLength={8}
                className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background"
                required
              />
              <p className="text-xs text-muted-foreground mt-1">Minimum 8 characters</p>
            </div>

            {!isLogin && (
              <div className="space-y-2">
                <p className="text-sm font-semibold text-foreground">Account type</p>
                <div className="grid grid-cols-1 gap-2">
                  <label
                    className={`flex items-start gap-3 rounded-lg border px-3 py-2.5 cursor-pointer transition-colors ${
                      accountRole === "customer" ? "border-primary bg-primary/5" : "border-border"
                    }`}
                  >
                    <input
                      type="radio"
                      name="accountRole"
                      checked={accountRole === "customer"}
                      onChange={() => setAccountRole("customer")}
                      className="accent-primary mt-0.5"
                    />
                    <span className="text-sm">
                      <span className="font-bold block">Customer</span>
                      <span className="text-muted-foreground text-xs">Shop and collect loyalty points on purchases.</span>
                    </span>
                  </label>
                  <label
                    className={`flex items-start gap-3 rounded-lg border px-3 py-2.5 cursor-pointer transition-colors ${
                      accountRole === "producer" ? "border-primary bg-primary/5" : "border-border"
                    }`}
                  >
                    <input
                      type="radio"
                      name="accountRole"
                      checked={accountRole === "producer"}
                      onChange={() => setAccountRole("producer")}
                      className="accent-primary mt-0.5"
                    />
                    <span className="text-sm">
                      <span className="font-bold block">Producer</span>
                      <span className="text-muted-foreground text-xs">
                        Shop like a customer plus access the producer dashboard to manage listings.
                      </span>
                    </span>
                  </label>
                </div>
              </div>
            )}

            {!isLogin && (
              <label className="flex items-start gap-2 text-sm cursor-pointer">
                <input
                  type="checkbox"
                  checked={consent}
                  onChange={(e) => setConsent(e.target.checked)}
                  className="accent-primary mt-0.5 w-4 h-4"
                />
                <span>
                  I agree to GLH storing my data in accordance with the{" "}
                  <Link to="/privacy" className="text-primary font-semibold underline">Privacy Policy</Link>
                </span>
              </label>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full bg-primary text-primary-foreground font-bold py-2.5 rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50"
            >
              {submitting ? "Please wait..." : isLogin ? "Sign In" : "Create Account"}
            </button>
          </form>

          <p className="text-center text-sm mt-4 text-muted-foreground">
            {isLogin ? "Don't have an account?" : "Already have an account?"}{" "}
            <button
              onClick={() => setIsLogin(!isLogin)}
              className="text-primary font-semibold underline"
            >
              {isLogin ? "Create one" : "Sign in"}
            </button>
          </p>
        </div>
      </main>
      <Footer />
    </div>
  );
}
