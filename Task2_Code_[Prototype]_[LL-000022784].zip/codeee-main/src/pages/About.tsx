import { Link } from "react-router-dom";
import Footer from "@/components/Footer";

export default function About() {
  return (
    <div className="flex flex-col min-h-screen">
      <nav className="bg-primary px-4 py-3">
        <div className="container mx-auto">
          <Link to="/" className="text-primary-foreground font-serif text-xl font-bold">
            Local Produce Hub
          </Link>
        </div>
      </nav>
      <main className="container mx-auto flex-1 max-w-3xl px-4 py-8">
        <h1 className="text-2xl font-bold font-serif text-primary mb-4">About Greenfield Local Hub</h1>
        <p className="mb-4">
          Greenfield Local Hub (GLH) is a cooperative of local farmers and food producers dedicated to bringing fresh, locally sourced food directly to your table. We offer a single retail location and an online platform where you can browse, order and collect or receive delivery of the finest produce from our community.
        </p>
        <h2 className="text-xl font-bold font-serif text-primary mt-6 mb-2">Our Mission</h2>
        <p className="mb-4">
          We believe in transparent pricing, full traceability from farm to fork, and supporting the livelihoods of local farmers. Every product on our platform can be traced back to the producer and the specific batch it came from, meeting the highest food safety standards.
        </p>
        <h2 className="text-xl font-bold font-serif text-primary mt-6 mb-2">Our Producers</h2>
        <p className="mb-4">
          From Hillside Apiary's golden honey to Green Acres Farm's crisp mixed salads, our cooperative brings together passionate producers who care about quality, sustainability and community. Each producer manages their own stock and product details through our dedicated dashboard.
        </p>
        <h2 className="text-xl font-bold font-serif text-primary mt-6 mb-2">Benefits of Buying Locally</h2>
        <ul className="list-disc list-inside space-y-2 mb-4">
          <li>Fresher produce with fewer food miles</li>
          <li>Support for the local economy and farming communities</li>
          <li>Full traceability and transparency about how your food is produced</li>
          <li>Seasonal variety and unique artisan products</li>
        </ul>
      </main>
      <Footer />
    </div>
  );
}
