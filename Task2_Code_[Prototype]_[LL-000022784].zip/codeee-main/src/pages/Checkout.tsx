import { useState, useEffect, useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useCart } from "@/context/CartContext";
import type { CartItem } from "@/context/CartContext";
import { useAuth } from "@/context/AuthContext";
import Footer from "@/components/Footer";
import { toast } from "sonner";
import { Trash2, Minus, Plus, ShoppingBag, Clock, CreditCard, Check, ArrowLeft, User, UserPlus, MapPin, Phone, Mail } from "lucide-react";
import {
  formatAddress,
  loadCheckoutProfile,
  saveCheckoutProfile,
  type SavedDeliveryAddress,
} from "@/lib/checkoutProfile";
import { postOrderCheckout } from "@/lib/api/loyalty";
import { redemptionOptions } from "@/lib/loyaltyRules";

const logo = "/favicon-glh.svg";
const DELIVERY_FEE_PENCE = 350;

const slots = [
  { time: "09:00", status: "available" as const },
  { time: "10:00", status: "available" as const },
  { time: "11:00", status: "full" as const },
  { time: "14:00", status: "available" as const },
  { time: "15:00", status: "low" as const },
  { time: "16:00", status: "available" as const },
];

const emptyDelivery: SavedDeliveryAddress = { line1: "", line2: "", city: "", postcode: "", phone: "" };

function digitsOnly(s: string) {
  return s.replace(/\D/g, "");
}

function last4FromCardInput(cardNumber: string) {
  const d = digitsOnly(cardNumber);
  return d.slice(-4).padStart(4, "0").slice(-4);
}

export default function Checkout() {
  const {
    items,
    subtotal,
    pointsToRedeem,
    setPointsToRedeem,
    loyaltyDiscount,
    totalToPay,
    maxRedeemableForCart,
    redeemablePoints,
    refreshLoyalty,
    removeFromCart,
    updateQuantity,
    clearCart,
  } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
  const [fulfillmentType, setFulfillmentType] = useState<"collection" | "delivery">("collection");
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [orderNumber] = useState(() => `#${Math.floor(1000 + Math.random() * 9000)}`);
  const [confirmedTotalGbp, setConfirmedTotalGbp] = useState(0);

  // Guest info
  const [guestName, setGuestName] = useState("");
  const [guestEmail, setGuestEmail] = useState("");
  const [guestPhone, setGuestPhone] = useState("");
  const [delivery, setDelivery] = useState<SavedDeliveryAddress>({ ...emptyDelivery });

  const [cardholderName, setCardholderName] = useState("");
  const [cardNumber, setCardNumber] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");
  const [useSavedPayment, setUseSavedPayment] = useState(false);

  const savedProfile = useMemo(() => (user?.email ? loadCheckoutProfile(user.email) : null), [user?.email]);

  useEffect(() => {
    if (!user?.email) return;
    const saved = loadCheckoutProfile(user.email);
    if (saved?.delivery) {
      setDelivery((d) => ({
        line1: saved.delivery.line1 || d.line1,
        line2: saved.delivery.line2 || d.line2,
        city: saved.delivery.city || d.city,
        postcode: saved.delivery.postcode || d.postcode,
        phone: saved.delivery.phone || d.phone,
      }));
    }
    if (saved?.payment?.cardholderName) {
      setCardholderName(saved.payment.cardholderName);
    }
    setUseSavedPayment(Boolean(saved?.payment?.cardLast4 && saved.payment.cardLast4.length === 4));
  }, [user?.email]);

  const deliveryFieldsComplete = useMemo(() => {
    const pc = delivery.postcode.replace(/\s/g, "");
    const phoneOk = delivery.phone.trim().length > 0 || (!user && guestPhone.trim().length > 0);
    return (
      delivery.line1.trim().length > 0 &&
      delivery.city.trim().length > 0 &&
      pc.length >= 5 &&
      phoneOk
    );
  }, [delivery.line1, delivery.city, delivery.postcode, delivery.phone, guestPhone, user]);

  const deliveryChargePence = fulfillmentType === "delivery" ? DELIVERY_FEE_PENCE : 0;
  const finalPayableGbp =
    (Math.round(subtotal * 100) - Math.round(pointsToRedeem) + deliveryChargePence) / 100;

  const handlePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    const merchPence = Math.round(subtotal * 100);
    const discPence = Math.round(pointsToRedeem);

    if (user?.email) {
      const last4 =
        useSavedPayment && savedProfile?.payment?.cardLast4
          ? savedProfile.payment.cardLast4
          : last4FromCardInput(cardNumber);
      const exp =
        useSavedPayment && savedProfile?.payment?.expiry ? savedProfile.payment.expiry : expiry.trim();
      const name = cardholderName.trim() || savedProfile?.payment?.cardholderName || "";
      if (!useSavedPayment) {
        const pan = digitsOnly(cardNumber);
        if (pan.length < 13 || pan.length > 19) {
          toast.error("Please enter a valid card number");
          return;
        }
        if (!/^\d{2}\/\d{2}$/.test(expiry.trim())) {
          toast.error("Enter expiry as MM/YY");
          return;
        }
        if (cvv.trim().length < 3) {
          toast.error("Please enter your card security code");
          return;
        }
      } else if (!savedProfile?.payment?.cardLast4) {
        toast.error("No saved card on file — enter your card details");
        setUseSavedPayment(false);
        return;
      }
      saveCheckoutProfile(user.email, {
        delivery: { ...delivery, phone: delivery.phone.trim() || guestPhone.trim() },
        payment: { cardholderName: name, cardLast4: last4, expiry: exp },
      });

      try {
        await postOrderCheckout({
          merchandiseSubtotalPence: merchPence,
          deliveryChargePence: deliveryChargePence,
          pointsToRedeem: discPence,
          idempotencyKey: crypto.randomUUID(),
          fulfillmentType,
          items: items.map((item) => ({
            productId: item.product.id,
            productName: item.product.name,
            unitPricePence: Math.round(item.product.price * 100),
            quantity: item.quantity,
          })),
        });
        await refreshLoyalty();
      } catch (err) {
        toast.error(err instanceof Error ? err.message : "Checkout failed");
        return;
      }
    }

    setConfirmedTotalGbp((merchPence - discPence + deliveryChargePence) / 100);
    setOrderPlaced(true);
  };

  const handleBackToShopping = () => {
    clearCart();
    navigate("/");
  };

  const stepIcons = [ShoppingBag, User, Clock, CreditCard];
  const stepLabels = ["Basket", "Details", "Slot", "Payment"];
  const totalSteps = 4;

  // Step flow: 1=Basket, 2=Details, 3=Slot, 4=Payment
  if (items.length === 0 && !orderPlaced) {
    return (
      <div className="flex flex-col min-h-screen">
        <CheckoutNav />
        <div className="flex-1 flex flex-col items-center justify-center gap-4 animate-fade-up">
          <ShoppingBag className="h-16 w-16 text-muted-foreground/30" />
          <p className="text-muted-foreground text-lg font-semibold">Your basket is empty</p>
          <Link to="/" className="bg-gradient-to-r from-primary to-primary-light text-primary-foreground px-8 py-3 rounded-full font-bold hover:shadow-glow transition-all duration-300">
            Continue Shopping
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  // Order confirmation screen
  if (orderPlaced) {
    return (
      <div className="flex flex-col min-h-screen">
        <CheckoutNav />
        <main className="container mx-auto flex-1 max-w-2xl px-4 py-12">
          <div className="animate-fade-in text-center">
            <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4 shadow-glow">
              <Check className="h-8 w-8 text-primary-foreground" />
            </div>
            <h2 className="font-serif font-bold text-2xl mb-2">Order Confirmed!</h2>
            <p className="text-muted-foreground mb-8">Thank you for shopping with Local Produce Hub</p>

            <div className="bg-card border border-border rounded-2xl p-6 shadow-sm text-left mb-6">
              <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                <ShoppingBag className="h-5 w-5 text-primary" />
                Order {orderNumber}
              </h3>

              <div className="space-y-3 mb-6">
                <div className="flex items-center gap-2 text-sm">
                  <Clock className="h-4 w-4 text-primary" />
                  <span className="font-semibold">{fulfillmentType === "collection" ? "Collection" : "Delivery"} Slot:</span>
                  <span>{selectedSlot} — Today</span>
                </div>

                {fulfillmentType === "collection" ? (
                  <div className="bg-primary/5 border border-primary/20 rounded-xl p-4">
                    <h4 className="font-bold text-sm mb-2 flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-primary" />
                      Collection Point
                    </h4>
                    <p className="text-sm">Local Produce Hub</p>
                    <p className="text-sm text-muted-foreground">Greenfield Community Market</p>
                    <p className="text-sm text-muted-foreground">12 High Street, Greenfield, GL1 2AB</p>
                    <p className="text-xs text-muted-foreground mt-2">Please bring your order confirmation email or screenshot</p>
                  </div>
                ) : (
                  <div className="bg-primary/5 border border-primary/20 rounded-xl p-4">
                    <h4 className="font-bold text-sm mb-2 flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-primary" />
                      Delivery Address
                    </h4>
                    <p className="text-sm">
                      {formatAddress({
                        ...delivery,
                        phone: delivery.phone.trim() || guestPhone.trim(),
                      }) || "—"}
                    </p>
                    <p className="text-xs text-muted-foreground mt-2">You'll receive a text when the driver is 10 minutes away</p>
                  </div>
                )}

                <div className="flex items-center gap-2 text-sm">
                  <Mail className="h-4 w-4 text-primary" />
                  <span>Confirmation sent to: <span className="font-semibold">{user?.email || guestEmail}</span></span>
                </div>
              </div>

              <div className="border-t border-border pt-4">
                <div className="flex justify-between font-bold text-lg">
                  <span>Total Paid</span>
                  <span>£{confirmedTotalGbp.toFixed(2)}</span>
                </div>
              </div>
            </div>

            <button
              onClick={handleBackToShopping}
              className="bg-gradient-to-r from-primary to-primary-light text-primary-foreground font-bold px-8 py-3 rounded-xl hover:shadow-glow transition-all duration-300"
            >
              Back to Shopping
            </button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen">
      <CheckoutNav />

      <main className="container mx-auto flex-1 max-w-2xl px-4 py-8">
        {/* Step indicator */}
        <div className="flex items-center justify-between mb-10 relative">
          <div className="absolute top-5 left-0 right-0 h-0.5 bg-border" />
          <div
            className="absolute top-5 left-0 h-0.5 bg-primary transition-all duration-500"
            style={{ width: `${((step - 1) / (totalSteps - 1)) * 100}%` }}
          />
          {stepLabels.map((label, i) => {
            const Icon = stepIcons[i];
            const isActive = i + 1 === step;
            const isDone = i + 1 < step;
            return (
              <button
                key={label}
                onClick={() => i + 1 < step && setStep(i + 1)}
                className="relative flex flex-col items-center gap-2 z-10"
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 ${
                    isDone
                      ? "bg-primary text-primary-foreground shadow-glow"
                      : isActive
                      ? "bg-primary text-primary-foreground shadow-glow scale-110"
                      : "bg-card text-muted-foreground border-2 border-border"
                  }`}
                >
                  {isDone ? <Check className="h-5 w-5" /> : <Icon className="h-5 w-5" />}
                </div>
                <span className={`text-xs font-bold ${isActive ? "text-primary" : "text-muted-foreground"}`}>
                  {label}
                </span>
              </button>
            );
          })}
        </div>

        {/* Step 1: Basket */}
        {step === 1 && (
          <BasketStep
            items={items}
            subtotal={subtotal}
            user={user}
            pointsToRedeem={pointsToRedeem}
            setPointsToRedeem={setPointsToRedeem}
            maxRedeemableForCart={maxRedeemableForCart}
            redeemablePoints={redeemablePoints}
            loyaltyDiscount={loyaltyDiscount}
            totalToPay={totalToPay}
            removeFromCart={removeFromCart}
            updateQuantity={updateQuantity}
            onContinue={() => setStep(2)}
          />
        )}

        {/* Step 2: Guest or Account */}
        {step === 2 && (
          <div className="animate-fade-in">
            <h2 className="font-serif font-bold text-xl mb-5">Your Details</h2>

            {user ? (
              <div className="bg-card border border-border rounded-2xl p-6 shadow-sm mb-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold">
                    {user.email?.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <p className="font-bold text-sm">Signed in as</p>
                    <p className="text-sm text-muted-foreground">{user.email}</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-bold block mb-1.5">Fulfillment Type</label>
                    <div className="flex gap-3">
                      <button
                        onClick={() => setFulfillmentType("collection")}
                        className={`flex-1 py-3 rounded-xl font-bold text-sm border-2 transition-all ${fulfillmentType === "collection" ? "border-primary bg-primary text-primary-foreground shadow-glow" : "border-border bg-card hover:border-primary/50"}`}
                      >
                        🏪 Collection
                      </button>
                      <button
                        onClick={() => setFulfillmentType("delivery")}
                        className={`flex-1 py-3 rounded-xl font-bold text-sm border-2 transition-all ${fulfillmentType === "delivery" ? "border-primary bg-primary text-primary-foreground shadow-glow" : "border-border bg-card hover:border-primary/50"}`}
                      >
                        🚚 Delivery
                      </button>
                    </div>
                  </div>
                  {fulfillmentType === "delivery" && (
                    <DeliveryAddressFields delivery={delivery} onChange={setDelivery} />
                  )}
                </div>

                <div className="flex gap-3 mt-6">
                  <button onClick={() => setStep(1)} className="flex-1 bg-secondary text-secondary-foreground font-bold py-3 rounded-xl hover:bg-secondary/80 transition-all">Back</button>
                  <button
                    onClick={() => setStep(3)}
                    disabled={fulfillmentType === "delivery" && !deliveryFieldsComplete}
                    className="flex-1 bg-gradient-to-r from-primary to-primary-light text-primary-foreground font-bold py-3 rounded-xl hover:shadow-glow transition-all duration-300 disabled:opacity-40"
                  >
                    Continue to Slot Selection
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Guest checkout */}
                <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
                  <h3 className="font-bold text-base mb-4 flex items-center gap-2">
                    <User className="h-4 w-4 text-primary" />
                    Continue as Guest
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-bold block mb-1.5">Full Name *</label>
                      <input
                        type="text" value={guestName} onChange={(e) => setGuestName(e.target.value)}
                        placeholder="Your full name"
                        className="w-full border border-input rounded-xl px-4 py-3 text-sm bg-background focus:ring-2 focus:ring-ring outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-bold block mb-1.5">Email *</label>
                      <input
                        type="email" value={guestEmail} onChange={(e) => setGuestEmail(e.target.value)}
                        placeholder="your@email.com"
                        className="w-full border border-input rounded-xl px-4 py-3 text-sm bg-background focus:ring-2 focus:ring-ring outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-bold block mb-1.5">Phone</label>
                      <input
                        type="tel" value={guestPhone} onChange={(e) => setGuestPhone(e.target.value)}
                        placeholder="+44 7700 000000"
                        className="w-full border border-input rounded-xl px-4 py-3 text-sm bg-background focus:ring-2 focus:ring-ring outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-bold block mb-1.5">Fulfillment Type</label>
                      <div className="flex gap-3">
                        <button
                          onClick={() => setFulfillmentType("collection")}
                          className={`flex-1 py-3 rounded-xl font-bold text-sm border-2 transition-all ${fulfillmentType === "collection" ? "border-primary bg-primary text-primary-foreground shadow-glow" : "border-border bg-card hover:border-primary/50"}`}
                        >
                          🏪 Collection
                        </button>
                        <button
                          onClick={() => setFulfillmentType("delivery")}
                          className={`flex-1 py-3 rounded-xl font-bold text-sm border-2 transition-all ${fulfillmentType === "delivery" ? "border-primary bg-primary text-primary-foreground shadow-glow" : "border-border bg-card hover:border-primary/50"}`}
                        >
                          🚚 Delivery
                        </button>
                      </div>
                    </div>
                    {fulfillmentType === "delivery" && (
                      <DeliveryAddressFields delivery={delivery} onChange={setDelivery} />
                    )}
                    <div className="flex gap-3">
                      <button onClick={() => setStep(1)} className="flex-1 bg-secondary text-secondary-foreground font-bold py-3 rounded-xl hover:bg-secondary/80 transition-all">Back</button>
                      <button
                        onClick={() => {
                          if (!guestName.trim() || !guestEmail.trim()) {
                            toast.error("Please fill in your name and email");
                            return;
                          }
                          if (fulfillmentType === "delivery" && !deliveryFieldsComplete) {
                            toast.error("Please complete street, city, postcode (at least 5 characters), and a contact phone for delivery");
                            return;
                          }
                          setStep(3);
                        }}
                        className="flex-1 bg-gradient-to-r from-primary to-primary-light text-primary-foreground font-bold py-3 rounded-xl hover:shadow-glow transition-all duration-300"
                      >
                        Continue as Guest
                      </button>
                    </div>
                  </div>
                </div>

                {/* Or register */}
                <div className="relative flex items-center justify-center">
                  <div className="border-t border-border flex-1" />
                  <span className="px-4 text-sm text-muted-foreground font-semibold">or</span>
                  <div className="border-t border-border flex-1" />
                </div>

                <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
                  <h3 className="font-bold text-base mb-2 flex items-center gap-2">
                    <UserPlus className="h-4 w-4 text-primary" />
                    Create an Account
                  </h3>
                  <p className="text-sm text-muted-foreground mb-4">Save your details, earn loyalty points, and track orders easily.</p>
                  <div className="flex gap-3">
                    <Link
                      to="/account?mode=register&redirect=checkout"
                      className="flex-1 text-center bg-gradient-to-r from-primary to-primary-light text-primary-foreground font-bold py-3 rounded-xl hover:shadow-glow transition-all duration-300"
                    >
                      Register Now
                    </Link>
                    <Link
                      to="/account?redirect=checkout"
                      className="flex-1 text-center bg-secondary text-secondary-foreground font-bold py-3 rounded-xl hover:bg-secondary/80 transition-all"
                    >
                      Sign In
                    </Link>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Step 3: Slot */}
        {step === 3 && (
          <div className="animate-fade-in">
            <h2 className="font-serif font-bold text-xl mb-5">
              Select Your {fulfillmentType === "collection" ? "Collection" : "Delivery"} Slot
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {slots.map((s) => {
                const isSelected = selectedSlot === s.time;
                let btnClass = "border-2 rounded-xl py-4 text-sm font-bold transition-all duration-200 ";
                if (s.status === "full") {
                  btnClass += "bg-destructive/10 text-destructive border-destructive/30 cursor-not-allowed opacity-60";
                } else if (isSelected) {
                  btnClass += "bg-primary text-primary-foreground border-primary shadow-glow scale-105";
                } else if (s.status === "low") {
                  btnClass += "bg-warning/10 text-warning border-warning/50 hover:border-warning hover:shadow-sm";
                } else {
                  btnClass += "bg-success/10 text-success border-success/50 hover:border-success hover:shadow-sm";
                }

                return (
                  <button
                    key={s.time}
                    disabled={s.status === "full"}
                    onClick={() => setSelectedSlot(s.time)}
                    className={btnClass}
                  >
                    <span className="block text-lg">{s.time}</span>
                    <span className="block text-xs mt-0.5 opacity-80">
                      {s.status === "full" ? "Full" : s.status === "low" ? "1 left" : "Available"}
                    </span>
                  </button>
                );
              })}
            </div>

            <div className="flex gap-3 mt-8">
              <button onClick={() => setStep(2)} className="flex-1 bg-secondary text-secondary-foreground font-bold py-3 rounded-xl hover:bg-secondary/80 transition-all duration-200">
                Back
              </button>
              <button
                disabled={!selectedSlot}
                onClick={() => setStep(4)}
                className="flex-1 bg-gradient-to-r from-primary to-primary-light text-primary-foreground font-bold py-3 rounded-xl hover:shadow-glow transition-all duration-300 disabled:opacity-40"
              >
                Continue to Payment
              </button>
            </div>
          </div>
        )}

        {/* Step 4: Payment */}
        {step === 4 && (
          <div className="animate-fade-in">
            <h2 className="font-serif font-bold text-xl mb-5">Payment (Secured by Stripe)</h2>
            <div className="bg-card border border-border rounded-2xl p-6 shadow-elegant">
              <form onSubmit={handlePayment} className="space-y-5">
                {user && savedProfile?.payment?.cardLast4 && (
                  <label className="flex items-start gap-3 rounded-xl border border-border bg-muted/30 px-4 py-3 cursor-pointer">
                    <input
                      type="checkbox"
                      className="mt-1"
                      checked={useSavedPayment}
                      onChange={(e) => setUseSavedPayment(e.target.checked)}
                    />
                    <span className="text-sm">
                      <span className="font-bold block">Use saved card</span>
                      <span className="text-muted-foreground">
                        {savedProfile.payment.cardholderName} — ending {savedProfile.payment.cardLast4}, exp{" "}
                        {savedProfile.payment.expiry}
                      </span>
                    </span>
                  </label>
                )}

                {!useSavedPayment && (
                  <>
                    <div>
                      <label htmlFor="cardholderName" className="text-sm font-bold block mb-1.5">
                        Name on card
                      </label>
                      <input
                        id="cardholderName"
                        type="text"
                        autoComplete="cc-name"
                        value={cardholderName}
                        onChange={(e) => setCardholderName(e.target.value)}
                        placeholder="As shown on your card"
                        required={!useSavedPayment}
                        className="w-full border border-input rounded-xl px-4 py-3 text-sm bg-background focus:ring-2 focus:ring-ring focus:border-primary outline-none transition-all"
                      />
                    </div>
                    <div>
                      <label htmlFor="cardNumber" className="text-sm font-bold block mb-1.5">
                        Card number
                      </label>
                      <input
                        id="cardNumber"
                        type="text"
                        inputMode="numeric"
                        autoComplete="cc-number"
                        value={cardNumber}
                        onChange={(e) => setCardNumber(e.target.value)}
                        placeholder="•••• •••• •••• ••••"
                        required={!useSavedPayment}
                        maxLength={23}
                        className="w-full border border-input rounded-xl px-4 py-3 text-sm bg-background focus:ring-2 focus:ring-ring focus:border-primary outline-none transition-all"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="expiry" className="text-sm font-bold block mb-1.5">
                          Expiry
                        </label>
                        <input
                          id="expiry"
                          type="text"
                          autoComplete="cc-exp"
                          value={expiry}
                          onChange={(e) => setExpiry(e.target.value)}
                          placeholder="MM/YY"
                          required={!useSavedPayment}
                          maxLength={5}
                          className="w-full border border-input rounded-xl px-4 py-3 text-sm bg-background focus:ring-2 focus:ring-ring focus:border-primary outline-none transition-all"
                        />
                      </div>
                      <div>
                        <label htmlFor="cvv" className="text-sm font-bold block mb-1.5">
                          CVV
                        </label>
                        <input
                          id="cvv"
                          type="password"
                          autoComplete="cc-csc"
                          value={cvv}
                          onChange={(e) => setCvv(e.target.value)}
                          placeholder="***"
                          required={!useSavedPayment}
                          maxLength={4}
                          className="w-full border border-input rounded-xl px-4 py-3 text-sm bg-background focus:ring-2 focus:ring-ring focus:border-primary outline-none transition-all"
                        />
                      </div>
                    </div>
                  </>
                )}

                {useSavedPayment && (
                  <p className="text-xs text-muted-foreground">
                    Full card numbers and CVV are not stored on this device. Only the cardholder name, last four digits,
                    and expiry are saved locally for quicker checkout next time.
                  </p>
                )}

                <div className="flex gap-3 mt-2">
                  <button
                    type="button"
                    onClick={() => setStep(3)}
                    className="flex-1 bg-secondary text-secondary-foreground font-bold py-3 rounded-xl hover:bg-secondary/80 transition-all"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    className="flex-1 bg-gradient-to-r from-primary to-primary-light text-primary-foreground font-bold py-3 rounded-xl hover:shadow-glow transition-all duration-300 active:scale-[0.99]"
                  >
                    Pay £{finalPayableGbp.toFixed(2)} Securely
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}

function DeliveryAddressFields({
  delivery,
  onChange,
}: {
  delivery: SavedDeliveryAddress;
  onChange: (next: SavedDeliveryAddress) => void;
}) {
  const patch = (partial: Partial<SavedDeliveryAddress>) => onChange({ ...delivery, ...partial });
  return (
    <div className="space-y-3">
      <p className="text-xs text-muted-foreground font-semibold flex items-center gap-1.5">
        <MapPin className="h-3.5 w-3.5 text-primary" />
        Delivery address (please be precise — drivers use this to find you)
      </p>
      <div>
        <label className="text-sm font-bold block mb-1.5">Street / building number *</label>
        <input
          type="text"
          value={delivery.line1}
          onChange={(e) => patch({ line1: e.target.value })}
          placeholder="e.g. 12 High Street"
          className="w-full border border-input rounded-xl px-4 py-3 text-sm bg-background focus:ring-2 focus:ring-ring outline-none"
        />
      </div>
      <div>
        <label className="text-sm font-bold block mb-1.5">Address line 2 (optional)</label>
        <input
          type="text"
          value={delivery.line2}
          onChange={(e) => patch({ line2: e.target.value })}
          placeholder="Flat, floor, business name…"
          className="w-full border border-input rounded-xl px-4 py-3 text-sm bg-background focus:ring-2 focus:ring-ring outline-none"
        />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="text-sm font-bold block mb-1.5">Town / city *</label>
          <input
            type="text"
            value={delivery.city}
            onChange={(e) => patch({ city: e.target.value })}
            placeholder="e.g. Greenfield"
            className="w-full border border-input rounded-xl px-4 py-3 text-sm bg-background focus:ring-2 focus:ring-ring outline-none"
          />
        </div>
        <div>
          <label className="text-sm font-bold block mb-1.5">Postcode *</label>
          <input
            type="text"
            value={delivery.postcode}
            onChange={(e) => patch({ postcode: e.target.value.toUpperCase() })}
            placeholder="e.g. GL1 2AB"
            autoComplete="postal-code"
            className="w-full border border-input rounded-xl px-4 py-3 text-sm bg-background focus:ring-2 focus:ring-ring outline-none"
          />
        </div>
      </div>
      <div>
        <label className="text-sm font-bold block mb-1.5 flex items-center gap-2">
          <Phone className="h-3.5 w-3.5 text-primary" />
          Contact phone for delivery *
        </label>
        <input
          type="tel"
          value={delivery.phone}
          onChange={(e) => patch({ phone: e.target.value })}
          placeholder="+44 7700 900000"
          autoComplete="tel"
          className="w-full border border-input rounded-xl px-4 py-3 text-sm bg-background focus:ring-2 focus:ring-ring outline-none"
        />
        <p className="text-[11px] text-muted-foreground mt-1">
          Guests can use the same number as above if you already entered a phone in your details.
        </p>
      </div>
    </div>
  );
}

function CheckoutNav() {
  return (
    <nav className="bg-gradient-to-r from-primary-dark via-primary to-primary-dark px-4 py-3 shadow-lg">
      <div className="container mx-auto flex items-center justify-between">
        <Link to="/" className="group flex items-center gap-2.5 text-primary-foreground font-serif text-xl font-bold">
          <img
            src={logo}
            alt="GLH Logo"
            className="h-10 w-10 rounded-lg ring-2 ring-primary-foreground/40 shadow-md transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3"
          />
          Local Produce Hub
        </Link>
        <Link to="/" className="text-primary-foreground/80 hover:text-primary-foreground text-sm font-semibold flex items-center gap-1 transition-colors">
          <ArrowLeft className="h-4 w-4" />
          Continue Shopping
        </Link>
      </div>
    </nav>
  );
}

function BasketStep({
  items,
  subtotal,
  user,
  pointsToRedeem,
  setPointsToRedeem,
  maxRedeemableForCart,
  redeemablePoints,
  loyaltyDiscount,
  totalToPay,
  removeFromCart,
  updateQuantity,
  onContinue,
}: {
  items: CartItem[];
  subtotal: number;
  user: { email?: string | null } | null;
  pointsToRedeem: number;
  setPointsToRedeem: (n: number) => void;
  maxRedeemableForCart: number;
  redeemablePoints: number;
  loyaltyDiscount: number;
  totalToPay: number;
  removeFromCart: (id: string) => void;
  updateQuantity: (id: string, qty: number) => void;
  onContinue: () => void;
}) {
  const redemptionChoices = redemptionOptions(maxRedeemableForCart);

  return (
    <div className="animate-fade-in">
      <h2 className="font-serif font-bold text-xl mb-5">Your Order</h2>
      <div className="space-y-3">
        {items.map((item) => (
          <div key={item.product.id} className="bg-card border border-border rounded-xl p-4 flex items-center justify-between shadow-sm hover:shadow-elegant transition-shadow duration-200">
            <div className="flex items-center gap-3 flex-1">
              <img src={item.product.image} alt={item.product.name} className="w-12 h-12 rounded-lg object-cover" />
              <div>
                <p className="font-bold text-sm">{item.product.name}</p>
                <p className="text-muted-foreground text-xs">{item.product.producer}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => updateQuantity(item.product.id, item.quantity - 1)} className="p-1.5 rounded-lg bg-secondary hover:bg-accent transition-colors" aria-label="Decrease quantity">
                <Minus className="h-3 w-3" />
              </button>
              <span className="text-sm font-bold w-6 text-center">{item.quantity}</span>
              <button onClick={() => updateQuantity(item.product.id, item.quantity + 1)} className="p-1.5 rounded-lg bg-secondary hover:bg-accent transition-colors" aria-label="Increase quantity">
                <Plus className="h-3 w-3" />
              </button>
            </div>
            <p className="font-bold text-sm w-16 text-right">
              £{(item.product.price * item.quantity).toFixed(2)}
            </p>
            <button onClick={() => removeFromCart(item.product.id)} className="ml-3 text-destructive/60 hover:text-destructive transition-colors p-1" aria-label={`Remove ${item.product.name}`}>
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>

      {user && maxRedeemableForCart > 0 && (
        <div className="bg-card border border-border rounded-xl px-5 py-4 mt-4 shadow-sm">
          <label htmlFor="loyalty-redeem" className="text-sm font-bold block mb-2">
            Use loyalty points (75–750, steps of 75)
          </label>
          <p className="text-xs text-muted-foreground mb-2">
            You can spend up to <span className="font-semibold text-foreground">{maxRedeemableForCart}</span> pts on
            this basket ({redeemablePoints} pts currently available before expiry).
          </p>
          <select
            id="loyalty-redeem"
            value={pointsToRedeem}
            onChange={(e) => setPointsToRedeem(Number(e.target.value))}
            className="w-full border border-input rounded-xl px-4 py-2.5 text-sm font-semibold bg-background"
          >
            {redemptionChoices.map((p) => (
              <option key={p} value={p}>
                {p === 0 ? "Do not redeem points" : `Redeem ${p} pts (£${(p / 100).toFixed(2)} off)`}
              </option>
            ))}
          </select>
        </div>
      )}

      {user && maxRedeemableForCart === 0 && redeemablePoints > 0 && (
        <p className="text-xs text-muted-foreground mt-4 px-1">
          Loyalty redemption is disabled until your basket reaches at least £0.75 (75 pts minimum).
        </p>
      )}

      {loyaltyDiscount > 0 && (
        <div className="bg-loyalty-bg border border-loyalty-border/30 rounded-xl px-5 py-3 mt-4 flex justify-between text-sm shadow-sm">
          <span className="text-accent-foreground font-semibold">
            Loyalty Discount ({pointsToRedeem} pts applied):
          </span>
          <span className="font-bold text-primary">-£{loyaltyDiscount.toFixed(2)}</span>
        </div>
      )}

      <div className="bg-gradient-to-r from-primary to-primary-light text-primary-foreground rounded-xl px-5 py-3 mt-2 flex justify-between font-bold text-lg shadow-glow">
        <span>Total to Pay:</span>
        <span>£{totalToPay.toFixed(2)}</span>
      </div>

      <button
        onClick={onContinue}
        className="w-full mt-6 bg-gradient-to-r from-primary to-primary-light text-primary-foreground font-bold py-3.5 rounded-xl hover:shadow-glow transition-all duration-300 active:scale-[0.99]"
      >
        Continue to Details
      </button>
    </div>
  );
}
