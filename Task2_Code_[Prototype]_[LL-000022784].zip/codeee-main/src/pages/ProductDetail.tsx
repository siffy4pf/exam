import { useParams, Link } from "react-router-dom";
import { products, getStockStatus } from "@/data/products";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import StockBadge from "@/components/StockBadge";
import { useCart } from "@/context/CartContext";
import { toast } from "sonner";
import { ArrowLeft, Plus, MapPin, ShieldCheck, Tag, Package, AlertTriangle } from "lucide-react";

// Product detail page: detailed info + add-to-basket action.
export default function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const { addToCart } = useCart();
  const product = products.find((p) => p.id === id);

  if (!product) {
    return (
      <div className="flex flex-col min-h-screen">
        <Navbar />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold font-serif mb-2">Product Not Found</h1>
            <p className="text-muted-foreground mb-4">The product you're looking for doesn't exist.</p>
            <Link to="/" className="text-primary font-semibold hover:underline">← Back to shop</Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const status = getStockStatus(product.stock);
  const relatedProducts = products.filter(
    (p) => p.category === product.category && p.id !== product.id
  ).slice(0, 3);

  const handleAdd = () => {
    // Block add if stock is empty, otherwise add to basket.
    if (status === "out-of-stock") return;
    addToCart(product);
    toast.success(`${product.name} added to basket`);
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1 container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
          <Link to="/" className="hover:text-primary transition-colors">Home</Link>
          <span>/</span>
          <Link to="/products" className="hover:text-primary transition-colors">Products</Link>
          <span>/</span>
          <span className="text-foreground font-medium">{product.name}</span>
        </nav>

        <Link to="/" className="inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:underline mb-6">
          <ArrowLeft className="h-4 w-4" />
          Back to shop
        </Link>

        {/* Product detail grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Image */}
          <div className="relative rounded-2xl overflow-hidden bg-card border border-border">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-[300px] md:h-[450px] object-cover"
            />
            <div className="absolute top-4 right-4">
              <StockBadge stock={product.stock} />
            </div>
          </div>

          {/* Info */}
          <div className="flex flex-col">
            <div className="mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-primary bg-primary/10 px-2.5 py-1 rounded-full">
                {product.category}
              </span>
            </div>
            <h1 className="text-3xl md:text-4xl font-bold font-serif mb-2">{product.name}</h1>
            <p className="text-muted-foreground text-sm flex items-center gap-1.5 mb-4">
              <MapPin className="h-3.5 w-3.5" />
              {product.producer} {product.origin && `· ${product.origin}`}
            </p>

            <p className="text-primary font-extrabold text-3xl mb-4">£{product.price.toFixed(2)}</p>

            {product.description && (
              <p className="text-foreground/80 leading-relaxed mb-6">{product.description}</p>
            )}

            {/* Details grid */}
            <div className="grid grid-cols-2 gap-3 mb-6">
              {product.weight && (
                <div className="bg-accent/50 rounded-xl p-3">
                  <p className="text-xs text-muted-foreground flex items-center gap-1 mb-0.5">
                    <Package className="h-3 w-3" /> Weight
                  </p>
                  <p className="font-semibold text-sm">{product.weight}</p>
                </div>
              )}
              <div className="bg-accent/50 rounded-xl p-3">
                <p className="text-xs text-muted-foreground flex items-center gap-1 mb-0.5">
                  <Tag className="h-3 w-3" /> Batch Ref
                </p>
                <p className="font-semibold text-sm">{product.batchRef}</p>
              </div>
              <div className="bg-accent/50 rounded-xl p-3">
                <p className="text-xs text-muted-foreground flex items-center gap-1 mb-0.5">
                  <ShieldCheck className="h-3 w-3" /> Traceability
                </p>
                <p className="font-semibold text-sm">Fully Traceable</p>
              </div>
              <div className="bg-accent/50 rounded-xl p-3">
                <p className="text-xs text-muted-foreground mb-0.5">Stock Level</p>
                <p className="font-semibold text-sm">{product.stock} available</p>
              </div>
            </div>

            {/* Dietary */}
            {product.dietary.length > 0 && (
              <div className="mb-4">
                <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2">Dietary Info</p>
                <div className="flex flex-wrap gap-2">
                  {product.dietary.map((d) => (
                    <span key={d} className="text-xs font-semibold bg-success/10 text-success px-2.5 py-1 rounded-full border border-success/20">
                      {d}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Allergens */}
            {product.allergens.length > 0 && (
              <div className="mb-6">
                <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-1">
                  <AlertTriangle className="h-3 w-3 text-warning" /> Allergens
                </p>
                <div className="flex flex-wrap gap-2">
                  {product.allergens.map((a) => (
                    <span key={a} className="text-xs font-semibold bg-warning/10 text-warning px-2.5 py-1 rounded-full border border-warning/20">
                      {a}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Add to basket */}
            <button
              onClick={handleAdd}
              disabled={status === "out-of-stock"}
              className="w-full bg-gradient-to-r from-primary to-primary-light text-primary-foreground font-bold text-base py-3.5 rounded-xl hover:shadow-glow transition-all duration-300 disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2 active:scale-[0.98]"
              aria-label={`Add ${product.name} to basket`}
            >
              <Plus className="h-5 w-5" />
              {status === "out-of-stock" ? "Out of Stock" : "Add to Basket"}
            </button>
          </div>
        </div>

        {/* Related products */}
        {relatedProducts.length > 0 && (
          <section className="mt-16">
            <h2 className="text-xl font-bold font-serif mb-6">More in {product.category}</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {relatedProducts.map((rp) => (
                <Link
                  key={rp.id}
                  to={`/product/${rp.id}`}
                  className="group bg-card border border-border rounded-2xl overflow-hidden hover-lift shadow-sm"
                >
                  <div className="relative overflow-hidden">
                    <img
                      src={rp.image}
                      alt={rp.name}
                      className="w-full h-40 object-cover transition-transform duration-500 group-hover:scale-110"
                      loading="lazy"
                    />
                    <div className="absolute top-3 right-3">
                      <StockBadge stock={rp.stock} />
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-bold text-foreground">{rp.name}</h3>
                    <p className="text-muted-foreground text-xs">{rp.producer}</p>
                    <p className="text-primary font-extrabold text-lg mt-1">£{rp.price.toFixed(2)}</p>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}
      </main>
      <Footer />
    </div>
  );
}
