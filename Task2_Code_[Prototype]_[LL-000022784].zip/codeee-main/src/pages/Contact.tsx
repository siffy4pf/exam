import { useState } from "react";
import { Link } from "react-router-dom";
import Footer from "@/components/Footer";
import { toast } from "sonner";

export default function Contact() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) {
      toast.error("Please fill in all fields.");
      return;
    }
    toast.success("Thank you for your message! We'll get back to you soon.");
    setName("");
    setEmail("");
    setMessage("");
  };

  return (
    <div className="flex flex-col min-h-screen">
      <nav className="bg-primary px-4 py-3">
        <div className="container mx-auto">
          <Link to="/" className="text-primary-foreground font-serif text-xl font-bold">
            Local Produce Hub
          </Link>
        </div>
      </nav>
      <main className="container mx-auto flex-1 max-w-xl px-4 py-8">
        <h1 className="text-2xl font-bold font-serif text-primary mb-4">Contact Us</h1>
        <p className="mb-6 text-muted-foreground">
          Have a question or feedback? Get in touch with the GLH team.
        </p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="contactName" className="text-sm font-semibold block mb-1">Name</label>
            <input id="contactName" type="text" value={name} onChange={(e) => setName(e.target.value)} maxLength={100} className="w-full border border-input rounded-lg px-3 py-2 text-sm" required />
          </div>
          <div>
            <label htmlFor="contactEmail" className="text-sm font-semibold block mb-1">Email</label>
            <input id="contactEmail" type="email" value={email} onChange={(e) => setEmail(e.target.value)} maxLength={255} className="w-full border border-input rounded-lg px-3 py-2 text-sm" required />
          </div>
          <div>
            <label htmlFor="contactMessage" className="text-sm font-semibold block mb-1">Message</label>
            <textarea id="contactMessage" value={message} onChange={(e) => setMessage(e.target.value)} maxLength={1000} rows={5} className="w-full border border-input rounded-lg px-3 py-2 text-sm" required />
          </div>
          <button type="submit" className="bg-primary text-primary-foreground font-bold px-6 py-2 rounded-lg hover:bg-primary/90">
            Send Message
          </button>
        </form>
      </main>
      <Footer />
    </div>
  );
}
