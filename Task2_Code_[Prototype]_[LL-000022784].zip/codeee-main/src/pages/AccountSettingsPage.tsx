import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import AccountSettings from "@/components/dashboard/AccountSettings";
import { useAuth } from "@/context/AuthContext";
import { Link } from "react-router-dom";

// Wrapper page for account settings plus quick links.
export default function AccountSettingsPage() {
  const { user } = useAuth();

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="container mx-auto flex-1 px-4 py-8">
        <section className="mb-6 rounded-xl border border-border bg-card p-5">
          {/* Quick shortcut so users can jump to order history page. */}
          <h2 className="mb-2 text-xl font-bold font-serif">Order History</h2>
          <p className="mb-3 text-sm text-muted-foreground">
            View your previous orders and reorder items with one click.
          </p>
          <Link to="/account/orders" className="text-sm font-semibold text-primary hover:underline">
            Open previous orders
          </Link>
        </section>

        <AccountSettings userEmail={user?.email ?? ""} userRole={user?.role} />
      </main>
      <Footer />
    </div>
  );
}
