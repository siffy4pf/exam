import { Link } from "react-router-dom";
import Footer from "@/components/Footer";

export default function Privacy() {
  return (
    <div className="flex flex-col min-h-screen">
      <nav className="bg-primary px-4 py-3">
        <div className="container mx-auto">
          <Link to="/" className="text-primary-foreground font-serif text-xl font-bold">
            Local Produce Hub
          </Link>
        </div>
      </nav>
      <main className="container mx-auto flex-1 max-w-3xl px-4 py-8">
        <h1 className="text-2xl font-bold font-serif text-primary mb-4">Privacy Policy</h1>
        <p className="mb-4">
          At Greenfield Local Hub, we are committed to protecting your personal data in compliance with the UK General Data Protection Regulation (UK GDPR) and the Data Protection Act 2018.
        </p>
        <h2 className="text-lg font-bold font-serif text-primary mt-6 mb-2">What Data We Collect</h2>
        <ul className="list-disc list-inside space-y-1 mb-4">
          <li>Name and contact details when you create an account</li>
          <li>Order history and delivery preferences</li>
          <li>Loyalty points balance</li>
        </ul>
        <h2 className="text-lg font-bold font-serif text-primary mt-6 mb-2">How We Use Your Data</h2>
        <p className="mb-4">Your data is used solely to process orders, manage your account, and provide loyalty rewards. We do not share personal data with third parties except for payment processing through Stripe.</p>
        <h2 className="text-lg font-bold font-serif text-primary mt-6 mb-2">Your Rights</h2>
        <p className="mb-4">You have the right to access, correct, or delete your personal data at any time. Contact us at privacy@glh.co.uk to exercise these rights.</p>
        <h2 className="text-lg font-bold font-serif text-primary mt-6 mb-2">Data Security</h2>
        <p>All passwords are hashed using industry-standard encryption. Payment data is handled entirely by Stripe and never stored on our servers. Data consent is recorded at account creation.</p>
      </main>
      <Footer />
    </div>
  );
}
