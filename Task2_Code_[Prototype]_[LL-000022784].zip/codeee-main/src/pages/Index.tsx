import { useState, useMemo, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import HeroBanner from "@/components/HeroBanner";
import LoyaltyBanner from "@/components/LoyaltyBanner";
import CategoryGrid from "@/components/CategoryGrid";
import FilterBar from "@/components/FilterBar";
import ProductCard from "@/components/ProductCard";
import HowItWorks from "@/components/HowItWorks";
import ProducerSpotlight from "@/components/ProducerSpotlight";
import Footer from "@/components/Footer";
import { products } from "@/data/products";
import { useAuth } from "@/context/AuthContext";

// Home page: handles filters/search and shows featured products.
export default function Index() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [dietary, setDietary] = useState("All");
  const [producer, setProducer] = useState("All");
  const [inStockOnly, setInStockOnly] = useState(false);
  const productsRef = useRef<HTMLDivElement>(null);
  const { user } = useAuth();

  const filtered = useMemo(() => {
    // Keep all filter logic in one place so it is easy to adjust later.
    return products.filter((p) => {
      if (search) {
        const q = search.toLowerCase();
        const matchesName = p.name.toLowerCase().includes(q);
        const matchesProducer = p.producer.toLowerCase().includes(q);
        const matchesCategory = p.category.toLowerCase().includes(q);
        const matchesDescription = p.description?.toLowerCase().includes(q);
        if (!matchesName && !matchesProducer && !matchesCategory && !matchesDescription) return false;
      }
      if (category !== "All" && p.category !== category) return false;
      if (dietary !== "All" && !p.dietary.includes(dietary)) return false;
      if (producer !== "All" && p.producer !== producer) return false;
      if (inStockOnly && p.stock === 0) return false;
      return true;
    });
  }, [search, category, dietary, producer, inStockOnly]);

  const navigate = useNavigate();

  const handleCategorySelect = (cat: string) => {
    setCategory(cat);
    productsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const handleSearch = (query: string) => {
    setSearch(query);
    if (query.trim()) {
      productsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const displayedProducts = filtered.slice(0, 6);

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar onSearch={handleSearch} />
      <HeroBanner />
      {user && <LoyaltyBanner />}

      <main className="container mx-auto flex-1 px-4 pb-12">
        <CategoryGrid onCategorySelect={handleCategorySelect} />

        <div ref={productsRef} id="products" className="scroll-mt-20">
          <div className="flex items-end justify-between mb-2 pt-4">
            <div>
              <p className="text-primary font-bold text-sm uppercase tracking-wider mb-1">Fresh today</p>
              <h2 className="text-2xl md:text-3xl font-bold font-serif">
                {search ? `Results for "${search}"` : category === "All" ? "Featured Products" : category}
              </h2>
            </div>
            <div className="flex gap-5 text-xs text-muted-foreground">
              {[
                { color: "bg-success", label: "In Stock" },
                { color: "bg-warning", label: "Low Stock" },
                { color: "bg-destructive", label: "Out of Stock" },
              ].map((s) => (
                <span key={s.label} className="flex items-center gap-1.5">
                  <span className={`w-2 h-2 rounded-full ${s.color} inline-block`} />
                  {s.label}
                </span>
              ))}
            </div>
          </div>

          <FilterBar
            category={category}
            dietary={dietary}
            producer={producer}
            inStockOnly={inStockOnly}
            onCategoryChange={setCategory}
            onDietaryChange={setDietary}
            onProducerChange={setProducer}
            onInStockChange={setInStockOnly}
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-4 animate-stagger">
            {displayedProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>

          {filtered.length === 0 && (
            <div className="text-center py-16 animate-fade-in">
              <p className="text-muted-foreground text-lg font-semibold">No products match your filters.</p>
              <p className="text-muted-foreground/60 text-sm mt-1">Try adjusting your filters or search terms.</p>
              <button
                onClick={() => { setCategory("All"); setDietary("All"); setProducer("All"); setInStockOnly(false); }}
                className="mt-4 text-primary font-bold text-sm hover:underline"
              >
                Clear all filters
              </button>
            </div>
          )}

          {filtered.length > 6 && (
            <div className="text-center mt-8">
              <Link
                to="/products"
                className="inline-flex items-center gap-2 bg-gradient-to-r from-primary to-primary-light text-primary-foreground font-bold px-8 py-3 rounded-xl hover:shadow-glow transition-all duration-300"
              >
                View All Products ({filtered.length})
              </Link>
            </div>
          )}
        </div>

        <HowItWorks />
        <ProducerSpotlight />
      </main>

      <Footer />
    </div>
  );
}
