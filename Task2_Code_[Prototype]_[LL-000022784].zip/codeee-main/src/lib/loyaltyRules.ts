/** Mirrors backend `loyaltyRules.js` for checkout UI. */

export const MIN_REDEMPTION_POINTS = 75;
export const MAX_REDEMPTION_POINTS = 750;
export const REDEMPTION_INCREMENT = 75;

export function pointsEarnedFromEarnBasePence(earnBasePence: number) {
  if (!Number.isFinite(earnBasePence) || earnBasePence < 0) return 0;
  return Math.floor(earnBasePence / 10);
}

export function earnBasePence({
  merchandiseSubtotalPence,
  loyaltyDiscountPence,
}: {
  merchandiseSubtotalPence: number;
  loyaltyDiscountPence: number;
}) {
  const m = Number(merchandiseSubtotalPence);
  const d = Number(loyaltyDiscountPence);
  if (!Number.isFinite(m) || m < 0) return 0;
  if (!Number.isFinite(d) || d < 0) return Math.floor(m);
  return Math.max(0, Math.floor(m - d));
}

export function discountPenceFromRedeemedPoints(pointsToRedeem: number) {
  if (!Number.isFinite(pointsToRedeem) || pointsToRedeem < 0) return 0;
  return Math.floor(pointsToRedeem);
}

export function maxRedeemablePoints({
  merchandiseSubtotalPence,
  redeemablePointsBalance,
}: {
  merchandiseSubtotalPence: number;
  redeemablePointsBalance: number;
}) {
  const capBySubtotal = Math.min(
    MAX_REDEMPTION_POINTS,
    Math.max(0, Math.floor(Number(merchandiseSubtotalPence) || 0)),
    Math.max(0, Math.floor(Number(redeemablePointsBalance) || 0)),
  );
  if (capBySubtotal < MIN_REDEMPTION_POINTS) return 0;
  const steps = Math.floor(capBySubtotal / REDEMPTION_INCREMENT);
  return steps * REDEMPTION_INCREMENT;
}

export function redemptionOptions(maxPoints: number): number[] {
  const out: number[] = [0];
  for (let p = MIN_REDEMPTION_POINTS; p <= maxPoints; p += REDEMPTION_INCREMENT) {
    out.push(p);
  }
  return out;
}
