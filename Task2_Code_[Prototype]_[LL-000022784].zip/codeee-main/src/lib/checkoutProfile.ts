export type SavedDeliveryAddress = {
  line1: string;
  line2: string;
  city: string;
  postcode: string;
  phone: string;
};

export type SavedPaymentHint = {
  cardholderName: string;
  cardLast4: string;
  expiry: string;
};

export type SavedCheckoutProfile = {
  delivery: SavedDeliveryAddress;
  payment: SavedPaymentHint;
};

const STORAGE_PREFIX = "ghc_checkout_profile:";

function keyForUser(email: string) {
  return `${STORAGE_PREFIX}${email.toLowerCase().trim()}`;
}

export function loadCheckoutProfile(email: string): SavedCheckoutProfile | null {
  try {
    const raw = localStorage.getItem(keyForUser(email));
    if (!raw) return null;
    const parsed = JSON.parse(raw) as SavedCheckoutProfile;
    if (!parsed?.delivery || !parsed?.payment) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function saveCheckoutProfile(email: string, profile: SavedCheckoutProfile) {
  localStorage.setItem(keyForUser(email), JSON.stringify(profile));
}

export function formatAddress(d: SavedDeliveryAddress) {
  const parts = [d.line1.trim(), d.line2.trim(), d.city.trim(), d.postcode.trim(), d.phone.trim()].filter(Boolean);
  return parts.join(", ");
}
