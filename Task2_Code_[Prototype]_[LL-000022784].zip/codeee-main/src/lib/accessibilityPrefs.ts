const STORAGE_KEY = "ghc_accessibility_prefs_v1";

export interface AccessibilityPrefs {
  largeText: boolean;
  highContrast: boolean;
  reduceMotion: boolean;
}

const defaults: AccessibilityPrefs = {
  largeText: false,
  highContrast: false,
  reduceMotion: false,
};

export function loadAccessibilityPrefs(): AccessibilityPrefs {
  if (typeof window === "undefined") return defaults;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaults;
    const parsed = JSON.parse(raw) as Partial<AccessibilityPrefs>;
    return {
      largeText: Boolean(parsed.largeText),
      highContrast: Boolean(parsed.highContrast),
      reduceMotion: Boolean(parsed.reduceMotion),
    };
  } catch {
    return defaults;
  }
}

export function saveAccessibilityPrefs(prefs: AccessibilityPrefs) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs));
}

export function applyAccessibilityPrefs(prefs: AccessibilityPrefs) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  root.classList.toggle("a11y-large-text", prefs.largeText);
  root.classList.toggle("a11y-high-contrast", prefs.highContrast);
  root.classList.toggle("a11y-reduce-motion", prefs.reduceMotion);
}
