import { apiFetch } from "./client";

// Shared type for order history cards and tracker UI.
export interface UserOrder {
  id: string;
  status: "paid" | "cancelled" | "refunded" | "ready" | "dispatched" | "delivered" | "collected" | string;
  fulfillmentType: "collection" | "delivery";
  merchandiseSubtotalPence: number;
  deliveryChargePence: number;
  loyaltyPointsRedeemed: number;
  loyaltyDiscountPence: number;
  earnBasePence: number;
  pointsEarned: number;
  createdAt: string;
  items: Array<{
    productId: string | null;
    productName: string;
    unitPricePence: number;
    quantity: number;
  }>;
}

export function getMyOrders() {
  // Fetch only orders for currently signed-in account.
  return apiFetch<{ orders: UserOrder[] }>("/orders/mine");
}
