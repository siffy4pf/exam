export type AccountRole = "customer" | "producer";

export interface AuthUser {
  id: string;
  email: string;
  fullName: string | null;
  role: AccountRole;
}

export interface AccountProfile {
  bankAccountName: string;
  bankSortCode: string;
  bankAccountNumber: string;
  addressLine1: string;
  addressLine2: string;
  addressCity: string;
  addressPostcode: string;
  addressPhone: string;
}

interface AuthResponse {
  user: AuthUser;
}

import { apiFetch } from "./client";

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  return apiFetch<T>(path, options);
}

export function signUp(payload: {
  email: string;
  password: string;
  fullName?: string;
  role?: AccountRole;
}) {
  return request<AuthResponse>("/auth/signup", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export function login(payload: { email: string; password: string }) {
  return request<AuthResponse>("/auth/login", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export function logout() {
  return request<void>("/auth/logout", {
    method: "POST",
  });
}

export function getSession() {
  return request<AuthResponse>("/auth/session");
}

export function changePassword(payload: { currentPassword: string; newPassword: string }) {
  return request<{ message: string }>("/auth/change-password", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export function getAccountProfile() {
  // Load per-user bank/address profile from backend.
  return request<{ profile: AccountProfile }>("/auth/profile");
}

export function updateAccountProfile(payload: AccountProfile) {
  // Save per-user bank/address profile to backend.
  return request<{ profile: AccountProfile }>("/auth/profile", {
    method: "PUT",
    body: JSON.stringify(payload),
  });
}
