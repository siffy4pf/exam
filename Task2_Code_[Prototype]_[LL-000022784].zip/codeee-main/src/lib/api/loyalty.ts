import { apiFetch } from "./client";

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  return apiFetch<T>(path, options);
}

export interface LoyaltySummary {
  ledgerBalance: number;
  redeemablePoints: number;
}

export function getLoyaltySummary() {
  return request<LoyaltySummary>("/loyalty/summary");
}

export interface LoyaltyPreview {
  ok: boolean;
  errors: string[];
  redeemablePoints: number;
  discountPence: number;
  earnBasePence: number;
  pointsWouldEarn: number;
}

export function previewLoyaltyCheckout(body: {
  merchandiseSubtotalPence: number;
  pointsToRedeem: number;
}) {
  return request<LoyaltyPreview>("/loyalty/preview", {
    method: "POST",
    body: JSON.stringify(body),
  });
}

export interface CheckoutOrder {
  id: string;
  status: string;
  merchandiseSubtotalPence: number;
  deliveryChargePence: number;
  loyaltyPointsRedeemed: number;
  loyaltyDiscountPence: number;
  earnBasePence: number;
  pointsEarned: number;
  createdAt: string;
}

export function postOrderCheckout(body: {
  merchandiseSubtotalPence: number;
  deliveryChargePence: number;
  pointsToRedeem: number;
  idempotencyKey: string;
  fulfillmentType?: "collection" | "delivery";
  items?: Array<{
    productId: string;
    productName: string;
    unitPricePence: number;
    quantity: number;
  }>;
}) {
  return request<{ order: CheckoutOrder; duplicate: boolean }>("/orders/checkout", {
    method: "POST",
    body: JSON.stringify(body),
  });
}
