/**
 * In development, use same-origin requests so Vite can proxy to the backend (no CORS).
 * In production, use VITE_API_URL or the current origin.
 */
export function getApiBaseUrl(): string {
  if (import.meta.env.DEV) {
    return "";
  }
  const fromEnv = import.meta.env.VITE_API_URL;
  if (fromEnv && String(fromEnv).trim()) {
    return String(fromEnv).replace(/\/$/, "");
  }
  if (typeof window !== "undefined") {
    return window.location.origin;
  }
  return "http://localhost:4000";
}

export async function apiFetch<T>(path: string, options: RequestInit = {}): Promise<T> {
  const base = getApiBaseUrl();
  const url = `${base}${path.startsWith("/") ? path : `/${path}`}`;

  let response: Response;
  try {
    response = await fetch(url, {
      ...options,
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
        ...(options.headers ?? {}),
      },
    });
  } catch (e) {
    if (e instanceof TypeError) {
      throw new Error(
        "Cannot reach the server. From the project root run `npm run dev` (starts frontend and backend together). If you only run the frontend, start the backend with `npm run dev:backend`.",
      );
    }
    throw e;
  }

  if (!response.ok) {
    const text = await response.text();
    let message = `Request failed (${response.status})`;
    try {
      const data = JSON.parse(text) as { error?: string };
      if (data?.error) message = data.error;
    } catch {
      const snippet = text.replace(/\s+/g, " ").trim().slice(0, 120);
      if (snippet) message = `${message}: ${snippet}`;
    }
    throw new Error(message);
  }

  if (response.status === 204) {
    return undefined as T;
  }

  return response.json() as Promise<T>;
}
