import { apiFetch } from "./client";

// Types and API calls used by producer dashboard product management.
export interface ProducerProduct {
  id: string;
  producerUserId: string;
  name: string;
  stock: number;
  pricePence: number;
  price: number;
  createdAt: string;
  updatedAt: string;
}

export function getMyProducts() {
  // Load products that belong to the signed-in producer.
  return apiFetch<{ products: ProducerProduct[] }>("/products/mine");
}

export function createMyProduct(payload: { name: string; stock: number; price: number }) {
  // Create one new product for current producer.
  return apiFetch<{ product: ProducerProduct }>("/products/mine", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export function updateMyProductStock(productId: string, payload: { stock: number }) {
  // Update stock only (quick edit button in dashboard table).
  return apiFetch<{ product: ProducerProduct }>(`/products/${productId}/stock`, {
    method: "PATCH",
    body: JSON.stringify(payload),
  });
}
